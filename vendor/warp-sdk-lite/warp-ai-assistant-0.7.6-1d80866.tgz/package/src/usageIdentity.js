// 0.7.6 -- pseudonymous usage identity (server only). Lets Warp apply per-person limits WITHOUT ever
// receiving who the person is. It is computed exclusively inside the site's own server route
// (serverRouteHandler.js), never in the browser, and travels to Warp as ONE opaque header:
//
//   x-warp-client-ref: <32 characters, base64url>
//   = HMAC-SHA256(secret, "warp-usage-ref:v1|<UTC day>|<site API key>|<client IP>"), first 24 bytes
//
// - Client IP: read ONLY from the header the configured hosting platform overwrites itself
//   (TRUSTED_PROXY_HEADERS). Any other header the browser could send (x-forwarded-for on a platform
//   that does not overwrite it, a ready-made x-warp-client-ref, a body field) is never read.
// - Never sent to Warp: the IP, the User-Agent, cookies, the session, an e-mail or a user id. The
//   reference is irreversible without the secret, which only the site's server holds.
// - Rotation: the reference changes once per UTC day. Within the day it does not change when the
//   person navigates, reloads, clears the browser's site data or opens another conversation.
// - Bound to the site: the site's own API key is part of the input, so the same person gets a
//   different, unrelated reference on another site. Warp, in turn, hashes it again per siteId.
// - Without a usable signal (header missing or malformed), no reference is invented: Warp then
//   applies the site-wide limits only (same as Assistant 0.7.1-0.7.5).
// Uses Web Crypto (globalThis.crypto.subtle), never node:crypto, so the package entry stays safe to
// bundle for the browser.

export const USAGE_REF_HEADER = "x-warp-client-ref";
export const USAGE_REF_LENGTH = 32;
export const USAGE_REF_ROTATION = "utc-day";
// Headers each platform sets from the real connection and overwrites when the client sends them.
export const TRUSTED_PROXY_HEADERS = Object.freeze({
  vercel: "x-real-ip",
  cloudflare: "cf-connecting-ip",
});
export const MIN_SECRET_LENGTH = 32;
const IP_PATTERN = /^(?:[0-9]{1,3}(?:\.[0-9]{1,3}){3}|[0-9a-fA-F:]{2,39})$/;
const BASE64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

function toBase64Url(bytes) {
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const n = (bytes[i] << 16) | ((bytes[i + 1] ?? 0) << 8) | (bytes[i + 2] ?? 0);
    out += BASE64URL[(n >> 18) & 63] + BASE64URL[(n >> 12) & 63] + BASE64URL[(n >> 6) & 63] + BASE64URL[n & 63];
  }
  return out;
}

// Returns null when no identity is configured (and not required). Throws at creation -- i.e. at the
// site's start-up -- when it is required but cannot work: missing/short secret, unknown platform, or
// no Web Crypto. A hosted/production site passes required: true, so it can never run without it.
export function createUsageIdentity({ secret, trustedProxy, apiKey, required = false, clock = () => Date.now(), subtle = globalThis.crypto?.subtle } = {}) {
  const hasSecret = typeof secret === "string" && secret.length > 0;
  if (!hasSecret) {
    if (required) throw new Error("usageIdentity is required but no secret was configured (read it from a server-only environment variable).");
    return null;
  }
  if (secret.length < MIN_SECRET_LENGTH) throw new Error(`usageIdentity secret must have at least ${MIN_SECRET_LENGTH} characters.`);
  const headerName = TRUSTED_PROXY_HEADERS[trustedProxy];
  if (!headerName) throw new Error(`usageIdentity.trustedProxy must be one of: ${Object.keys(TRUSTED_PROXY_HEADERS).join(", ")}.`);
  if (!apiKey) throw new Error("usageIdentity needs the site API key.");
  if (!subtle?.importKey || !subtle?.sign) throw new Error("usageIdentity needs Web Crypto (globalThis.crypto.subtle).");
  const encoder = new TextEncoder();
  let keyPromise = null;
  const key = () => (keyPromise ||= subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]));

  return Object.freeze({
    headerName,
    // The reference for this request, or null when the platform gave no usable client address.
    async derive(request) {
      const raw = request?.headers?.get?.(headerName);
      const ip = typeof raw === "string" ? raw.split(",")[0].trim() : "";
      if (!IP_PATTERN.test(ip)) return null;
      const day = new Date(clock()).toISOString().slice(0, 10);
      const signature = new Uint8Array(await subtle.sign("HMAC", await key(), encoder.encode(`warp-usage-ref:v1|${day}|${apiKey}|${ip}`)));
      return toBase64Url(signature.subarray(0, 24));
    },
  });
}
