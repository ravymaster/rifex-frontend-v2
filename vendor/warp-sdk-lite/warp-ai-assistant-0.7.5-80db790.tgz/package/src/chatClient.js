import { validatePageContextShape } from "./pageContext.js";

// Talks to the SITE'S OWN server route (default "/api/warp/chat", same-origin), never to Warp's
// real API directly -- the Warp API token lives only in serverRouteHandler.js, server-side. The
// response shape matched here is the REAL external Chat API v1 contract
// (POST /api/v1/chat -> {conversationId, message} | {error:{code,message}}), not the richer
// internal /api/v1/generate shape (pendingConfirmation/guardDecision/usage) an earlier, internal-
// only widget in warp-ai-engine expected -- that shape does not exist on the real external endpoint.

export const CHAT_CLIENT_STATUSES = Object.freeze({
  IDLE: "idle",
  SENDING: "sending",
  ERROR: "error",
  RATE_LIMITED: "rate_limited",
  // "Ver más" mission -- distinct from SENDING so a caller can show a different loading affordance
  // (e.g. disable only the "Ver más" button, not the whole compose form) while a page advance is in
  // flight. Never blocks send() -- the two are independent operations against independent endpoints.
  LOADING_MORE: "loading_more",
});

const DEFAULT_MAX_MESSAGE_LENGTH = 2000;

// 0.7.3 -- shown when Warp answers a conversation it no longer had (see send()).
export const LOST_CONTEXT_NOTICE = "La conversación anterior ya no está disponible (el asistente se reinició o pasó mucho tiempo). Empezamos de nuevo: repite tu pregunta si hace falta.";

function initialState() {
  return {
    status: CHAT_CLIENT_STATUSES.IDLE,
    messages: [],
    conversationId: null,
    error: null,
    draftText: "",
    retryAfterMs: null,
    // Explicit-query mission (2026-10-06) -- one entry per open query form, keyed by its query
    // action id: { values, options, optionsStatus: "loading"|"ready"|"error"|"none", fieldErrors,
    // error, submitting }. Values typed by the person survive every recoverable error and are
    // carried over to the next query action offered after a successful consultation.
    queryForms: {},
  };
}

// Generic, code-based texts (never a site's vocabulary) for an explicit query's failures.
const QUERY_ERROR_TEXT = Object.freeze({
  OPTIONS_UNAVAILABLE: "No se pudieron cargar las opciones. Puedes reintentar.",
  SELECTION_CHANGED: "El elemento seleccionado cambió. Usa la consulta del elemento actual.",
  SELECTION_NO_LONGER_ACTIVE: "El elemento ya no está seleccionado. Selecciónalo de nuevo.",
  VALIDATION_FAILED: "Revisa los campos marcados.",
  READ_FAILED: "No se pudo consultar en este momento. Puedes reintentar con los mismos datos.",
  ACTION_INVALID_OR_EXPIRED: "Esta consulta ya no está disponible.",
  ACTION_ALREADY_USED: "Esta consulta ya se envió.",
});
const FIELD_ERROR_TEXT = Object.freeze({
  MISSING_REQUIRED_FIELD: "Campo obligatorio.",
  FORMAT_MISMATCH: "Formato inválido: usa fecha y hora con zona, por ejemplo 2026-10-10T10:00:00-03:00.",
  OPTION_NOT_AVAILABLE: "Esta opción ya no está disponible. Elige otra.",
  ENUM_MISMATCH: "Valor no permitido.",
  TYPE_MISMATCH: "Tipo de dato inválido.",
  INVALID_LOCAL_DATETIME: "Elige una fecha y una hora válidas.",
});

// Form date/time mission (2026-10-08) -- messages for a field whose contract declares its time zone
// (the person picks date and time; Warp converts them in that zone). They name the zone the site
// declared, never the visitor's own, and never adjust the time silently.
function fieldErrorText(code, field) {
  const zone = field?.timeZone;
  if (zone && code === "TIME_NONEXISTENT") return `Esa hora no existe en ${zone} por el cambio de horario. Elige otra hora.`;
  if (zone && code === "TIME_AMBIGUOUS") return `Esa hora ocurre dos veces en ${zone} por el cambio de horario. Elige otra hora.`;
  if (zone && (code === "FORMAT_MISMATCH" || code === "MISSING_REQUIRED_FIELD")) return "Elige la fecha y la hora.";
  return FIELD_ERROR_TEXT[code] || "Valor inválido.";
}
const FINAL_QUERY_ERRORS = new Set(["SELECTION_CHANGED", "SELECTION_NO_LONGER_ACTIVE", "ACTION_INVALID_OR_EXPIRED", "ACTION_ALREADY_USED"]);

// "Ver más" mission -- talks to the SITE'S OWN server route (default "/api/warp/chat/actions"),
// same posture as the chat endpoint above: the Warp API token lives only in serverRouteHandler.js,
// server-side, never in this browser-side module. The real external contract
// (POST /api/v1/chat/actions -> {conversationId,data,nextAction?} | {error:{code,message}}) is
// matched here, not guessed -- `data` is the capability's OWN real result, passed through verbatim;
// this client never interprets or names its fields.
export function createWarpChatClient({ endpoint = "/api/warp/chat", actionsEndpoint = "/api/warp/chat/actions", fetchImpl, maxMessageLength = DEFAULT_MAX_MESSAGE_LENGTH, pageContext: initialPageContext = null } = {}) {
  // 0.7.5 -- the page the site says the person is on (Warp Level 1). Set only by the site (widget
  // config or setPageContext on internal navigation), never read from the DOM, forms, storage or
  // cookies. Kept outside the conversation state: "Nueva conversación" keeps the current page, and
  // changing page keeps the conversation. Sent only with chat messages, to the site's own route.
  let pageContext = null;
  const applyPageContext = (candidate) => {
    if (candidate === null || candidate === undefined) {
      pageContext = null;
      return { ok: true };
    }
    const shape = validatePageContextShape(candidate);
    pageContext = shape.ok ? shape.value : null;
    return shape.ok ? { ok: true } : { ok: false, reason: "invalid_page_context" };
  };
  applyPageContext(initialPageContext);
  const doFetch = fetchImpl || (typeof fetch !== "undefined" ? fetch : null);
  let state = initialState();
  const listeners = new Set();

  function setState(patch) {
    state = { ...state, ...patch };
    for (const listener of listeners) listener(state);
  }

  function updateForm(queryId, patch) {
    const form = state.queryForms[queryId] || { values: {}, options: {}, fieldErrors: {} };
    setState({ queryForms: { ...state.queryForms, [queryId]: { ...form, ...patch } } });
  }

  // Explicit-query mission (2026-10-06) -- a POST to the site's own actions route that never touches
  // the global chat status (a form's loading/error lives in its own queryForms entry).
  async function postAction(payload) {
    if (typeof doFetch !== "function") return { ok: false, body: { error: { code: "NETWORK_UNAVAILABLE" } } };
    let response;
    try {
      response = await doFetch(actionsEndpoint, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    } catch {
      return { ok: false, body: { error: { code: "READ_FAILED" } } };
    }
    let body = {};
    try {
      body = await response.json();
    } catch {
      body = {};
    }
    return { ok: response.ok && !body.error, body };
  }

  return {
    getState() {
      return { ...state };
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    // Kept in sync with every keystroke so the in-progress draft survives a minimize/expand
    // re-render -- the widget never loses what the person was typing.
    setDraftText(text) {
      setState({ draftText: String(text ?? "") });
    },
    async send(rawMessage) {
      const message = String(rawMessage ?? "").trim();
      if (!message) return { ok: false, reason: "empty" };
      if (state.status === CHAT_CLIENT_STATUSES.SENDING) return { ok: false, reason: "already_sending" };
      if (message.length > maxMessageLength) return { ok: false, reason: "too_long" };
      if (typeof doFetch !== "function") {
        setState({ status: CHAT_CLIENT_STATUSES.ERROR, error: { code: "NETWORK_UNAVAILABLE", message: "fetch is not available in this environment." } });
        return { ok: false, reason: "no_fetch" };
      }

      setState({
        status: CHAT_CLIENT_STATUSES.SENDING,
        error: null,
        draftText: "",
        messages: [...state.messages, { role: "user", text: message, at: new Date().toISOString() }],
      });

      let response;
      try {
        response = await doFetch(endpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ message, conversationId: state.conversationId || undefined, ...(pageContext ? { pageContext } : {}) }),
        });
      } catch {
        setState({ status: CHAT_CLIENT_STATUSES.ERROR, error: { code: "NETWORK_ERROR", message: "No pudimos contactar al asistente." } });
        return { ok: false, reason: "network_error" };
      }

      let body = {};
      try {
        body = await response.json();
      } catch {
        body = {};
      }

      if (response.status === 429) {
        const retryAfterHeader = response.headers?.get?.("retry-after");
        setState({ status: CHAT_CLIENT_STATUSES.RATE_LIMITED, error: body.error || null, retryAfterMs: retryAfterHeader ? Number(retryAfterHeader) * 1000 : null });
        return { ok: false, reason: "rate_limited" };
      }
      if (!response.ok || body.error) {
        setState({ status: CHAT_CLIENT_STATUSES.ERROR, error: body.error || { code: "UNKNOWN_ERROR", message: "Algo salió mal." } });
        return { ok: false, reason: "error" };
      }

      // "Ver más" mission -- `body.actions`, when present, is Warp's own real, server-computed
      // continuation reference (see chatHandler.js/chatActionHandler.js) -- carried on the message
      // it belongs to, never as free-floating "last action" state, so a later, unrelated message
      // can never be mistaken for offering it. Absent entirely when there is nothing to offer.
      const action = Array.isArray(body.actions) && body.actions.length > 0 ? body.actions[0] : null;
      // "Selección de elemento real" mission -- `body.itemActions`, when present, is a SEPARATE,
      // additive field (one real `select` action per real, selectable item this turn's read
      // returned) -- `action`'s own meaning above (the one primary read_more/refresh action for
      // this message) is completely unchanged; a server that never sends `itemActions` produces
      // messages indistinguishable from before this mission.
      const itemActions = Array.isArray(body.itemActions) && body.itemActions.length > 0 ? body.itemActions : null;
      // 0.7.3: Warp no longer had this conversation (it restarted, was redeployed, or the
      // conversation expired) and answered it as a new one. Say so, once, right before the answer,
      // instead of silently forgetting -- only when this client had actually sent a conversation.
      const lostContext = body.conversationRestarted === true && Boolean(state.conversationId);
      const notice = lostContext ? [{ role: "notice", text: LOST_CONTEXT_NOTICE, at: new Date().toISOString() }] : [];
      setState({
        status: CHAT_CLIENT_STATUSES.IDLE,
        conversationId: body.conversationId || state.conversationId,
        messages: [...state.messages, ...notice, { role: "assistant", text: body.message || "", at: new Date().toISOString(), ...(action ? { action } : {}), ...(itemActions ? { itemActions } : {}), ...(itemActions && body.itemPresentation ? { itemPresentation: body.itemPresentation } : {}) }],
      });
      return { ok: true };
    },
    // "Ver más" mission -- advances the SPECIFIC action `id` (opaque, server-owned) refers to; never
    // reinterprets "continue the last search" itself. Appends a new `role:"result"` message carrying
    // the real, raw item data Warp's response returned (`data`) -- never text this client wrote on
    // the model's behalf, and this works identically whether or not a model is even configured
    // server-side ("la navegación debe funcionar aunque no se llame al modelo para redactar").
    async loadMore(actionId) {
      const id = String(actionId ?? "").trim();
      if (!id) return { ok: false, reason: "empty" };
      if (state.status === CHAT_CLIENT_STATUSES.SENDING || state.status === CHAT_CLIENT_STATUSES.LOADING_MORE) {
        return { ok: false, reason: "already_busy" };
      }
      if (typeof doFetch !== "function") {
        setState({ status: CHAT_CLIENT_STATUSES.ERROR, error: { code: "NETWORK_UNAVAILABLE", message: "fetch is not available in this environment." } });
        return { ok: false, reason: "no_fetch" };
      }

      setState({ status: CHAT_CLIENT_STATUSES.LOADING_MORE, error: null });

      let response;
      try {
        response = await doFetch(actionsEndpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ conversationId: state.conversationId || undefined, actionId: id }),
        });
      } catch {
        setState({ status: CHAT_CLIENT_STATUSES.ERROR, error: { code: "NETWORK_ERROR", message: "No pudimos contactar al asistente." } });
        return { ok: false, reason: "network_error" };
      }

      let body = {};
      try {
        body = await response.json();
      } catch {
        body = {};
      }

      if (response.status === 429) {
        const retryAfterHeader = response.headers?.get?.("retry-after");
        setState({ status: CHAT_CLIENT_STATUSES.RATE_LIMITED, error: body.error || null, retryAfterMs: retryAfterHeader ? Number(retryAfterHeader) * 1000 : null });
        return { ok: false, reason: "rate_limited" };
      }
      if (!response.ok || body.error) {
        // A recoverable error (e.g. this action already used, or expired) never wipes the
        // conversation -- only the status/error flip, so the widget can show a clear, recoverable
        // message next to the existing history.
        setState({ status: CHAT_CLIENT_STATUSES.ERROR, error: body.error || { code: "UNKNOWN_ERROR", message: "Algo salió mal." } });
        return { ok: false, reason: "error" };
      }

      // "Actualizar consulta" mission -- `data` is kept in full (not just `items`) so a flat,
      // non-list capability result (e.g. availability.check's status/message/eligibleUnitCount) can
      // be rendered too, generically, by the widget below -- never a per-capability translator here.
      // `items` is still derived the exact same way for "Ver más"'s own byte-for-byte behavior, EXCEPT
      // it is now `null` (never a fabricated `[]`) when the real result genuinely has no `items`
      // field at all -- distinct from a genuine empty list (`data.items: []`, 0 real matches), which
      // must still render as an empty list, never fall through to a flat-object rendering of `data`.
      // `obtainedAt` is the server's own real timestamp for THIS result (falls back to this client's
      // clock only if a server ever omits it) -- "no cambies la fecha del resultado anterior": this
      // is always a NEW message appended to the array, an earlier result's own `obtainedAt` is never
      // touched. The single-use `action` button that was just used successfully is removed from the
      // message that offered it (0.7.2): the server already consumed it, so leaving it visible only
      // invited "Esta acción ya no es válida"; any follow-up action arrives on the new message.
      const withoutUsedAction = state.messages.map((existing) => {
        if (existing?.action?.id !== id) return existing;
        const { action: _used, ...rest } = existing;
        return rest;
      });
      setState({
        status: CHAT_CLIENT_STATUSES.IDLE,
        conversationId: body.conversationId || state.conversationId,
        messages: [...withoutUsedAction, {
          role: "result",
          data: body.data ?? null,
          items: Array.isArray(body.data?.items) ? body.data.items : null,
          obtainedAt: body.obtainedAt || new Date().toISOString(),
          at: new Date().toISOString(),
          ...(body.nextAction ? { action: body.nextAction } : {}),
          // Result presentation hints from the site's own contract (Warp's resultPresentation.js).
          ...(body.presentation ? { presentation: body.presentation } : {}),
          // "Selección de elemento real" mission -- "selección desde una página obtenida por Ver
          // más": a page fetched through loadMore can ALSO offer its own real select actions for
          // its own items. Separate from `action` above, same posture as `send()`'s own itemActions.
          ...(Array.isArray(body.itemActions) && body.itemActions.length > 0 ? { itemActions: body.itemActions } : {}),
          // Explicit-query mission (2026-10-06) -- an explicit query offered for the element just
          // selected (or re-offered after a consultation). Rendered as a form by the widget.
          ...(Array.isArray(body.queryActions) && body.queryActions.length > 0 ? { queryActions: body.queryActions } : {}),
        }],
      });
      return { ok: true };
    },
    // Explicit-query mission (2026-10-06) -- opens the form of query action `query` (the summary the
    // server sent: {id, requiredFields, optionsActionId?}). When some field is a closed list, its
    // options are loaded NOW (one request, reused by every field fed by the same list); until they
    // are ready, or if loading fails, the form cannot be submitted.
    async openQueryForm(query) {
      if (!query?.id) return { ok: false, reason: "empty" };
      const existing = state.queryForms[query.id];
      const form = existing || { values: {}, options: {}, optionsStatus: query.optionsActionId ? "loading" : "none", fieldErrors: {}, error: null, submitting: false };
      setState({ queryForms: { ...state.queryForms, [query.id]: { ...form, open: true } } });
      if (query.optionsActionId && form.optionsStatus !== "ready") return this.loadQueryOptions(query);
      return { ok: true };
    },
    closeQueryForm(queryId) {
      const form = state.queryForms[queryId];
      if (!form) return;
      setState({ queryForms: { ...state.queryForms, [queryId]: { ...form, open: false } } });
    },
    async loadQueryOptions(query) {
      updateForm(query.id, { optionsStatus: "loading", error: null });
      const outcome = await postAction({ conversationId: state.conversationId || undefined, actionId: query.optionsActionId });
      if (!outcome.ok) {
        updateForm(query.id, { optionsStatus: "error", error: QUERY_ERROR_TEXT.OPTIONS_UNAVAILABLE });
        return { ok: false, reason: "options_unavailable" };
      }
      const options = outcome.body?.data?.options && typeof outcome.body.data.options === "object" ? outcome.body.data.options : {};
      updateForm(query.id, { optionsStatus: "ready", options, error: null });
      return { ok: true };
    },
    // Updates a typed value WITHOUT notifying listeners: re-rendering on every keystroke would rebuild
    // the inputs and lose focus. The value is read back on the next real render/submit.
    setQueryValue(queryId, name, value) {
      const form = state.queryForms[queryId];
      if (!form) return;
      state = { ...state, queryForms: { ...state.queryForms, [queryId]: { ...form, values: { ...form.values, [name]: value } } } };
    },
    async submitQuery(query) {
      const form = state.queryForms[query?.id];
      if (!form || form.submitting) return { ok: false, reason: "already_busy" };
      if (query.optionsActionId && form.optionsStatus !== "ready") return { ok: false, reason: "options_not_ready" };
      updateForm(query.id, { submitting: true, error: null, fieldErrors: {} });
      const outcome = await postAction({ conversationId: state.conversationId || undefined, actionId: query.id, values: form.values });
      if (!outcome.ok) {
        const code = outcome.body?.error?.code || "UNKNOWN_ERROR";
        const fieldErrors = {};
        for (const detail of Array.isArray(outcome.body?.error?.details) ? outcome.body.error.details : []) {
          const name = String(detail?.path || "").replace(/^\$\./, "");
          if (name) fieldErrors[name] = fieldErrorText(detail.code, (query.requiredFields || []).find((field) => field.name === name));
        }
        updateForm(query.id, { submitting: false, fieldErrors, error: QUERY_ERROR_TEXT[code] || "No se pudo completar la consulta.", final: FINAL_QUERY_ERRORS.has(code) });
        return { ok: false, reason: code };
      }
      const body = outcome.body;
      const nextQuery = Array.isArray(body.queryActions) ? body.queryActions[0] : null;
      const nextForms = { ...state.queryForms };
      delete nextForms[query.id];
      // The values just used stay in the NEXT form (same element, same fields): consulting again
      // with other dates never means typing everything from scratch.
      if (nextQuery?.id) nextForms[nextQuery.id] = { values: { ...form.values }, options: form.options, optionsStatus: nextQuery.optionsActionId ? form.optionsStatus : "none", fieldErrors: {}, error: null, submitting: false, open: false };
      setState({
        queryForms: nextForms,
        messages: [...state.messages, {
          role: "result",
          data: body.data ?? null,
          items: Array.isArray(body.data?.items) ? body.data.items : null,
          obtainedAt: body.obtainedAt || new Date().toISOString(),
          at: new Date().toISOString(),
          ...(nextQuery ? { queryActions: body.queryActions } : {}),
          ...(body.presentation ? { presentation: body.presentation } : {}),
        }],
      });
      return { ok: true };
    },
    // Conversation (messages + conversationId) and any in-progress draft are preserved by
    // construction -- this state object is never reset by minimize/expand/restore, only by an
    // explicit reset() the widget calls on a genuine "start over" action.
    reset() {
      setState(initialState());
    },
    // 0.7.3: the widget's "Nueva conversación" button. Starts a clean conversation (no messages,
    // no conversationId, no open forms) and keeps only what the person was typing. Refused while a
    // message or a page is in flight, so a late response can never land in the new conversation.
    // 0.7.5 -- called by the site on internal navigation (or with null to clear). An invalid context
    // is never sent: it clears the current one and reports { ok:false }.
    setPageContext(candidate) {
      return applyPageContext(candidate);
    },
    getPageContext() {
      return pageContext ? { ...pageContext } : null;
    },
    startNewConversation() {
      if (state.status === CHAT_CLIENT_STATUSES.SENDING || state.status === CHAT_CLIENT_STATUSES.LOADING_MORE) {
        return { ok: false, reason: "busy" };
      }
      setState({ ...initialState(), draftText: state.draftText });
      return { ok: true };
    },
  };
}
