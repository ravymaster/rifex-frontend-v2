// Safe, clickable links (0.7.4). Warp sends answers as plain text (plus structured actions such as
// "Ver más" / "Seleccionar"); it has no structured link channel. So the widget detects URLs in the
// text itself -- strictly:
//   - only `https://` URLs are ever made clickable; anything else (javascript:, data:, file:, http:,
//     unknown schemes, malformed or over-long URLs, URLs carrying credentials) stays plain text;
//   - the text is never interpreted as HTML or Markdown: every segment is escaped by the caller and a
//     link is built only from the parsed, normalized URL (`URL.href`), never from raw text;
//   - the visible label shows where the link really goes: the path for the site's own pages, the
//     domain (in its ASCII/punycode form, which exposes look-alike characters) for anything else;
//   - which hosts count as the site's own, and optionally which hosts may be linked at all, come
//     from the SITE's widget configuration (per environment), never from a list fixed in this file.
// Clicking a link opens a new tab (`target="_blank"`, `rel="noopener noreferrer"`): the conversation
// in the original tab is untouched, and no request to Warp (no inference) is ever made.

export const MAX_URL_LENGTH = 2048;
const URL_CANDIDATE = /https:\/\/[^\s<>"'`]+/gi;
const TRAILING_PUNCTUATION = new Set([".", ",", ";", ":", "!", "?", "…", "»", "”", "’", "'", '"', ")", "]", "}", "*", "_"]);
const PAIRS = { ")": "(", "]": "[", "}": "{" };

function normalizeHost(value) {
  try {
    return new URL(`https://${String(value || "").trim()}`).host.toLowerCase();
  } catch {
    return null;
  }
}

// `config.links` (optional, provided by the site per environment):
//   { internalHosts: ["sitio.example.com"], allowedHosts: ["otro.example.com"] }
// The page's own host is always internal. When `allowedHosts` is given, links to any host that is
// neither internal nor listed stay plain text; when absent, any valid https link is clickable and an
// external one shows its domain clearly.
export function normalizeLinkPolicy(links = {}, pageHost = null) {
  const internal = new Set();
  const own = pageHost ? normalizeHost(pageHost) : null;
  if (own) internal.add(own);
  for (const host of Array.isArray(links?.internalHosts) ? links.internalHosts : []) {
    const normalized = normalizeHost(host);
    if (normalized) internal.add(normalized);
  }
  let allowed = null;
  if (Array.isArray(links?.allowedHosts)) {
    allowed = new Set();
    for (const host of links.allowedHosts) {
      const normalized = normalizeHost(host);
      if (normalized) allowed.add(normalized);
    }
  }
  return Object.freeze({ internalHosts: internal, allowedHosts: allowed });
}

export function parseSafeUrl(raw, policy = normalizeLinkPolicy()) {
  const text = String(raw ?? "");
  if (!text || text.length > MAX_URL_LENGTH) return { ok: false, reason: "length" };
  if (!/^https:\/\//i.test(text)) return { ok: false, reason: "scheme" };
  let url;
  try {
    url = new URL(text);
  } catch {
    return { ok: false, reason: "malformed" };
  }
  if (url.protocol !== "https:") return { ok: false, reason: "scheme" };
  // `https://sitio.cl@otro.com/...` looks like one site and goes to another: never a link.
  if (url.username || url.password) return { ok: false, reason: "credentials" };
  if (!url.hostname || !url.hostname.includes(".")) return { ok: false, reason: "host" };
  const host = url.host.toLowerCase();
  const internal = policy.internalHosts.has(host);
  if (!internal && policy.allowedHosts && !policy.allowedHosts.has(host)) return { ok: false, reason: "host_not_allowed" };
  return { ok: true, href: url.href, host, internal, path: `${url.pathname}${url.search}` };
}

// Removes punctuation that follows a URL in a sentence ("…en https://x.cl/a." -> "https://x.cl/a"),
// keeping a closing bracket that belongs to the URL itself (balanced inside it).
function trimTrailing(candidate) {
  let end = candidate.length;
  while (end > 0 && TRAILING_PUNCTUATION.has(candidate[end - 1])) {
    const ch = candidate[end - 1];
    const open = PAIRS[ch];
    if (open) {
      const body = candidate.slice(0, end);
      const opens = body.split(open).length - 1;
      const closes = body.split(ch).length - 1;
      if (opens >= closes) break;
    }
    end -= 1;
  }
  return candidate.slice(0, end);
}

// Splits text into plain segments and validated links. A candidate that fails validation is kept
// as plain text, exactly as written.
export function splitTextWithLinks(text, policy = normalizeLinkPolicy()) {
  const source = String(text ?? "");
  const segments = [];
  let last = 0;
  for (const match of source.matchAll(URL_CANDIDATE)) {
    const candidate = trimTrailing(match[0]);
    if (!candidate) continue;
    const start = match.index;
    const parsed = parseSafeUrl(candidate, policy);
    if (!parsed.ok) continue;
    if (start > last) segments.push({ type: "text", value: source.slice(last, start) });
    segments.push({ type: "link", value: candidate, ...parsed });
    last = start + candidate.length;
  }
  if (last < source.length) segments.push({ type: "text", value: source.slice(last) });
  return segments;
}

const MAX_LABEL_PATH = 48;
function shorten(value) {
  return value.length > MAX_LABEL_PATH ? `${value.slice(0, MAX_LABEL_PATH - 1)}…` : value;
}

// The clear, visible label of a link (the caller escapes it).
export function linkLabel(link) {
  if (link.internal) return link.path && link.path !== "/" ? shorten(link.path) : "Página de inicio";
  return link.host;
}
