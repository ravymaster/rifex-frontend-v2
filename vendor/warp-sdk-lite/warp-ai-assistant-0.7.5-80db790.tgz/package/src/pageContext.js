// Assistant copy (0.7.5) of Warp's page context shape check (lib/ai/levels/pageContext.js). The site
// server route uses it to refuse malformed contexts before they reach Warp; Warp itself remains the
// authority (closed shape + the site's declared pages). Keep both in sync.
//
// Minimal page context (Warp Level 1, 2026-11-11) -- tells the model WHERE the person is so a new
// conversation can orient them ("Ya estoy aquí, ¿qué hago?"), and nothing else.
//
// Closed schema: exactly { pageId, module, area, guidance }, every value a short identifier
// (lowercase letters, digits, hyphen; starts with a letter; at most 40 chars; no 5+ digit runs, so
// phone numbers, RUTs, card or account numbers cannot be smuggled in). `area` is a closed list.
// Anything else -- extra fields, URLs, query strings, hashes, free text, form values, cookies,
// tokens, names, emails, UUIDs -- is rejected. A shape-valid context must ALSO match, field by
// field, one entry the site declared in Warp's private configuration (`allowedPageContexts`): the
// browser can pick among declared pages, never invent one, and a page of another site never matches.
//
// The context only orients: it grants no permission, never raises the site's level, never enables
// a capability and proves no role. Capabilities are decided only by the site's level policy.

export const PAGE_CONTEXT_FIELDS = Object.freeze(["pageId", "module", "area", "guidance"]);
export const PAGE_CONTEXT_AREAS = Object.freeze(["public", "account", "administrative"]);
export const PAGE_CONTEXT_MAX_LENGTH = 40;
const IDENTIFIER = /^[a-z][a-z0-9-]{0,39}$/;
const DIGIT_RUN = /\d{5,}/;

export const PAGE_CONTEXT_ERRORS = Object.freeze({
  INVALID: "PAGE_CONTEXT_INVALID",
  NOT_ALLOWED: "PAGE_CONTEXT_NOT_ALLOWED",
});

function isIdentifier(value) {
  return typeof value === "string" && value.length <= PAGE_CONTEXT_MAX_LENGTH && IDENTIFIER.test(value) && !DIGIT_RUN.test(value) && !value.includes("--") && !value.endsWith("-");
}

// Pure shape validation. Returns { ok, value } with a frozen copy, or { ok:false, code }.
export function validatePageContextShape(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return { ok: false, code: PAGE_CONTEXT_ERRORS.INVALID };
  const keys = Object.keys(input);
  if (keys.length !== PAGE_CONTEXT_FIELDS.length || keys.some((key) => !PAGE_CONTEXT_FIELDS.includes(key))) return { ok: false, code: PAGE_CONTEXT_ERRORS.INVALID };
  if (!PAGE_CONTEXT_FIELDS.every((field) => isIdentifier(input[field]))) return { ok: false, code: PAGE_CONTEXT_ERRORS.INVALID };
  if (!PAGE_CONTEXT_AREAS.includes(input.area)) return { ok: false, code: PAGE_CONTEXT_ERRORS.INVALID };
  return { ok: true, value: Object.freeze({ pageId: input.pageId, module: input.module, area: input.area, guidance: input.guidance }) };
}

// Exact match of all four fields against the site's declared list.
export function isPageContextAllowed(context, allowedPageContexts) {
  if (!Array.isArray(allowedPageContexts)) return false;
  return allowedPageContexts.some((entry) => PAGE_CONTEXT_FIELDS.every((field) => entry?.[field] === context[field]));
}

// Full check used by the chat route: shape first, then the site's own list.
export function resolvePageContext(input, allowedPageContexts) {
  const shape = validatePageContextShape(input);
  if (!shape.ok) return shape;
  if (!isPageContextAllowed(shape.value, allowedPageContexts)) return { ok: false, code: PAGE_CONTEXT_ERRORS.NOT_ALLOWED };
  return shape;
}
