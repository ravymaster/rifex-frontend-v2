// Runs ONLY on the site's own server (a Next.js Route Handler, or anything that calls this with a
// real Web-standard Request). The Warp API token is read here, from server-side config, and NEVER
// serialized into any response sent to the browser -- chatClient.js (browser-side) only ever talks
// to this route's own relative path, never to Warp's real API URL directly.

const DEFAULT_MAX_BODY_BYTES = 8 * 1024;
const DEFAULT_MAX_MESSAGE_LENGTH = 2000;
const DEFAULT_TIMEOUT_MS = 25_000;

function jsonResponse(body, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", ...extraHeaders } });
}

// createWarpChatRouteHandler({ apiUrl, apiKey }) -- `apiUrl` is Warp AI Engine's real base URL
// (e.g. "https://warp-ai-engine-v1.vercel.app"), `apiKey` the real Site API Key
// (warp_...), both read by the CALLER from server-only env vars (process.env.WARP_AI_API_URL /
// process.env.WARP_AI_API_KEY, matching the variable names the Renacar compatibility audit already
// found the consuming site expects to have). This function never reads process.env itself, so it
// stays runtime-agnostic and trivially testable.
export function createWarpChatRouteHandler({ apiUrl, apiKey, fetchImpl, maxMessageLength = DEFAULT_MAX_MESSAGE_LENGTH, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
  if (!apiUrl || !apiKey) {
    throw new Error("createWarpChatRouteHandler requires both apiUrl and apiKey (read from server-only environment variables by the caller, never hardcoded).");
  }
  const doFetch = fetchImpl || (typeof fetch !== "undefined" ? fetch : null);
  const targetUrl = new URL("/api/v1/chat", apiUrl).toString();

  return async function warpChatRouteHandler(request) {
    const contentType = request.headers.get("content-type") || "";
    if (!contentType.toLowerCase().includes("application/json")) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Content-Type must be application/json." } }, 400);
    }

    let rawBody;
    try {
      rawBody = await request.text();
    } catch {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Could not read the request body." } }, 400);
    }
    if (Buffer.byteLength(rawBody, "utf8") > DEFAULT_MAX_BODY_BYTES) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Request body is too large." } }, 413);
    }

    let payload;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Invalid JSON body." } }, 400);
    }

    const message = String(payload?.message || "").trim();
    if (!message) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "message is required." } }, 400);
    }
    if (message.length > maxMessageLength) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: `message exceeds ${maxMessageLength} characters.` } }, 413);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const upstreamResponse = await doFetch(targetUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          // The ONLY place the real token is ever attached to a request -- server-side, on the
          // OUTBOUND call to Warp, never echoed back to the browser in any response this route sends.
          authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          message,
          ...(payload?.conversationId ? { conversationId: String(payload.conversationId).slice(0, 128) } : {}),
        }),
        signal: controller.signal,
      });
      const upstreamBody = await upstreamResponse.json().catch(() => ({}));
      // Forwards Warp's own real response shape/status as-is -- never invents a different one, and
      // never includes anything from the request headers (no token) in what goes back to the browser.
      return jsonResponse(upstreamBody, upstreamResponse.status, upstreamResponse.status === 429 && upstreamResponse.headers.get("retry-after") ? { "retry-after": upstreamResponse.headers.get("retry-after") } : {});
    } catch (error) {
      if (error?.name === "AbortError") {
        return jsonResponse({ error: { code: "TIMEOUT", message: "El asistente tardó demasiado en responder." } }, 504);
      }
      return jsonResponse({ error: { code: "UPSTREAM_UNAVAILABLE", message: "No se pudo contactar al asistente en este momento." } }, 502);
    } finally {
      clearTimeout(timeoutId);
    }
  };
}

// "Ver más" mission -- same exact posture as createWarpChatRouteHandler above (the Warp API token
// is read here, server-side, and never echoed to the browser), proxying instead to Warp's real
// POST /api/v1/chat/actions. Deliberately separate from the chat handler above: this route has its
// own (shorter) default timeout, since advancing a page is a single real Connector round trip, never
// a model call.
const DEFAULT_ACTION_TIMEOUT_MS = 15_000;
const DEFAULT_MAX_ID_LENGTH = 128;

export function createWarpReadActionRouteHandler({ apiUrl, apiKey, fetchImpl, timeoutMs = DEFAULT_ACTION_TIMEOUT_MS } = {}) {
  if (!apiUrl || !apiKey) {
    throw new Error("createWarpReadActionRouteHandler requires both apiUrl and apiKey (read from server-only environment variables by the caller, never hardcoded).");
  }
  const doFetch = fetchImpl || (typeof fetch !== "undefined" ? fetch : null);
  const targetUrl = new URL("/api/v1/chat/actions", apiUrl).toString();

  return async function warpReadActionRouteHandler(request) {
    const contentType = request.headers.get("content-type") || "";
    if (!contentType.toLowerCase().includes("application/json")) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Content-Type must be application/json." } }, 400);
    }

    let rawBody;
    try {
      rawBody = await request.text();
    } catch {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Could not read the request body." } }, 400);
    }
    if (Buffer.byteLength(rawBody, "utf8") > DEFAULT_MAX_BODY_BYTES) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Request body is too large." } }, 413);
    }

    let payload;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "Invalid JSON body." } }, 400);
    }

    const conversationId = String(payload?.conversationId || "").trim();
    const actionId = String(payload?.actionId || "").trim();
    if (!conversationId || !actionId) {
      return jsonResponse({ error: { code: "INVALID_INPUT", message: "conversationId and actionId are required." } }, 400);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const upstreamResponse = await doFetch(targetUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          // The ONLY place the real token is ever attached to this request -- server-side, never
          // echoed back to the browser in any response this route sends.
          authorization: `Bearer ${apiKey}`,
        },
        // Explicit-query mission (2026-10-06) -- the values of an explicit query form, forwarded
        // only when they are a flat object (Warp validates every key/value against the real schema).
        body: JSON.stringify({
          conversationId: conversationId.slice(0, DEFAULT_MAX_ID_LENGTH),
          actionId: actionId.slice(0, DEFAULT_MAX_ID_LENGTH),
          ...(payload?.values && typeof payload.values === "object" && !Array.isArray(payload.values) ? { values: payload.values } : {}),
        }),
        signal: controller.signal,
      });
      const upstreamBody = await upstreamResponse.json().catch(() => ({}));
      return jsonResponse(upstreamBody, upstreamResponse.status, upstreamResponse.status === 429 && upstreamResponse.headers.get("retry-after") ? { "retry-after": upstreamResponse.headers.get("retry-after") } : {});
    } catch (error) {
      if (error?.name === "AbortError") {
        return jsonResponse({ error: { code: "TIMEOUT", message: "La acción tardó demasiado en completarse." } }, 504);
      }
      return jsonResponse({ error: { code: "UPSTREAM_UNAVAILABLE", message: "No se pudo contactar al asistente en este momento." } }, 502);
    } finally {
      clearTimeout(timeoutId);
    }
  };
}
