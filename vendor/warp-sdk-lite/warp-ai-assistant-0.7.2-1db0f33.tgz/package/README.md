# @warp-ai/assistant

Floating chat widget (window + expanded view) that talks to Warp through **the site's own server
route** — the Warp Site API Key never reaches the browser.

```
Browser widget --(same-origin, relative)--> /api/warp/chat (your route) --(server-side, Bearer token)--> Warp's real /api/v1/chat
```

## Server route (token lives here only)

```js
// app/api/warp/chat/route.js
import { createWarpChatRouteHandler } from "@warp-ai/assistant";

export const POST = createWarpChatRouteHandler({
  apiUrl: process.env.WARP_AI_API_URL,   // e.g. "https://warp-ai-engine-v1.vercel.app"
  apiKey: process.env.WARP_AI_API_KEY,   // the real Site API Key, server-only env var
});
```

## Widget (client)

```jsx
"use client";
import { useEffect } from "react";
import { createWarpWidgetGlobal } from "@warp-ai/assistant";

export function WarpAssistant() {
  useEffect(() => {
    const widget = createWarpWidgetGlobal();
    widget.init({ title: "Asistente", endpoint: "/api/warp/chat" });
    return () => widget.destroy();
  }, []);
  return null;
}
```

Conversation and any in-progress draft text are held in the chat client, never reset by
minimize/expand/restore — only an explicit "start over" clears them.

## "Ver más" — explicit page navigation, controlled by Warp

When a real read the model performed has more pages (the capability's Discovery schema declares
page/total-pages fields, and the installation configured `WARP_AI_READ_PAGE_CONTINUATION_POLICY`
for it — see the Warp AI Engine docs), `POST /api/v1/chat` includes an `actions` array on that
reply. This widget renders a "Ver más" button for it automatically; clicking it **never calls the
model** — it goes straight to Warp's own `/api/v1/chat/actions`, which re-validates ownership,
advances exactly one page (conserving the original filters), and calls the site's real Connector.

Add a second server route, same pattern as the chat one above:

```js
// app/api/warp/chat/actions/route.js
import { createWarpReadActionRouteHandler } from "@warp-ai/assistant";

export const POST = createWarpReadActionRouteHandler({
  apiUrl: process.env.WARP_AI_API_URL,
  apiKey: process.env.WARP_AI_API_KEY,
});
```

The widget's default `actionsEndpoint` is `/api/warp/chat/actions` — pass a different path to
`createFloatingWidget`/`createWarpChatClient` if your route lives elsewhere. Rendered items come
from the capability's own real result, generically (whatever primitive fields it has) — this
package never assumes or names a business-specific field.

## "Actualizar consulta" — explicit refresh, controlled by Warp

Some read capabilities (an installation opts them in explicitly via
`WARP_AI_READ_REFRESH_POLICY`, never guessed) can be **re-run on demand** with their exact original
arguments — for a flat, structured answer that can genuinely change between the moment the model
first answered and whenever the person wants to check again (e.g. "is this still available?"),
rather than a paginated list. `POST /api/v1/chat` offers this the exact same way as "Ver más" — an
`actions` entry with `kind: "refresh"` — and it goes through the **same** `/api/v1/chat/actions`
route above; no second route to add. Clicking it never calls the model either, and unlike "Ver más"
a failed refresh can be retried with the same button (it is never left permanently unusable).

The result renders generically too: a flat, non-list result becomes one row of field:value chips
(the same rendering "Ver más" already uses for each list item), with the real moment it was
obtained shown underneath. A capability that never opted in behaves exactly as before — no button,
no change.

## "Selección de elemento real" — choosing a real catalog item without knowing its id

Some read capabilities (an installation opts them in explicitly via
`WARP_AI_READ_SELECTION_POLICY`, declaring which OTHER capability+argument the item's real id is
meant to feed — never guessed from field names) offer a `select` action **per real item** of a list
result. The person clicks a real item (never types or copies an id); Warp validates and stores that
selection, server-side, scoped to this conversation. A later query that needs that exact argument
uses the stored, validated id automatically when the model doesn't state one — and if the model
proposes a genuinely different value instead, Warp never silently picks one over the other: it asks
for a new selection or a clarification instead of guessing.

This arrives on the SAME message as the model's reply, in a new, separate `itemActions` field —
`actions` (the single read_more/refresh/clear_selection slot) keeps its exact previous meaning
unchanged. The widget renders each selectable item with the same generic per-field chips as any
other item, plus a "Seleccionar" affordance; clicking it goes straight to the same
`/api/v1/chat/actions` route above (no third route to add), confirms the exact real item chosen, and
offers a "Quitar selección" action to clear it explicitly. Selecting a different item simply replaces
the previous selection; nothing is ever inferred from free text.

## Result presentation (0.7.0) — readable cards declared by the site

By default each result item is shown generically, one chip per field. A site can make items
readable by annotating its OWN capability `outputSchema` (the item schema for list results, or the
top-level properties for a single object) with `x-presentation`, plus an optional standard `title`
as the human label:

| `x-presentation` | Shown as |
|---|---|
| `"title"` | the item's name, in bold |
| `"detail"` | a short line under the title (`title`, if declared, is used as its label) |
| `"hidden"` | never shown (internal ids, raw values) |
| not annotated | inside a collapsed "Más detalles" section, labeled with `title` if declared |

Warp reads these annotations from the real Discovery manifest and sends them with the results
(`itemPresentation` on chat replies, `presentation` on action results). Only primitive values (and
lists of them) are displayed; objects are never shown raw. The widget never decides which field is
the title: without annotations nothing changes.

## What this does NOT do yet

- No mutation/reservation support — the real `/api/v1/chat` endpoint this proxies to is
  conversation-only by design (see `RENACAR_DISCOVERY_COMPATIBILITY_AUDIT.md`). Selecting an item
  never confirms availability or creates a reservation by itself.
- No persistence of `conversationId` across a full page reload (in-memory only in this version) —
  add your own `localStorage` wiring around `createWarpChatClient` if you need that.
- No deterministic detection of "the person wants to change item" from free text alone — changing or
  clearing a selection always goes through the explicit `select`/`clear_selection` controls above,
  never a guess at conversational intent.
