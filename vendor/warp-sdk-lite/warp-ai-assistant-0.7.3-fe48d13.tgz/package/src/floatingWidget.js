import { createWarpChatClient, CHAT_CLIENT_STATUSES } from "./chatClient.js";

// A floating chat widget with THREE visual states -- closed, window (the normal panel) and
// expanded ("vista ampliada", a larger panel) -- plus an orthogonal minimized flag. Conversation
// (chatClient's own messages/conversationId) and the in-progress draft text both live in
// chatClient, which nothing here ever resets except the explicit "empezar de nuevo" action -- every
// render() reads the CURRENT draftText from chatClient and writes it back into the textarea, so a
// minimize/expand/restore cycle (which re-renders the DOM) never loses what the person was typing.

export const WIDGET_MODES = Object.freeze({ CLOSED: "closed", WINDOW: "window", EXPANDED: "expanded" });
export const WIDGET_EVENTS = Object.freeze({
  OPENED: "widget.opened",
  CLOSED: "widget.closed",
  MINIMIZED: "widget.minimized",
  EXPANDED: "widget.expanded",
  DESTROYED: "widget.destroyed",
});

function normalizeConfig(config = {}) {
  return {
    endpoint: config.endpoint || "/api/warp/chat",
    actionsEndpoint: config.actionsEndpoint || "/api/warp/chat/actions",
    title: config.title || "Asistente",
    subtitle: config.subtitle || "",
    placeholder: config.placeholder || "Escribe tu mensaje...",
    primaryColor: config.primaryColor || "#176d5f",
    accentColor: config.accentColor || "#eef1ef",
    position: config.position === "bottom-left" ? "bottom-left" : "bottom-right",
    launcherLabel: config.launcherLabel || "Chat",
    maxMessageLength: Number(config.maxMessageLength || 2000),
  };
}

export function createFloatingWidget(config = {}, environment = {}) {
  const doc = environment.document || (typeof document !== "undefined" ? document : null);
  const customElementsRegistry = environment.customElements || (typeof customElements !== "undefined" ? customElements : null);

  if (!doc?.createElement) {
    return createUnavailableWidget();
  }

  registerWarpWidgetElement(customElementsRegistry);

  const normalized = normalizeConfig(config);
  const client = config.client || createWarpChatClient({ endpoint: normalized.endpoint, actionsEndpoint: normalized.actionsEndpoint, fetchImpl: config.fetchImpl, maxMessageLength: normalized.maxMessageLength });
  const element = doc.createElement("warp-floating-widget");
  element.configure(normalized, client, environment);
  return element.controller;
}

export function createWarpWidgetGlobal(environment = {}) {
  let instance = null;
  return {
    init(config = {}) {
      if (instance && !instance.getState().destroyed) return instance;
      instance = createFloatingWidget(config, environment);
      instance.mount();
      return instance;
    },
    open() { instance?.open(); return instance?.getState() || null; },
    expand() { instance?.expand(); return instance?.getState() || null; },
    minimize() { instance?.minimize(); return instance?.getState() || null; },
    close() { instance?.close(); return instance?.getState() || null; },
    destroy() { instance?.destroy(); instance = null; },
    getState() { return instance?.getState() || { mounted: false, destroyed: true }; },
  };
}

export function registerWarpWidgetElement(customElementsRegistry) {
  if (!customElementsRegistry || customElementsRegistry.get?.("warp-floating-widget")) return;
  const BaseElement = typeof HTMLElement === "function" ? HTMLElement : class {};

  customElementsRegistry.define("warp-floating-widget", class WarpFloatingWidgetElement extends BaseElement {
    configure(config, client, environment = {}) {
      this.config = config;
      this.client = client;
      this.environment = environment;
      this.state = { mounted: false, mode: WIDGET_MODES.CLOSED, minimized: false, destroyed: false, clientState: client.getState(), events: [] };
      this.controller = createController(this);
      this.unsubscribe = client.subscribe((clientState) => {
        this.state.clientState = clientState;
        this.render();
      });
      this.attachShadow({ mode: "open" });
      this.render();
    }

    connectedCallback() {
      this.state.mounted = true;
      this.render();
    }

    disconnectedCallback() {
      this.unsubscribe?.();
    }

    render() {
      if (!this.shadowRoot || !this.config || this.state.destroyed) return;
      const clientState = this.client.getState();
      const isVisible = this.state.mode !== WIDGET_MODES.CLOSED && !this.state.minimized;
      const isExpanded = this.state.mode === WIDGET_MODES.EXPANDED;
      const status = clientState.status;
      // Every render rebuilds the panel (innerHTML), which resets the message list to the top and
      // drops focus. Capture both first and restore them after the rebuild.
      const viewState = captureViewState(this.shadowRoot);

      this.shadowRoot.innerHTML = `
        <style>${createStyles(this.config)}</style>
        <div class="warp-widget ${this.config.position} ${isExpanded ? "expanded" : ""}">
          <button class="launcher" type="button" aria-label="${escapeAttribute(this.config.launcherLabel)}">
            <span>W</span><strong>${escapeHtml(this.config.launcherLabel)}</strong>
          </button>
          <section class="panel ${isVisible ? "open" : ""}" aria-label="${escapeAttribute(this.config.title)}">
            <header>
              <div><strong>${escapeHtml(this.config.title)}</strong><span>${escapeHtml(this.config.subtitle)}</span></div>
              ${clientState.messages.length ? `<button class="new-conversation" type="button" ${status === CHAT_CLIENT_STATUSES.SENDING || status === CHAT_CLIENT_STATUSES.LOADING_MORE ? "disabled" : ""}>Nueva conversación</button>` : ""}
              <button class="expand" type="button" aria-label="${isExpanded ? "Reducir" : "Ampliar"}">${isExpanded ? "⤡" : "⤢"}</button>
              <button class="minimize" type="button" aria-label="Minimizar">_</button>
              <button class="close" type="button" aria-label="Cerrar">x</button>
            </header>
            <div class="messages" role="log" aria-live="polite">
              ${clientState.messages.length ? renderMessages(clientState) : `<p class="empty">¿En qué te puedo ayudar?</p>`}
            </div>
            ${createStatus(status, clientState.error, clientState.retryAfterMs)}
            <form class="compose">
              <textarea maxlength="${this.config.maxMessageLength}" placeholder="${escapeAttribute(this.config.placeholder)}">${escapeHtml(clientState.draftText || "")}</textarea>
              <button type="submit" ${status === CHAT_CLIENT_STATUSES.SENDING ? "disabled" : ""}>Enviar</button>
            </form>
          </section>
        </div>
      `;
      this.bindEvents();
      restoreViewState(this.shadowRoot, viewState);
    }

    bindEvents() {
      const root = this.shadowRoot;
      root.querySelector(".launcher")?.addEventListener("click", () => this.controller.open());
      root.querySelector(".close")?.addEventListener("click", () => this.controller.close());
      root.querySelector(".minimize")?.addEventListener("click", () => this.controller.minimize());
      // 0.7.3 -- explicit "start over": a clean conversation, nothing reconstructed from old state.
      root.querySelector(".new-conversation")?.addEventListener("click", () => this.client.startNewConversation());
      // "Ver más" mission -- one delegated listener on the messages container (re-attached on every
      // render, same as every other binding here) rather than one per button -- a double click on
      // the SAME rendered button still only ever sends one loadMore(id) per real click event; the
      // idempotency of a genuine double-click is chatClient.js's own busy-state guard plus the
      // server's own CAS, never something this listener needs to re-implement.
      root.querySelector(".messages")?.addEventListener("click", (event) => {
        // Explicit-query mission (2026-10-06) -- open / retry-options / cancel of a query form.
        const queryControl = event.target.closest?.("[data-query-open], [data-query-retry], [data-query-cancel]");
        if (queryControl) {
          const query = findQueryAction(this.client.getState(), queryControl.getAttribute("data-query-open") || queryControl.getAttribute("data-query-retry") || queryControl.getAttribute("data-query-cancel"));
          if (!query) return;
          if (queryControl.hasAttribute("data-query-cancel")) this.client.closeQueryForm(query.id);
          else if (queryControl.hasAttribute("data-query-retry")) this.client.loadQueryOptions(query);
          else this.client.openQueryForm(query);
          return;
        }
        // "Selección de elemento real" mission -- `.selectable` (a real catalog item) uses the
        // EXACT SAME generic loadMore(actionId) call as `.load-more` -- the mechanism is identical
        // regardless of kind; only which element can trigger it is new.
        // A card's "Más detalles" section only expands/collapses (native <details>); it never selects
        // the card it lives in (0.7.1 fix: in 0.7.0 opening the details also consumed the select action).
        if (event.target.closest?.(".card-more")) return;
        const target = event.target.closest?.(".load-more, .selectable");
        if (!target) return;
        const actionId = target.getAttribute("data-action-id");
        if (actionId) this.client.loadMore(actionId);
      });
      // Keyboard activation for `.selectable` (role="button") -- same action, same mechanism.
      root.querySelector(".messages")?.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        if (event.target.closest?.(".card-more")) return;
        const target = event.target.closest?.(".selectable");
        if (!target) return;
        event.preventDefault();
        const actionId = target.getAttribute("data-action-id");
        if (actionId) this.client.loadMore(actionId);
      });
      // Typed values are stored silently (no re-render, so focus is never lost); submit sends them.
      (typeof root.querySelectorAll === "function" ? [...root.querySelectorAll(".query-form")] : []).forEach((formElement) => {
        const queryId = formElement.getAttribute("data-query-id");
        formElement.addEventListener("input", (event) => {
          const name = event.target.getAttribute?.("name");
          if (name) this.client.setQueryValue(queryId, name, event.target.type === "checkbox" ? event.target.checked : event.target.value);
        });
        formElement.addEventListener("change", (event) => {
          const name = event.target.getAttribute?.("name");
          if (name) this.client.setQueryValue(queryId, name, event.target.type === "checkbox" ? event.target.checked : event.target.value);
        });
        formElement.addEventListener("submit", (event) => {
          event.preventDefault();
          event.stopPropagation();
          const query = findQueryAction(this.client.getState(), queryId);
          if (query) this.client.submitQuery(query);
        });
      });
      root.querySelector(".expand")?.addEventListener("click", () => {
        if (this.state.mode === WIDGET_MODES.EXPANDED) this.controller.open();
        else this.controller.expand();
      });
      const textarea = root.querySelector("textarea");
      textarea?.addEventListener("input", (event) => this.client.setDraftText(event.target.value));
      root.querySelector("form.compose")?.addEventListener("submit", (event) => {
        event.preventDefault();
        const value = textarea?.value || "";
        this.client.send(value);
      });
      textarea?.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && !event.shiftKey) {
          event.preventDefault();
          root.querySelector("form.compose")?.requestSubmit();
        }
      });
    }
  });
}

// Within this distance of the bottom, the person counts as "at the end" and keeps following new
// content; anywhere above it, they are reading earlier messages and their position is kept.
const FOLLOW_BOTTOM_THRESHOLD_PX = 24;

// Snapshot of what a rebuild would lose: the message list's scroll position (and whether it was at
// the end), and which field had focus (compose textarea, or a query form field by form id + name)
// with its caret. Never reads or stores field values -- those already live in chatClient's state.
function captureViewState(root) {
  const messages = typeof root?.querySelector === "function" ? root.querySelector(".messages") : null;
  const view = { hadMessages: false, atBottom: true, scrollTop: 0, focus: null };
  if (messages && typeof messages.scrollTop === "number") {
    view.hadMessages = messages.scrollHeight > 0;
    view.scrollTop = messages.scrollTop;
    view.atBottom = messages.scrollHeight - messages.scrollTop - messages.clientHeight <= FOLLOW_BOTTOM_THRESHOLD_PX;
  }
  const active = root?.activeElement;
  if (active && typeof active.getAttribute === "function") {
    const queryForm = active.closest?.(".query-form");
    const caret = typeof active.selectionStart === "number" ? { start: active.selectionStart, end: active.selectionEnd } : null;
    if (queryForm && active.getAttribute("name")) {
      view.focus = { kind: "query", formId: queryForm.getAttribute("data-query-id"), name: active.getAttribute("name"), caret };
    } else if (active.tagName === "TEXTAREA" && active.closest?.("form.compose")) {
      view.focus = { kind: "compose", caret };
    }
  }
  return view;
}

function restoreViewState(root, view) {
  if (!view || typeof root?.querySelector !== "function") return;
  const messages = root.querySelector(".messages");
  if (messages && typeof messages.scrollTop === "number") {
    // First render with content, or the person was at the end: follow the newest content.
    messages.scrollTop = !view.hadMessages || view.atBottom ? messages.scrollHeight : view.scrollTop;
  }
  if (!view.focus) return;
  let target = null;
  if (view.focus.kind === "compose") {
    target = root.querySelector("form.compose textarea");
  } else if (typeof root.querySelectorAll === "function") {
    const form = [...root.querySelectorAll(".query-form")].find((element) => element.getAttribute("data-query-id") === view.focus.formId);
    target = form ? [...form.querySelectorAll("[name]")].find((element) => element.getAttribute("name") === view.focus.name) : null;
  }
  if (!target || typeof target.focus !== "function" || target.disabled) return;
  target.focus({ preventScroll: true });
  if (view.focus.caret && typeof target.setSelectionRange === "function") {
    try {
      target.setSelectionRange(view.focus.caret.start, view.focus.caret.end);
    } catch {
      // Some input types (e.g. number) do not support selection ranges -- focus alone is enough.
    }
  }
}

function createController(element) {
  function setMode(mode, eventName) {
    element.state.mode = mode;
    element.state.minimized = false;
    element.state.events = [{ eventName, timestamp: new Date().toISOString() }, ...element.state.events].slice(0, 12);
    element.render();
  }
  return {
    mount() {
      const doc = element.environment.document || (typeof document !== "undefined" ? document : null);
      if (!element.isConnected) doc?.body?.appendChild(element);
      element.state.mounted = true;
      element.render();
      return this;
    },
    open() { setMode(WIDGET_MODES.WINDOW, WIDGET_EVENTS.OPENED); },
    expand() { setMode(WIDGET_MODES.EXPANDED, WIDGET_EVENTS.EXPANDED); },
    close() { setMode(WIDGET_MODES.CLOSED, WIDGET_EVENTS.CLOSED); },
    // Minimizing NEVER changes `mode` (window vs. expanded) or touches the client's conversation/
    // draft state -- only the visual `minimized` flag flips, so restoring returns to exactly the
    // same mode and the same conversation/draft the person left.
    minimize() {
      element.state.minimized = true;
      element.state.events = [{ eventName: WIDGET_EVENTS.MINIMIZED, timestamp: new Date().toISOString() }, ...element.state.events].slice(0, 12);
      element.render();
    },
    destroy() {
      element.client.destroy?.();
      element.unsubscribe?.();
      element.state.destroyed = true;
      element.state.events = [{ eventName: WIDGET_EVENTS.DESTROYED, timestamp: new Date().toISOString() }, ...element.state.events].slice(0, 12);
      element.remove?.();
    },
    getState() {
      return { ...element.state, clientState: element.client.getState() };
    },
  };
}

function createUnavailableWidget() {
  return {
    mount: () => null, open: () => null, expand: () => null, minimize: () => null, close: () => null, destroy: () => null,
    getState: () => ({ mounted: false, destroyed: true, unavailable: true }),
  };
}

function createStyles(config) {
  return `
    :host { all: initial; font-family: Arial, Helvetica, sans-serif; }
    * { box-sizing: border-box; }
    .warp-widget { position: fixed; z-index: 2147483000; bottom: 22px; color: #10201d; }
    .bottom-right { right: 22px; } .bottom-left { left: 22px; }
    .launcher { display: inline-flex; align-items: center; gap: 8px; min-height: 48px; border: 0; border-radius: 999px; padding: 0 16px; background: ${config.primaryColor}; color: #fff; cursor: pointer; box-shadow: 0 18px 45px rgba(0,0,0,.18); font: 700 14px Arial; }
    .launcher span { display: grid; place-items: center; width: 26px; height: 26px; border-radius: 999px; background: rgba(255,255,255,.18); }
    .panel { display: none; width: min(360px, calc(100vw - 32px)); max-height: min(680px, calc(100vh - 120px)); margin-bottom: 12px; border: 1px solid rgba(0,0,0,.08); border-radius: 20px; background: #fff; box-shadow: 0 26px 80px rgba(0,0,0,.22); overflow: hidden; }
    .expanded .panel { width: min(720px, calc(100vw - 32px)); max-height: min(860px, calc(100vh - 60px)); }
    .panel.open { display: grid; grid-template-rows: auto minmax(180px, 1fr) auto auto; }
    header { display: flex; align-items: center; gap: 8px; padding: 14px; background: ${config.primaryColor}; color: #fff; }
    header div { flex: 1; min-width: 0; } header strong, header span { display: block; } header span { opacity: .8; font-size: 12px; }
    header button { width: 30px; height: 30px; border: 0; border-radius: 999px; background: rgba(255,255,255,.14); color: #fff; cursor: pointer; }
    .messages { display: grid; align-content: start; gap: 10px; padding: 14px; overflow: auto; }
    .empty { margin: 0; color: #52615d; font: 14px/1.45 Arial; }
    .message { max-width: 88%; padding: 10px 12px; border-radius: 14px; font: 14px/1.4 Arial; white-space: pre-wrap; }
    .user { justify-self: end; background: ${config.primaryColor}; color: #fff; }
    .assistant { justify-self: start; background: ${config.accentColor}; color: #10201d; }
    .message.result { justify-self: start; max-width: 100%; background: transparent; padding: 0; }
    .message.notice { justify-self: stretch; max-width: 100%; background: #fff7e0; color: #5c4a12; border: 1px solid #f0dca0; font-size: 13px; }
    header button.new-conversation { width: auto; padding: 0 10px; font: 700 12px Arial; }
    header button.new-conversation:disabled { opacity: .5; cursor: default; }
    .result-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
    .result-item { border: 1px solid rgba(0,0,0,.1); border-radius: 10px; padding: 8px 10px; background: #fff; font: 13px/1.35 Arial; display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
    .result-item.selectable { cursor: pointer; align-items: center; justify-content: space-between; }
    .result-item.selectable:hover, .result-item.selectable:focus-visible { border-color: ${config.primaryColor}; outline: none; }
    .select-hint { margin-left: auto; color: ${config.primaryColor}; font-weight: 700; font-size: 12px; white-space: nowrap; }
    .chip { background: ${config.accentColor}; border-radius: 999px; padding: 2px 8px; font-size: 12px; }
    .chip b { font-weight: 700; margin-right: 4px; text-transform: capitalize; }
    .result-item.card { flex-direction: column; align-items: stretch; gap: 3px; }
    .result-item.card.selectable { flex-direction: column; align-items: stretch; }
    .result-item.card .select-hint { margin-left: 0; align-self: flex-end; }
    .card-title { font: 700 14px/1.3 Arial; color: #10201d; }
    .card-detail { color: #33433f; font-size: 13px; }
    .card-more summary { cursor: pointer; color: ${config.primaryColor}; font: 700 12px Arial; }
    .card-more-body { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
    .result-time { margin: 4px 0 0; color: #6b7b77; font: 11px/1.3 Arial; }
    .load-more { margin-top: 8px; border: 1px solid ${config.primaryColor}; border-radius: 999px; padding: 8px 14px; background: #fff; color: ${config.primaryColor}; cursor: pointer; font: 700 13px Arial; }
    .query-form { display: grid; gap: 8px; margin-top: 8px; padding: 10px; border: 1px solid rgba(0,0,0,.12); border-radius: 12px; background: #fff; }
    .query-field { display: grid; gap: 3px; font: 12px/1.35 Arial; }
    .query-field span { font-weight: 700; }
    .query-field input, .query-field select { border: 1px solid rgba(0,0,0,.18); border-radius: 8px; padding: 6px 8px; font: 13px Arial; }
    .query-field small { color: #52615d; } .query-field small.muted { font-style: italic; }
    .query-field em { color: #a3261b; font-style: normal; }
    .query-field small.zone { color: #52615d; }
    .query-note { margin: 0; color: #52615d; font: 12px Arial; }
    .query-error { margin: 0; color: #a3261b; font: 12px/1.35 Arial; }
    .query-buttons { display: flex; gap: 8px; align-items: center; }
    .query-buttons button[type=submit] { border: 0; border-radius: 999px; padding: 8px 14px; background: ${config.primaryColor}; color: #fff; cursor: pointer; font: 700 13px Arial; }
    .query-buttons button[disabled] { opacity: .5; cursor: not-allowed; }
    .link { border: 0; background: none; color: ${config.primaryColor}; cursor: pointer; font: 700 12px Arial; padding: 0; }
    .status { margin: 0 14px 12px; padding: 10px; border-radius: 14px; background: #f5f7f6; color: #52615d; font: 13px/1.35 Arial; }
    form.compose { display: grid; grid-template-columns: 1fr auto; gap: 8px; padding: 14px; border-top: 1px solid rgba(0,0,0,.08); }
    textarea { width: 100%; min-height: 44px; max-height: 120px; resize: vertical; border: 1px solid rgba(0,0,0,.14); border-radius: 14px; padding: 10px; font: 14px Arial; }
    form.compose button { border: 0; border-radius: 999px; padding: 9px 12px; cursor: pointer; font: 700 13px Arial; background: ${config.primaryColor}; color: #fff; }
    @media (max-width: 520px) { .warp-widget { left: 16px; right: 16px; bottom: 16px; } .panel, .expanded .panel { width: 100%; } .launcher { width: 100%; justify-content: center; } }
  `;
}

// "Ver más" mission -- `role:"result"` carries the real, raw items Warp's action endpoint returned
// (chatClient.js's loadMore), never text a model wrote. This renders them GENERICALLY: whatever
// primitive-valued top-level fields an item has become label:value chips, in their own given order --
// never a guess at which field is "the title" or "the price", never a vertical vocabulary hardcoded
// here ("no adivines campos ni metas nombres de vehículos en el SDK"). A site that wants a richer,
// domain-specific presentation renders `client.getState().messages` itself instead of this widget.
function createResultItem(item, presentation = null) {
  const content = createResultItemContent(item, presentation);
  return content ? `<li class="${content.className}">${content.inner}</li>` : "";
}

// Result presentation hints (2026-11-03) -- when the SITE's own contract annotates its fields
// (`x-presentation` roles relayed by Warp: title / detail / hidden, plus a human `label`), an item
// becomes a readable card: title, short details, and everything else behind "Más detalles". Still no
// vertical vocabulary here: which field is the title is the site's decision, never this widget's.
// Without hints, exactly the previous generic chip row.
// Dates (0.7.2). Priority:
//   1. The site DECLARED the field as `format: "date-time"` (relayed as `fields[key].format`), with
//      an IANA zone (`fields[key].timeZone`, from the site's `x-timezone`): shown in THAT zone.
//   2. Declared date-time without a zone: shown in the viewer's own zone (compatibility fallback).
//   3. Not declared, but the value is a full ISO-8601 instant WITH an explicit offset (unambiguous
//      by value alone, never by field name): same viewer-zone fallback, kept only for sites that
//      have not declared their dates yet.
// Anything else (plain dates, other strings) is unchanged.
const ISO_INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,6})?)?(Z|[+-]\d{2}:\d{2})$/;
function formatInstant(value, timeZone = null) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  try {
    return new Intl.DateTimeFormat("es-CL", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", ...(timeZone ? { timeZone } : {}) }).format(date);
  } catch {
    try {
      return new Intl.DateTimeFormat("es-CL", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(date);
    } catch {
      return value;
    }
  }
}
function presentedValue(value, meta = null) {
  if (typeof value === "string" && meta?.format === "date-time") return formatInstant(value, typeof meta.timeZone === "string" ? meta.timeZone : null);
  if (typeof value === "string" && ISO_INSTANT.test(value)) return formatInstant(value);
  if (typeof value === "boolean") return value ? "Sí" : "No";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value) && value.length > 0 && value.every((entry) => typeof entry === "string" || typeof entry === "number")) return value.join(", ");
  return null;
}
function createResultItemContent(item, presentation) {
  if (!item || typeof item !== "object") return null;
  const fields = presentation?.fields && typeof presentation.fields === "object" ? presentation.fields : null;
  if (!fields) {
    const chips = Object.entries(item)
      .filter(([, value]) => typeof value === "string" || typeof value === "number" || typeof value === "boolean")
      .map(([key, value]) => `<span class="chip"><b>${escapeHtml(key)}</b>${escapeHtml(String(value))}</span>`)
      .join("");
    return { className: "result-item", inner: chips || escapeHtml(JSON.stringify(item)).slice(0, 200) };
  }
  const roleOf = (key) => fields[key]?.role || "more";
  const labelOf = (key) => (typeof fields[key]?.label === "string" && fields[key].label) || key;
  const withRole = (role) => Object.entries(item).filter(([key]) => roleOf(key) === role).map(([key, value]) => [key, presentedValue(value, fields[key])]).filter(([, value]) => value);
  const title = withRole("title").map(([, value]) => value).join(" · ");
  const details = withRole("detail").map(([key, value]) => `<span class="card-detail">${fields[key]?.label ? `<b>${escapeHtml(fields[key].label)}:</b> ` : ""}${escapeHtml(value)}</span>`).join("");
  const more = withRole("more").map(([key, value]) => `<span class="chip"><b>${escapeHtml(labelOf(key))}</b>${escapeHtml(value)}</span>`).join("");
  const inner = `${title ? `<strong class="card-title">${escapeHtml(title)}</strong>` : ""}${details}${more ? `<details class="card-more"><summary>Más detalles</summary><div class="card-more-body">${more}</div></details>` : ""}`;
  return { className: "result-item card", inner: inner || escapeHtml(JSON.stringify(item)).slice(0, 200) };
}

// "Actualizar consulta" / "Selección de elemento real" missions -- the label is chosen from the
// action's own `kind` (a generic, engine-level concept -- never a Renacar-specific word). Still no
// vertical vocabulary: a site that wants a domain-specific label ("Ver más vehículos") renders its
// own UI against chatClient.js directly instead.
const ACTION_KIND_LABELS = Object.freeze({
  refresh: "Actualizar consulta",
  select: "Seleccionar",
  clear_selection: "Quitar selección",
});
function createActionButton(action) {
  if (!action?.id) return "";
  const label = ACTION_KIND_LABELS[action.kind] || "Ver más";
  return `<button type="button" class="load-more" data-action-id="${escapeAttribute(action.id)}">${label}</button>`;
}

// "Selección de elemento real" mission -- one real, selectable item per `select` action, rendered
// with the EXACT SAME generic chip renderer every other item already uses (createResultItem below)
// -- a selectable item looks like any other item, plus a clickable affordance, never a different
// vocabulary. `data-action-id` is the only thing a click needs; the item's own real fields are shown
// exactly as the capability returned them.
function createSelectableItem(action, presentation = null) {
  if (!action?.id) return "";
  const content = createResultItemContent(action.item, presentation);
  const className = content?.className === "result-item card" ? "result-item card selectable" : "result-item selectable";
  return `<li class="${className}" data-action-id="${escapeAttribute(action.id)}" role="button" tabindex="0">${content?.inner || ""}<span class="select-hint">Seleccionar</span></li>`;
}

// `itemActions`, when present, is a SEPARATE block of real, clickable options rendered alongside
// (never instead of) whatever `action` already renders via createActionButton -- a message can
// genuinely offer both a primary action (e.g. "Ver más", if a further page also exists) AND a set of
// real items to choose from, independently.
function createSelectableItemsBlock(itemActions, presentation = null) {
  if (!Array.isArray(itemActions) || itemActions.length === 0) return "";
  return `<ul class="result-list selectable-list">${itemActions.map((action) => createSelectableItem(action, presentation)).join("")}</ul>`;
}

// A short, locale-formatted time for when THIS result was actually obtained -- never invented, and
// never applied to any OTHER message (each result message carries and displays its own).
function createResultTimestamp(obtainedAt) {
  if (!obtainedAt) return "";
  const date = new Date(obtainedAt);
  if (Number.isNaN(date.getTime())) return "";
  let formatted;
  try {
    formatted = date.toLocaleTimeString();
  } catch {
    formatted = date.toISOString();
  }
  return `<p class="result-time">Obtenido: ${escapeHtml(formatted)}</p>`;
}

// "Actualizar consulta" mission -- `message.data` (the capability's real, raw result) renders
// GENERICALLY, same posture as createResultItem below: a list-shaped result (`data.items` is an
// array -- "Ver más"'s own shape, unchanged) becomes the existing chip-per-item list; any other
// real, structured object result (e.g. availability.check's flat status/message/eligibleUnitCount)
// becomes ONE chip row via the exact same generic renderer, reused rather than duplicated -- never a
// translator written specifically for one capability's field names.
function createResultBody(message) {
  // `message.items` (pre-existing field, always an array) takes precedence for full backward
  // compatibility with anything already constructing a result message that way; `data.items` is the
  // same shape read from the fuller raw payload when only `data` is present.
  const listItems = Array.isArray(message?.items) ? message.items : (Array.isArray(message?.data?.items) ? message.data.items : null);
  if (listItems) {
    return `<ul class="result-list">${listItems.map((item) => createResultItem(item, message.presentation)).join("")}</ul>`;
  }
  // 0.7.2: a detail read wrapped in an envelope (`{ ok, <object> }`) -- the site's annotations say
  // which inner object is the thing to show (`presentation.itemPath`, set by Warp). When that object
  // is absent (e.g. not found), a short honest line instead of raw envelope fields.
  const itemPath = typeof message?.presentation?.itemPath === "string" ? message.presentation.itemPath : null;
  if (itemPath && message?.data && typeof message.data === "object") {
    const inner = message.data[itemPath];
    return inner && typeof inner === "object" && !Array.isArray(inner)
      ? `<ul class="result-list">${createResultItem(inner, message.presentation)}</ul>`
      : `<ul class="result-list"><li class="result-item">No se encontró información para mostrar.</li></ul>`;
  }
  if (message?.data && typeof message.data === "object") {
    return `<ul class="result-list">${createResultItem(message.data, message.presentation)}</ul>`;
  }
  return `<ul class="result-list"></ul>`;
}

// Explicit-query mission (2026-10-06) -- only the MOST RECENT query offered per capability is
// rendered: an older one belongs to an element that is no longer the current selection (the server
// would refuse it anyway), so it is never shown as something to fill in.
function renderMessages(clientState) {
  const latestQueryByCapability = new Map();
  clientState.messages.forEach((message, index) => {
    for (const query of message.queryActions || []) latestQueryByCapability.set(query.capability, { index, id: query.id });
  });
  return clientState.messages.map((message, index) => {
    const queries = (message.queryActions || []).filter((query) => latestQueryByCapability.get(query.capability)?.index === index);
    return createMessage(message, queries.map((query) => createQueryBlock(query, clientState.queryForms?.[query.id])).join(""));
  }).join("");
}

function findQueryAction(clientState, queryId) {
  for (const message of clientState.messages || []) {
    for (const query of message.queryActions || []) if (query.id === queryId) return query;
  }
  return null;
}

// The form is built ONLY from the real schema fields the server sent (name/type/description/
// format/enum/options) -- never a site's vocabulary. A closed-list field is a <select> filled with
// the loaded options (never free text); while they load, or if loading failed, submit is disabled.
function createQueryBlock(query, form) {
  if (!form?.open) {
    return `<button type="button" class="load-more" data-query-open="${escapeAttribute(query.id)}">Consultar</button>`;
  }
  const optionsBlocked = Boolean(query.optionsActionId) && form.optionsStatus !== "ready";
  const disabled = optionsBlocked || form.submitting || form.final;
  const fields = (query.requiredFields || []).map((field) => createQueryField(field, form)).join("");
  const optionsNotice = form.optionsStatus === "loading"
    ? `<p class="query-note">Cargando opciones...</p>`
    : (form.optionsStatus === "error" ? `<p class="query-error">${escapeHtml(form.error || "No se pudieron cargar las opciones.")} <button type="button" class="link" data-query-retry="${escapeAttribute(query.id)}">Reintentar</button></p>` : "");
  const errorNotice = form.error && form.optionsStatus !== "error" ? `<p class="query-error">${escapeHtml(form.error)}</p>` : "";
  return `<form class="query-form" data-query-id="${escapeAttribute(query.id)}" novalidate>
    ${fields}${optionsNotice}${errorNotice}
    <div class="query-buttons">
      <button type="submit" ${disabled ? "disabled" : ""}>${form.submitting ? "Consultando..." : "Consultar"}</button>
      <button type="button" class="link" data-query-cancel="${escapeAttribute(query.id)}">Cerrar</button>
    </div>
  </form>`;
}

function createQueryField(field, form) {
  const name = String(field.name || "");
  const value = form.values?.[name];
  const error = form.fieldErrors?.[name];
  // Label and help come only from the site's contract: `title` (else the technical name, as
  // before), the short `help` (else the description, but only when no title was declared -- a
  // contract that gives a human title keeps its technical description out of the customer's view).
  const label = field.title || name;
  const helpText = field.help || (field.title ? null : field.description);
  const description = helpText ? `<small>${escapeHtml(helpText)}</small>` : (field.title ? "" : `<small class="muted">El sitio no describió este campo.</small>`);
  let input;
  const choices = field.options ? (form.options?.[name] || null) : (Array.isArray(field.enum) ? field.enum.map((item) => ({ value: String(item), label: String(item) })) : null);
  if (field.options || choices) {
    const list = choices || [];
    input = `<select name="${escapeAttribute(name)}" ${field.options && form.optionsStatus !== "ready" ? "disabled" : ""}>
      <option value="">Selecciona...</option>
      ${list.map((option) => `<option value="${escapeAttribute(option.value)}" ${String(value ?? "") === option.value ? "selected" : ""}>${escapeHtml(option.label)}</option>`).join("")}
    </select>`;
  } else if (field.type === "boolean") {
    input = `<input type="checkbox" name="${escapeAttribute(name)}" ${value ? "checked" : ""}>`;
  } else if (field.type === "number" || field.type === "integer") {
    input = `<input type="number" name="${escapeAttribute(name)}" value="${escapeAttribute(value ?? "")}">`;
  } else if (field.format === "date-time" && field.timeZone) {
    // Native date + time picker: the value is the wall-clock time the person chose. It is NOT
    // converted here (the visitor's own zone is irrelevant); Warp converts it in the zone the
    // site declared, which is shown under the field.
    input = `<input type="datetime-local" name="${escapeAttribute(name)}" value="${escapeAttribute(isLocalDateTimeValue(value) ? value : "")}" step="60">
      <small class="zone">Hora de ${escapeHtml(describeTimeZone(field.timeZone))}</small>`;
  } else {
    const placeholder = field.format === "date-time" ? "AAAA-MM-DDThh:mm:ss±hh:mm" : "";
    input = `<input type="text" name="${escapeAttribute(name)}" value="${escapeAttribute(value ?? "")}" placeholder="${escapeAttribute(placeholder)}" autocomplete="off">`;
  }
  return `<label class="query-field"><span>${escapeHtml(label)}</span>${input}${description}${error ? `<em>${escapeHtml(error)}</em>` : ""}</label>`;
}

function isLocalDateTimeValue(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/.test(value);
}

// "Chile (America/Santiago)": the zone the site declared, named for the person when the platform
// can (Intl), always with its IANA id so it is unambiguous. Display only, never used to convert.
function describeTimeZone(timeZone) {
  try {
    const part = new Intl.DateTimeFormat("es", { timeZone, timeZoneName: "longGeneric" }).formatToParts(new Date()).find((item) => item.type === "timeZoneName");
    const human = part?.value ? part.value.replace(/^hora (de |del )?/i, "") : "";
    return human && human !== timeZone ? `${human} (${timeZone})` : timeZone;
  } catch {
    return timeZone;
  }
}

function createMessage(message, queryBlocks = "") {
  if (message.role === "result") {
    // 0.7.2: a list page whose items are ALSO offered as selectable cards shows them once (the
    // selectable cards), never the same card twice. A page without select actions is unchanged.
    const selectable = Array.isArray(message.itemActions) && message.itemActions.length > 0 && Array.isArray(message.items ?? message.data?.items);
    const body = selectable ? "" : createResultBody(message);
    return `<div class="message result">${body}${createResultTimestamp(message.obtainedAt)}${createSelectableItemsBlock(message.itemActions, message.presentation)}${createActionButton(message.action)}${queryBlocks}</div>`;
  }
  if (message.role === "notice") {
    // 0.7.3 -- lost-context notice (chatClient.js LOST_CONTEXT_NOTICE): plain text, no actions.
    return `<div class="message notice" role="status">${escapeHtml(message.text || "")}</div>`;
  }
  const role = message.role === "user" ? "user" : "assistant";
  return `<div class="message ${role}">${escapeHtml(message.text || "")}${role === "assistant" ? `${createSelectableItemsBlock(message.itemActions, message.itemPresentation)}${createActionButton(message.action)}` : ""}</div>`;
}

function createStatus(status, error, retryAfterMs) {
  if (status === CHAT_CLIENT_STATUSES.SENDING) return `<p class="status">Warp está escribiendo...</p>`;
  // "Ver más" / "Actualizar consulta" mission -- a distinct, recoverable loading/error affordance
  // for advancing a page OR refreshing a query, never reusing the "Warp está escribiendo" copy (no
  // model is involved in this call). Neutral wording on purpose: this same status covers both
  // action kinds, and the widget has no vertical vocabulary to say which one is in flight.
  if (status === CHAT_CLIENT_STATUSES.LOADING_MORE) return `<p class="status">Procesando...</p>`;
  if (status === CHAT_CLIENT_STATUSES.RATE_LIMITED) {
    const seconds = retryAfterMs ? Math.ceil(retryAfterMs / 1000) : null;
    return `<p class="status">Has enviado varios mensajes en poco tiempo.${seconds ? ` Intenta de nuevo en ${seconds}s.` : ""}</p>`;
  }
  if (error?.message) return `<p class="status">${escapeHtml(error.message)}</p>`;
  return "";
}

function escapeHtml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function escapeAttribute(value) {
  return escapeHtml(value).replace(/`/g, "");
}
