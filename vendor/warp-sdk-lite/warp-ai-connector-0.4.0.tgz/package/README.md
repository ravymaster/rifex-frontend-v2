# @warp-ai/connector

Discovery manifest generator and read-only capability invocation bridge for a site's own backend.

**V1 scope: read-only.** Registering anything shaped like a write (`operationType: "write"`, `sideEffects: true`, `confirmationRequired: true`, `mutating`/`write` truthy) throws immediately — it is never silently accepted or downgraded.

No dependency on Warp Core or the full `warp-ai-engine` repo. The Discovery manifest contract (`warp.discovery_manifest.v1`) and the schema-validation rules are extracted copies of the real, already-certified logic in that repo (see `docs/handover/RENACAR_DISCOVERY_COMPATIBILITY_AUDIT.md` and `DISCOVERY_SOURCE_REGISTRY_V1_ENTREGA.md`), not a reimplementation from scratch.

## Usage

```js
import { createConnector } from "@warp-ai/connector";

const connector = createConnector({
  platform: { id: "my-site", name: "My Site" },
});

connector.capability({
  id: "vehicle.list",
  description: "Lists vehicles available for reservation.",
  inputSchema: { type: "object", properties: { locationId: { type: "string" } }, required: [], additionalProperties: false },
  outputSchema: { type: "object", properties: { items: { type: "array", items: { type: "object", properties: {}, required: [], additionalProperties: false } } }, required: ["items"], additionalProperties: false },
  handler: async ({ locationId }) => ({ items: await myRealVehicleLookup(locationId) }),
});

// app/api/v1/discovery/route.js -- this EXACT path, never a different one. Warp AI Engine's own
// discovery client fetches a registered source's manifest at a fixed "/api/v1/discovery" (the
// same convention Warp Core itself uses), never wherever a site happens to mount it.
export const GET = connector.createDiscoveryRouteHandler();

// app/api/warp/capabilities/[capabilityId]/route.js -- capability paths have no such constraint;
// Warp reads each one directly from the manifest's own invocation.path, never assumes a location.
export const GET = connector.createCapabilityRouteHandler();
```

## Closed-list fields (`enum`)

A schema leaf (string/number/integer/boolean) may declare a real, closed `enum` — the only values that field genuinely accepts:

```js
inputSchema: {
  type: "object",
  properties: {
    category: { type: "string", enum: ["citycar", "sedan", "suv", "pickup", "van"] },
  },
  required: [],
  additionalProperties: false,
}
```

An invocation with a value outside the declared `enum` is rejected with `INVALID_ARGUMENTS` (`error.details[].code === "ENUM_MISMATCH"`) **before your handler ever runs** — never silently accepted and forwarded unfiltered. `enum` is only valid on a primitive field (not `object`/`array`), must be a non-empty array with no duplicates, and every member must match the field's own declared `type` — a malformed `enum` fails at `connector.capability(...)` registration time, not at first invocation.

## HTTP error responses now carry real detail

`error.details` (an array of `{code, path, message}`) is included in the `400` response whenever the failure is a validation problem (`INVALID_ARGUMENTS` — missing required field, wrong type, value out of range, or `enum` mismatch), so a caller can see exactly which field failed and why, not just a generic top-level message. Bounded to 20 entries. A `HANDLER_FAILED` (your own handler threw) deliberately stays generic — your handler's own exception text is never echoed to the public HTTP response.

## Associating this manifest with your siteId

Warp AI Engine now has a real, public endpoint for this (`POST /api/v1/site-sources`, authenticated
only by your own Site API Key, never a Lab credential) — see `@warp-ai/init`'s README for the
`--site-url` flow that calls it for you. This package itself still never calls out to Warp — it
only serves your manifest; associating it is a separate, explicit step.

## What this does NOT do yet

- No write/mutation support.
- No authentication on the routes it generates — add your own middleware if a capability should not be public.
