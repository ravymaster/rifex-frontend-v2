# @warp-ai/connector — Changelog

## 0.4.0 (2026-10-08)

### Added

- **Presentation annotations for forms:** `title` (standard JSON Schema) and `x-help`, both short texts; and **`x-timezone`** (IANA name) on a `format: "date-time"` field, declaring the zone in which a person's chosen date and time are interpreted. Warp converts a wall-clock value to the exact instant in that zone, including daylight-saving changes, and rejects nonexistent or ambiguous times.
- Validated at registration: `x-timezone` must be a valid IANA zone on a string field with `format: "date-time"`; `title` and `x-help` must be non-empty strings (at most 300 characters).

### Compatibility

Fully backward compatible: a schema without these annotations behaves exactly as in 0.3.0. Invocation-time validation is unchanged: `format: "date-time"` still requires an explicit offset, and Warp sends the converted value with its offset.

## 0.3.0 (2026-10-06)

### Added

- **`format: "date-time"`** on string fields (RFC 3339, explicit offset mandatory: `Z` or `±hh:mm`).
  An invocation with a value without offset, or not a real date-time (e.g. `2026-02-30`), is
  rejected (`INVALID_ARGUMENTS`, `error.details[].code === "FORMAT_MISMATCH"`, with the field path)
  before the handler runs. Declaring `format` on a non-string field, or a format this package does
  not enforce, is rejected at `connector.capability(...)` registration — never a check the author
  wrongly believes exists. Generic: never inferred from a field name.

### Compatibility

Fully backward compatible for every capability that does not declare `format`. A site that already
validates offsets itself can keep that as a second layer or retire it.

### Verified

- 27/27 tests (`node --test tests/connector.test.mjs`), 6 new. Note: `npm test` (`node --test
  tests/`) fails on Node 22 with or without this change (directory argument); run the file directly.

## 0.2.0 (2026-09-24)

Both changes are generic — neither mentions Renacar, vehicles, or any specific site's business
vocabulary; found while investigating a real integration, fixed in the shared component, not as a
per-site patch.

### Added

- **`enum` support** on any primitive schema field (string/number/integer/boolean). A capability
  may now declare a real, closed list of the only values a field accepts
  (`{ type: "string", enum: ["citycar", "sedan", "suv", "pickup", "van"] }`); an invocation with a
  value outside that list is rejected (`INVALID_ARGUMENTS`, `error.details[].code === "ENUM_MISMATCH"`)
  before the handler ever runs. A malformed `enum` declaration (empty, duplicate members, a member
  of the wrong type, or `enum` on a non-primitive field) is rejected at `connector.capability(...)`
  registration time, never silently accepted.
  - **Before this version**, the shared schema validator had no concept of `enum` at all — a site
    that needed a closed list of values had to validate it itself, outside the shared contract
    layer, and an unrecognized value would reach the handler unless the site's own code caught it.

### Fixed

- **HTTP error responses now carry real validation detail.** `createCapabilityRouteHandler`'s
  `400` response previously discarded `error.details` (the actual field/path/reason a validation
  failed) when building the JSON body, leaving only a generic top-level message. `error.details`
  (bounded to 20 entries) is now included for `INVALID_ARGUMENTS`. Applies to every capability
  registered through this package (the route handler is shared, not per-capability).
  `HANDLER_FAILED` deliberately stays generic — a site's own handler exception text is still never
  echoed to the public HTTP response, by design, not by omission.

### Compatibility

Fully backward compatible. A capability that never declares `enum` behaves byte-identically to
0.1.2. A caller that never reads `error.details` sees the same `code`/`message` shape as before,
just with an additional, optional field.

### Verified

- 21/21 tests in this package's own suite (`tests/connector.test.mjs`), including 7 new tests for
  both changes above.
- Warp AI Engine's own contract validator (`lib/ai/orchestrator/contractValidator.js`, a separate
  component — see that repo's own changelog/checkpoint for the equivalent fix on Warp's side) was
  checked against this SAME real gap and fixed in parallel; confirmed together against Renacar's
  live Discovery manifest (`vehicles.list.category`, real `enum` published, real rejection of an
  out-of-enum value verified end-to-end against the live tunnel).

## 0.1.2 and earlier

See git history — no changelog was kept before this release.
