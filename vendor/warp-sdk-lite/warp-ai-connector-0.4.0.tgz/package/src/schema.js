// A compact JSON-schema SUBSET validator -- object/array/string/number/integer/boolean/null,
// `required`, `additionalProperties`, `enum`, `format: "date-time"`. Adapted from warp-ai-engine's own
// lib/ai/orchestrator/contractValidator.js (validateArgumentsAgainstSchema) and
// lib/sdk/discovery/discoveryReport.js (validateSchema, for the DEFINITION-time shape check) --
// copied and simplified, not imported, so this package has no dependency on that repo.

const VALID_TYPES = new Set(["object", "array", "string", "number", "integer", "boolean", "null"]);
const MAX_SCHEMA_DEPTH = 6;
const MAX_SCHEMA_PROPERTIES = 40;
const MAX_ENUM_MEMBERS = 100;

// `format` support (shared-fix closure, explicit-query mission 2026-10-06): the standard JSON Schema
// keyword, restricted to the formats this package genuinely ENFORCES. Only "date-time" today --
// RFC 3339 section 5.6, which makes the offset mandatory ("Z" or "+hh:mm"/"-hh:mm"). A value without
// an explicit offset is ambiguous (its meaning would depend on whichever machine parses it), so it is
// rejected before the site's handler ever runs. Generic: never inferred from a field name; only a
// schema that explicitly declares `format: "date-time"` gets this check. Declaring a format this
// package does not enforce is rejected at registration, so an author never believes a check exists
// when it does not.
const SUPPORTED_FORMATS = new Set(["date-time"]);
const RFC3339_DATE_TIME = /^(\d{4})-(\d{2})-(\d{2})[Tt](\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(?:[Zz]|([+-])(\d{2}):(\d{2}))$/;

export function isValidTimeZone(timeZone) {
  if (typeof timeZone !== "string" || !timeZone || timeZone.length > 64) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone }).format(0);
    return true;
  } catch {
    return false;
  }
}

export function isRfc3339DateTime(value) {
  if (typeof value !== "string") return false;
  const match = RFC3339_DATE_TIME.exec(value);
  if (!match) return false;
  const [, year, month, day, hour, minute, second, , offsetHour, offsetMinute] = match;
  const y = Number(year); const mo = Number(month); const d = Number(day);
  if (mo < 1 || mo > 12) return false;
  const daysInMonth = new Date(Date.UTC(y, mo, 0)).getUTCDate();
  if (d < 1 || d > daysInMonth) return false;
  if (Number(hour) > 23 || Number(minute) > 59 || Number(second) > 60) return false;
  if (offsetHour !== undefined && (Number(offsetHour) > 23 || Number(offsetMinute) > 59)) return false;
  return true;
}

// Enum support (shared-fix closure, Renacar Discovery contract audit 2026-09-24): a schema leaf may
// declare `enum` -- a fixed, closed list of the only values that field genuinely accepts (e.g. a
// category). Generic: this file has no knowledge of what any enum's own values MEAN, only that
// declaring one commits the capability author to a real, closed, typed list, and that Warp's own
// validation (below) then genuinely enforces it -- an unrecognized value is rejected before it ever
// reaches the site's handler, never silently ignored/fell through to an unfiltered result.
function matchesDeclaredType(value, type) {
  if (type === "string") return typeof value === "string";
  if (type === "number") return typeof value === "number";
  if (type === "integer") return typeof value === "number" && Number.isInteger(value);
  if (type === "boolean") return typeof value === "boolean";
  if (type === "null") return value === null;
  return false; // enum is only meaningful on a primitive leaf -- never object/array
}

function isSensitiveKey(key) {
  return /secret|token|password|api[_-]?key|service[_-]?role|authorization|credential|__proto__|prototype|constructor/i.test(key);
}

// Validates that a schema object ITSELF (an inputSchema/outputSchema a capability author writes)
// is well-formed enough that a real Warp AI Engine's own Discovery validator will accept it --
// object type, real `properties`, explicit `required` array, `additionalProperties: false`, no
// secret-like field names, bounded depth/breadth. Throws with a clear message on the first problem.
export function assertValidSchemaDefinition(schema, { path = "$", depth = 0 } = {}) {
  if (depth > MAX_SCHEMA_DEPTH) {
    throw new Error(`Schema at ${path} exceeds the maximum nesting depth (${MAX_SCHEMA_DEPTH}).`);
  }
  if (!schema || typeof schema !== "object" || Array.isArray(schema)) {
    throw new Error(`Schema at ${path} must be a plain object.`);
  }
  if (!VALID_TYPES.has(schema.type)) {
    throw new Error(`Schema at ${path} must declare a valid "type" (${[...VALID_TYPES].join("|")}).`);
  }
  if (schema.enum !== undefined) {
    if (schema.type === "object" || schema.type === "array") {
      throw new Error(`Schema at ${path} declares "enum" on a non-primitive type ("${schema.type}") -- enum is only valid on string/number/integer/boolean/null.`);
    }
    if (!Array.isArray(schema.enum) || schema.enum.length === 0) {
      throw new Error(`Schema at ${path} declares "enum" but it is not a non-empty array.`);
    }
    if (schema.enum.length > MAX_ENUM_MEMBERS) {
      throw new Error(`Schema at ${path} declares too many "enum" members (max ${MAX_ENUM_MEMBERS}).`);
    }
    if (new Set(schema.enum).size !== schema.enum.length) {
      throw new Error(`Schema at ${path} declares "enum" with duplicate values.`);
    }
    for (const member of schema.enum) {
      if (!matchesDeclaredType(member, schema.type)) {
        throw new Error(`Schema at ${path} declares an "enum" member that does not match its own declared type ("${schema.type}").`);
      }
    }
  }
  if (schema.format !== undefined) {
    if (schema.type !== "string") {
      throw new Error(`Schema at ${path} declares "format" on a non-string type ("${schema.type}") -- format is only valid on string.`);
    }
    if (typeof schema.format !== "string" || !SUPPORTED_FORMATS.has(schema.format)) {
      throw new Error(`Schema at ${path} declares an unsupported "format" (${JSON.stringify(schema.format)}) -- supported: ${[...SUPPORTED_FORMATS].join(", ")}.`);
    }
  }
  // Presentation annotations (form date/time mission, 2026-10-08): `title` (standard JSON Schema)
  // and `x-help` are short human texts for a form; `x-timezone` declares the IANA zone in which a
  // person's chosen date/time is interpreted, and only makes sense on a `format: "date-time"` field.
  for (const key of ["title", "x-help"]) {
    if (schema[key] !== undefined && (typeof schema[key] !== "string" || !schema[key].trim() || schema[key].length > 300)) {
      throw new Error(`Schema at ${path} declares "${key}" but it is not a short non-empty string.`);
    }
  }
  if (schema["x-timezone"] !== undefined) {
    if (schema.type !== "string" || schema.format !== "date-time") {
      throw new Error(`Schema at ${path} declares "x-timezone" without being a string with format "date-time".`);
    }
    if (!isValidTimeZone(schema["x-timezone"])) {
      throw new Error(`Schema at ${path} declares an "x-timezone" that is not a valid IANA time zone (${JSON.stringify(schema["x-timezone"])}).`);
    }
  }
  if (schema.type === "object") {
    if (!schema.properties || typeof schema.properties !== "object" || Array.isArray(schema.properties)) {
      throw new Error(`Schema at ${path} of type "object" must declare "properties".`);
    }
    const propertyNames = Object.keys(schema.properties);
    if (propertyNames.length > MAX_SCHEMA_PROPERTIES) {
      throw new Error(`Schema at ${path} declares too many properties (max ${MAX_SCHEMA_PROPERTIES}).`);
    }
    if (schema.additionalProperties !== false) {
      throw new Error(`Schema at ${path} must set "additionalProperties: false".`);
    }
    if (!Array.isArray(schema.required)) {
      throw new Error(`Schema at ${path} must declare a "required" array (may be empty).`);
    }
    for (const key of schema.required) {
      if (!propertyNames.includes(key)) {
        throw new Error(`Schema at ${path} lists "${key}" as required but does not declare it in "properties".`);
      }
    }
    for (const [key, child] of Object.entries(schema.properties)) {
      if (isSensitiveKey(key)) {
        throw new Error(`Schema at ${path} declares a field name that looks like a secret ("${key}") -- not allowed.`);
      }
      assertValidSchemaDefinition(child, { path: `${path}.${key}`, depth: depth + 1 });
    }
  }
  if (schema.type === "array") {
    if (!schema.items || typeof schema.items !== "object") {
      throw new Error(`Schema at ${path} of type "array" must declare "items".`);
    }
    assertValidSchemaDefinition(schema.items, { path: `${path}[]`, depth: depth + 1 });
  }
}

export const SCHEMA_VALIDATION_ERROR_CODES = Object.freeze({
  MISSING_REQUIRED_FIELD: "MISSING_REQUIRED_FIELD",
  ADDITIONAL_PROPERTY: "ADDITIONAL_PROPERTY",
  TYPE_MISMATCH: "TYPE_MISMATCH",
  ENUM_MISMATCH: "ENUM_MISMATCH",
  FORMAT_MISMATCH: "FORMAT_MISMATCH",
});

// Validates a real invocation's arguments against an already-valid inputSchema (see above).
export function validateArguments(value, schema) {
  const errors = [];
  walk(value, schema, "$", errors, 0);
  return { ok: errors.length === 0, errors };
}

function walk(value, schema, path, errors, depth) {
  if (depth > MAX_SCHEMA_DEPTH) return;
  const type = schema.type;

  if (type === "object") {
    if (value === undefined || value === null || typeof value !== "object" || Array.isArray(value)) {
      errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.TYPE_MISMATCH, path, message: `${path} must be an object.` });
      return;
    }
    const properties = schema.properties || {};
    for (const key of schema.required || []) {
      if (value[key] === undefined || value[key] === null || value[key] === "") {
        errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.MISSING_REQUIRED_FIELD, path: `${path}.${key}`, message: `${path}.${key} is required.` });
      }
    }
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(value)) {
        if (!(key in properties)) {
          errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.ADDITIONAL_PROPERTY, path: `${path}.${key}`, message: `${path}.${key} is not a declared field.` });
        }
      }
    }
    for (const [key, childSchema] of Object.entries(properties)) {
      if (value[key] === undefined) continue;
      walk(value[key], childSchema, `${path}.${key}`, errors, depth + 1);
    }
    return;
  }

  if (type === "array") {
    if (!Array.isArray(value)) {
      errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.TYPE_MISMATCH, path, message: `${path} must be an array.` });
      return;
    }
    if (schema.items) value.forEach((item, i) => walk(item, schema.items, `${path}[${i}]`, errors, depth + 1));
    return;
  }

  let typeMismatch = false;
  if (type === "string" && typeof value !== "string") typeMismatch = true;
  if (type === "number" && typeof value !== "number") typeMismatch = true;
  if (type === "integer" && (typeof value !== "number" || !Number.isInteger(value))) typeMismatch = true;
  if (type === "boolean" && typeof value !== "boolean") typeMismatch = true;
  if (typeMismatch) errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.TYPE_MISMATCH, path, message: `${path} must be a ${type}.` });

  // Enum support (shared-fix closure, Renacar Discovery contract audit 2026-09-24) -- checked only
  // once the value already matches its declared primitive type (a type mismatch is reported once,
  // never doubled up with a redundant enum error for the same value). An unrecognized value is
  // REJECTED here, before it ever reaches the site's own handler -- never silently accepted and
  // forwarded as an unfiltered/unvalidated argument (the exact real gap the audit found: an
  // unrecognized category used to fall through to the site's own ad-hoc handling instead of being
  // caught by the shared contract layer).
  if (!typeMismatch && Array.isArray(schema.enum) && !schema.enum.includes(value)) {
    errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.ENUM_MISMATCH, path, message: `${path} must be one of: ${schema.enum.join(", ")}.` });
  }

  // `format: "date-time"` (see SUPPORTED_FORMATS above) -- same posture as enum: checked only once
  // the value is already a string, rejected before the handler ever runs.
  if (!typeMismatch && schema.format === "date-time" && !isRfc3339DateTime(value)) {
    errors.push({ code: SCHEMA_VALIDATION_ERROR_CODES.FORMAT_MISMATCH, path, message: `${path} must be an RFC 3339 date-time with an explicit offset (e.g. 2026-10-10T10:00:00-03:00 or 2026-10-10T13:00:00Z).` });
  }
}
