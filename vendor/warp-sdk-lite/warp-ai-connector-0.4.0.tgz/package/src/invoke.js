import { validateArguments } from "./schema.js";

export const INVOCATION_ERROR_CODES = Object.freeze({
  CAPABILITY_NOT_FOUND: "CAPABILITY_NOT_FOUND",
  INVALID_ARGUMENTS: "INVALID_ARGUMENTS",
  HANDLER_FAILED: "HANDLER_FAILED",
});

function invocationError(code, message, details) {
  const error = new Error(message);
  error.code = code;
  if (details) error.details = details;
  return error;
}

// Invokes a registered READ capability with already-parsed arguments (e.g. from a GET request's
// query string). Never invokes anything the registry does not already know about, and never runs
// the handler against unvalidated input.
export async function invokeCapability(registry, capabilityId, args = {}) {
  const capability = registry.get(capabilityId);
  if (!capability) {
    throw invocationError(INVOCATION_ERROR_CODES.CAPABILITY_NOT_FOUND, `Capability "${capabilityId}" is not registered.`);
  }
  const validation = validateArguments(args, capability.inputSchema);
  if (!validation.ok) {
    throw invocationError(INVOCATION_ERROR_CODES.INVALID_ARGUMENTS, `Arguments for "${capabilityId}" are invalid.`, validation.errors);
  }
  try {
    return await capability.handler(args);
  } catch (err) {
    throw invocationError(INVOCATION_ERROR_CODES.HANDLER_FAILED, `Capability "${capabilityId}" failed while handling the request.`, { message: err?.message });
  }
}
