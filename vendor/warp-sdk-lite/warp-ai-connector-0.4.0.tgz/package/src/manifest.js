import { DISCOVERY_MANIFEST_CONTRACT, DISCOVERY_PROTOCOL_VERSION, sanitizeValue } from "./protocol.js";

// Builds the real GET /api/v1/discovery response body -- the exact shape
// warp-ai-engine's own lib/sdk/discovery/discoveryReport.js validates against (see
// docs/handover/RENACAR_DISCOVERY_COMPATIBILITY_AUDIT.md section 5 for a worked example this
// mirrors). Every capability's `invocation.path` is derived from `basePath` + its own id, so the
// manifest this function returns and the route the invocation handler actually serves can never
// drift apart -- there is only one place either is computed.
export function buildManifest({ platform, connector, capabilities, basePath }) {
  return {
    contract: DISCOVERY_MANIFEST_CONTRACT,
    protocolVersion: DISCOVERY_PROTOCOL_VERSION,
    platform: {
      type: sanitizeValue(platform?.type || "external", 80),
      id: sanitizeValue(platform?.id || "", 120),
      name: sanitizeValue(platform?.name || "", 200),
      version: sanitizeValue(platform?.version || "1.0", 80),
      locale: sanitizeValue(platform?.locale || "es-AR", 40),
    },
    connector: {
      id: sanitizeValue(connector?.id || "@warp-ai/connector", 120),
      version: sanitizeValue(connector?.version || "0.1.0", 80),
    },
    capabilities: capabilities.map((capability) => ({
      id: capability.id,
      operationType: "read",
      sideEffects: false,
      confirmationRequired: false,
      authentication: capability.authentication,
      risk: capability.risk,
      description: capability.description,
      invocation: {
        protocol: "http",
        method: "GET",
        path: `${basePath}/${capability.id}`,
        contentType: "application/json",
      },
      inputSchema: capability.inputSchema,
      outputSchema: capability.outputSchema,
    })),
    catalog: { categories: [], services: [] },
  };
}
