import { assertValidSchemaDefinition } from "./schema.js";

// V1 is read-only by explicit product decision (WARP SDK LITE V1 mission) -- this registry never
// accepts a capability shaped as a write. There is no `operationType` parameter to override: every
// capability registered here is unconditionally a read (sideEffects: false, confirmationRequired:
// false), and any definition that TRIES to declare itself otherwise is rejected outright, not
// silently downgraded.
const ID_PATTERN = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const VALID_RISKS = new Set(["low", "medium", "high"]);
const VALID_AUTH = new Set(["public", "authenticated", "service"]);
const WRITE_INDICATOR_KEYS = ["operationType", "sideEffects", "confirmationRequired", "mutating", "write"];

export function createCapabilityRegistry() {
  const byId = new Map();

  function register(definition) {
    if (!definition || typeof definition !== "object") {
      throw new Error("A capability definition must be an object.");
    }
    for (const key of WRITE_INDICATOR_KEYS) {
      if (key in definition) {
        const value = definition[key];
        const looksLikeWrite = (key === "operationType" && value !== "read") || (key === "sideEffects" && value === true) || (key === "confirmationRequired" && value === true) || ((key === "mutating" || key === "write") && value);
        if (looksLikeWrite) {
          throw new Error(`@warp-ai/connector v1 is read-only -- capability "${definition.id}" declares "${key}", which is not supported yet. Writes are rejected, never silently accepted.`);
        }
      }
    }

    const id = String(definition.id || "");
    if (!ID_PATTERN.test(id)) {
      throw new Error(`Capability id "${id}" is invalid -- must match ${ID_PATTERN}.`);
    }
    if (byId.has(id)) {
      throw new Error(`Capability "${id}" is already registered.`);
    }
    const description = String(definition.description || "").trim();
    if (description.length < 12) {
      throw new Error(`Capability "${id}" needs a real description (at least 12 characters) so Warp can present it meaningfully.`);
    }
    const risk = definition.risk || "low";
    if (!VALID_RISKS.has(risk)) {
      throw new Error(`Capability "${id}" has an invalid risk ("${risk}") -- must be one of ${[...VALID_RISKS].join(", ")}.`);
    }
    const authentication = definition.authentication || "public";
    if (!VALID_AUTH.has(authentication)) {
      throw new Error(`Capability "${id}" has an invalid authentication value ("${authentication}").`);
    }
    if (typeof definition.handler !== "function") {
      throw new Error(`Capability "${id}" must provide a "handler" function.`);
    }
    assertValidSchemaDefinition(definition.inputSchema, { path: `${id}.inputSchema` });
    assertValidSchemaDefinition(definition.outputSchema, { path: `${id}.outputSchema` });

    const record = Object.freeze({
      id,
      description,
      risk,
      authentication,
      inputSchema: definition.inputSchema,
      outputSchema: definition.outputSchema,
      handler: definition.handler,
    });
    byId.set(id, record);
    return record;
  }

  function get(id) {
    return byId.get(id) || null;
  }

  function list() {
    return [...byId.values()];
  }

  return Object.freeze({ register, get, list });
}
