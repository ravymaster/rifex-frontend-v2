// Extracted, unmodified in substance, from warp-ai-engine's own
// lib/sdk/discovery/discoveryProtocol.js -- the real, already-certified Discovery manifest
// contract a Warp AI Engine deployment expects when it fetches GET /api/v1/discovery from a
// registered source. Copied rather than imported so this package has zero dependency on the
// warp-ai-engine repo/monorepo -- it must work standalone once published.

export const DISCOVERY_MANIFEST_CONTRACT = "warp.discovery_manifest.v1";
export const DISCOVERY_PROTOCOL_VERSION = "1.0";

export function sanitizeValue(value, maxLength = 240) {
  if (typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") {
    return "";
  }
  return String(value)
    .replace(/[<>{}[\]`"'\\]/g, "")
    .trim()
    .slice(0, maxLength);
}
