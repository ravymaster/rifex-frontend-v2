import { buildManifest } from "./manifest.js";
import { invokeCapability, INVOCATION_ERROR_CODES } from "./invoke.js";

// Framework-agnostic Web-standard Request/Response handlers (the same shape Next.js App Router
// route handlers already use natively) -- no Next.js import anywhere in this package, so it stays
// usable outside Next too, even though @warp-ai/init only wires it into Next.js today.

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

// GET /api/warp/discovery (or wherever @warp-ai/init wires it) -- the real manifest endpoint a
// registered Warp AI Engine Discovery source fetches.
export function createDiscoveryRouteHandler({ registry, platform, connector, basePath }) {
  return async function discoveryRouteHandler() {
    const manifest = buildManifest({ platform, connector, capabilities: registry.list(), basePath });
    return jsonResponse({ success: true, data: manifest });
  };
}

// A query string only carries strings; the capability's own inputSchema says what each one really
// is. integer/number/boolean are converted, arrays come from repeated params. A value that does not
// parse is left as the original string so the normal argument validation rejects it (never guessed).
function coerceQueryArguments(searchParams, inputSchema) {
  const properties = inputSchema?.properties || {};
  const args = {};
  for (const key of new Set(searchParams.keys())) {
    const declared = properties[key];
    const raw = searchParams.getAll(key);
    const convert = (type, value) => {
      if (type === "integer") return /^-?\d+$/.test(value) ? Number(value) : value;
      if (type === "number") return value.trim() !== "" && Number.isFinite(Number(value)) ? Number(value) : value;
      if (type === "boolean") return value === "true" ? true : value === "false" ? false : value;
      return value;
    };
    if (declared?.type === "array") args[key] = raw.map((value) => convert(declared.items?.type, value));
    else args[key] = convert(declared?.type, raw[0]);
  }
  return args;
}

// Safe HTTP error detail exposure (shared-fix closure, Renacar Discovery contract audit 2026-09-24)
// -- real evidence found the route handler discarding invokeCapability's own `error.details`
// (the actual field/path/reason a validation failed) when building the HTTP response, leaving only
// a generic top-level message ("Arguments for X are invalid.") -- forcing every site that needed
// real diagnostics to build its own wrapper. `details` here is ONLY ever the structured, already-
// safe output of schema.js's own validateArguments (field paths and generic type/enum-mismatch
// messages, built entirely from the capability's OWN already-certified schema -- never a value the
// caller supplied verbatim, never a raw exception message or stack trace). Bounded defensively so a
// pathological schema can never produce an unbounded response. HANDLER_FAILED deliberately stays
// generic -- a site's own handler exception text is that site's internal implementation detail, not
// safe to echo back over a public HTTP response by default.
const MAX_ERROR_DETAILS = 20;

function safeErrorDetails(error) {
  if (error?.code !== INVOCATION_ERROR_CODES.INVALID_ARGUMENTS) return undefined;
  if (!Array.isArray(error.details)) return undefined;
  return error.details.slice(0, MAX_ERROR_DETAILS).map((entry) => ({
    code: String(entry?.code || "VALIDATION_ERROR"),
    path: String(entry?.path || "$"),
    message: String(entry?.message || "Invalid value."),
  }));
}

// GET /api/warp/capabilities/:capabilityId -- one dynamic route handles every registered read
// capability; arguments come from the query string, matching the real protocol's GET+searchParams
// invocation style (see warp-ai-engine's own discoveryContextProvider.js).
export function createCapabilityRouteHandler({ registry }) {
  return async function capabilityRouteHandler(request, context) {
    const capabilityId = context?.params?.capabilityId;
    const url = new URL(request.url);
    const args = coerceQueryArguments(url.searchParams, registry.get(capabilityId)?.inputSchema);
    try {
      const result = await invokeCapability(registry, capabilityId, args);
      return jsonResponse({ success: true, data: result });
    } catch (error) {
      const status = error?.code === INVOCATION_ERROR_CODES.CAPABILITY_NOT_FOUND ? 404
        : error?.code === INVOCATION_ERROR_CODES.INVALID_ARGUMENTS ? 400
          : 500;
      const details = safeErrorDetails(error);
      return jsonResponse({
        success: false,
        error: {
          code: error?.code || "INTERNAL_ERROR",
          message: error?.message || "Unexpected error.",
          ...(details ? { details } : {}),
        },
      }, status);
    }
  };
}
