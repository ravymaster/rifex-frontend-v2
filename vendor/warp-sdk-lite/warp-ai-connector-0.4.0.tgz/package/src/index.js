import { createCapabilityRegistry } from "./capabilityRegistry.js";
import { buildManifest } from "./manifest.js";
import { invokeCapability } from "./invoke.js";
import { createDiscoveryRouteHandler as buildDiscoveryRouteHandler, createCapabilityRouteHandler as buildCapabilityRouteHandler } from "./routeHandlers.js";

export { INVOCATION_ERROR_CODES } from "./invoke.js";
export { DISCOVERY_MANIFEST_CONTRACT, DISCOVERY_PROTOCOL_VERSION } from "./protocol.js";

const DEFAULT_BASE_PATH = "/api/warp/capabilities";

// createConnector({ platform, connector, basePath }) -- the package's single public entry point.
// V1 scope (binding, per the WARP SDK LITE V1 mission): read-only. `.capability(def)` never
// accepts anything that looks like a write (see capabilityRegistry.js). No dependency on Warp Core
// or the full warp-ai-engine repo anywhere in this package.
export function createConnector({ platform, connector, basePath = DEFAULT_BASE_PATH } = {}) {
  const registry = createCapabilityRegistry();

  return Object.freeze({
    capability(definition) {
      return registry.register(definition);
    },
    listCapabilities() {
      return registry.list();
    },
    getManifest() {
      return buildManifest({ platform, connector, capabilities: registry.list(), basePath });
    },
    async invoke(capabilityId, args = {}) {
      return invokeCapability(registry, capabilityId, args);
    },
    // Next.js App Router (or any Web-standard Request/Response router) wiring.
    createDiscoveryRouteHandler() {
      return buildDiscoveryRouteHandler({ registry, platform, connector, basePath });
    },
    createCapabilityRouteHandler() {
      return buildCapabilityRouteHandler({ registry });
    },
    basePath,
  });
}
