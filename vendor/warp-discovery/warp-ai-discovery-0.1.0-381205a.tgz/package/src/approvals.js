// Warp Discovery -- Approval Registry. Only an authorized PERSON approves. Every decision is bound to
// the contentHash it approved: if the page changes, the old approval no longer applies (review again).
// The AI never approves: approver.type must be "human" and an approver name that identifies a bot,
// model or assistant is refused. Nothing in the engine calls this module.

import { CONTRACT_VERSIONS, KINDS, LIMITS, AREAS, ACCESS, ACTIONS, validateNavigationEntry, validateContentEntry } from "./contracts.js";

export const APPROVAL_ERROR_CODES = Object.freeze({
  APPROVER_REQUIRED: "APPROVER_REQUIRED",
  APPROVER_NOT_HUMAN: "APPROVER_NOT_HUMAN",
  NOT_VERIFIED: "NOT_VERIFIED",
  BLOCKED_OBSERVATION: "BLOCKED_OBSERVATION",
  ADMINISTRATIVE: "ADMINISTRATIVE",
  OVERRIDE_INVALID: "OVERRIDE_INVALID",
  DECISION_INVALID: "DECISION_INVALID",
});

export class ApprovalError extends Error {
  constructor(code, message) { super(message); this.name = "ApprovalError"; this.code = code; }
}

const NON_HUMAN_NAME = /\b(?:ai|ia|bot|robot|gpt|chatgpt|llm|model|modelo|assistant|asistente|agent|agente|warp|claude|openai|gemini|copilot|qwen|ollama|automat\w*|script|cron)\b/i;

export function createApprovalRegistry(origin) {
  return { contract: CONTRACT_VERSIONS.APPROVALS, origin, decisions: [] };
}

function assertApprover(approver) {
  if (!approver || typeof approver !== "object" || typeof approver.name !== "string" || !approver.name.trim() || approver.name.length > 80) {
    throw new ApprovalError(APPROVAL_ERROR_CODES.APPROVER_REQUIRED, "An identified person must approve (approver.name).");
  }
  if (approver.type !== "human" || NON_HUMAN_NAME.test(approver.name)) {
    throw new ApprovalError(APPROVAL_ERROR_CODES.APPROVER_NOT_HUMAN, "Only a person can approve Discovery contracts; AI or automation cannot.");
  }
}

// keyFacts: verbatim quotes the owner selects (the contract checks each one against its section).
const OVERRIDABLE = ["label", "intents", "area", "access", "action", "title", "keyFacts"];

export function applyOverrides(candidate, overrides) {
  if (!overrides) return { ...candidate };
  const out = { ...candidate };
  for (const [key, value] of Object.entries(overrides)) {
    if (!OVERRIDABLE.includes(key)) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, `Field "${key}" cannot be changed at review.`);
    if (key === "area" && !AREAS.includes(value)) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, "Invalid area.");
    if (key === "access" && !ACCESS.includes(value)) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, "Invalid access.");
    if (key === "action" && !ACTIONS.includes(value)) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, "Invalid action.");
    if (key === "intents" && (!Array.isArray(value) || value.length > LIMITS.INTENTS_MAX)) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, "Invalid intents.");
    if (key === "keyFacts") {
      if (!Array.isArray(value)) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, "Invalid keyFacts.");
      out[key] = value.map((f) => ({ id: f?.id, label: f?.label, sectionId: f?.sectionId, quote: f?.quote }));
      continue;
    }
    out[key] = Array.isArray(value) ? value.map((v) => String(v).trim()).filter(Boolean) : value;
  }
  const problems = out.kind === KINDS.NAVIGATION ? validateNavigationEntry({ ...out, status: "approved" }) : validateContentEntry({ ...out, status: "approved" });
  if (problems.length) throw new ApprovalError(APPROVAL_ERROR_CODES.OVERRIDE_INVALID, `Override breaks the contract (${problems[0].code}).`);
  return out;
}

// verification: the verifier result for this candidate (must be ok to approve).
export function recordDecision(registry, candidate, { decision, approver, verification, overrides = null, at = new Date().toISOString(), note = null }) {
  if (decision !== "approved" && decision !== "rejected") throw new ApprovalError(APPROVAL_ERROR_CODES.DECISION_INVALID, "Decision must be approved or rejected.");
  assertApprover(approver);
  if (candidate.kind === KINDS.FORM_OBSERVATION || candidate.kind === KINDS.ENDPOINT_OBSERVATION || candidate.blocked) {
    if (decision === "approved") throw new ApprovalError(APPROVAL_ERROR_CODES.BLOCKED_OBSERVATION, "Form and endpoint observations can never be approved.");
  }
  if (decision === "approved") {
    if (candidate.access === "administrative" || candidate.area === "administrative") throw new ApprovalError(APPROVAL_ERROR_CODES.ADMINISTRATIVE, "Administrative pages are never published.");
    if (!verification || verification.ok !== true) throw new ApprovalError(APPROVAL_ERROR_CODES.NOT_VERIFIED, "Only a verified candidate can be approved.");
    applyOverrides(candidate, overrides); // throws if the overrides break the contract
  }
  const entry = {
    id: candidate.id,
    kind: candidate.kind,
    decision,
    contentHash: candidate.contentHash || null,
    approver: { type: "human", name: approver.name.trim() },
    at,
    ...(overrides ? { overrides } : {}),
    ...(note ? { note: String(note).slice(0, 200) } : {}),
  };
  registry.decisions = registry.decisions.filter((d) => d.id !== candidate.id).concat(entry);
  return entry;
}

export function findDecision(registry, id) {
  return (registry?.decisions || []).find((d) => d.id === id) || null;
}
