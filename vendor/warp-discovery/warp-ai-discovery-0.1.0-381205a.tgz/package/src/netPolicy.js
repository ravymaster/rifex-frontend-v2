// Warp Discovery -- network policy (SSRF). Pure functions; no I/O except the injectable DNS lookup.
//
// Rules: only https (http only when explicitly enabled, for local tests); no credentials in URLs;
// only allowed ports; never localhost/loopback/private/link-local/CGNAT/multicast/reserved/cloud
// metadata; every hostname is resolved and EVERY returned address must be public before connecting;
// the connection is then pinned to that validated address (safeFetch.js), so a second DNS answer
// (DNS rebinding) is never used.

import { isIP } from "node:net";
import { lookup as dnsLookup } from "node:dns";

const BLOCKED_HOSTNAMES = [/^localhost$/i, /\.localhost$/i, /\.local$/i, /\.internal$/i, /\.home\.arpa$/i, /^metadata$/i, /^metadata\.google\.internal$/i, /^instance-data$/i];

const IPV4_BLOCKS = [
  ["0.0.0.0", 8], ["10.0.0.0", 8], ["100.64.0.0", 10], ["127.0.0.0", 8], ["169.254.0.0", 16],
  ["172.16.0.0", 12], ["192.0.0.0", 24], ["192.0.2.0", 24], ["192.88.99.0", 24], ["192.168.0.0", 16],
  ["198.18.0.0", 15], ["198.51.100.0", 24], ["203.0.113.0", 24], ["224.0.0.0", 4], ["240.0.0.0", 4],
];

function ipv4ToInt(ip) {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((p) => !Number.isInteger(p) || p < 0 || p > 255)) return null;
  return ((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3];
}

function inV4Block(ip, base, bits) {
  const a = ipv4ToInt(ip); const b = ipv4ToInt(base);
  if (a === null || b === null) return true; // unparsable -> treat as blocked
  const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
  return (a & mask) === (b & mask);
}

export function isLoopbackAddress(ip) {
  if (isIP(ip) === 4) return inV4Block(ip, "127.0.0.0", 8);
  if (isIP(ip) === 6) {
    const v = expandIPv6(ip);
    return v === "0000:0000:0000:0000:0000:0000:0000:0001" || (embeddedIPv4(v) !== null && isLoopbackAddress(embeddedIPv4(v)));
  }
  return false;
}

function expandIPv6(ip) {
  let addr = ip.toLowerCase().split("%")[0];
  // dotted IPv4 tail (e.g. ::ffff:10.0.0.1)
  const dotted = addr.match(/(\d+\.\d+\.\d+\.\d+)$/);
  if (dotted) {
    const n = ipv4ToInt(dotted[1]);
    if (n === null) return null;
    addr = addr.slice(0, -dotted[1].length) + `${((n >>> 16) & 0xffff).toString(16)}:${(n & 0xffff).toString(16)}`;
  }
  const halves = addr.split("::");
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(":") : [];
  const tail = halves.length === 2 && halves[1] ? halves[1].split(":") : [];
  const missing = 8 - head.length - tail.length;
  if (missing < 0 || (halves.length === 1 && missing !== 0)) return null;
  const groups = [...head, ...Array(halves.length === 2 ? missing : 0).fill("0"), ...tail];
  if (groups.length !== 8 || groups.some((g) => !/^[0-9a-f]{1,4}$/.test(g))) return null;
  return groups.map((g) => g.padStart(4, "0")).join(":");
}

function embeddedIPv4(expanded) {
  if (!expanded) return null;
  const g = expanded.split(":");
  const toV4 = (hi, lo) => { const n = (parseInt(hi, 16) << 16) + parseInt(lo, 16); return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join("."); };
  // ::ffff:a.b.c.d (mapped), ::a.b.c.d (compatible), 64:ff9b::a.b.c.d (NAT64)
  if (g.slice(0, 5).every((x) => x === "0000") && g[5] === "ffff") return toV4(g[6], g[7]);
  if (g.slice(0, 6).every((x) => x === "0000") && !(g[6] === "0000" && (g[7] === "0000" || g[7] === "0001"))) return toV4(g[6], g[7]);
  if (g[0] === "0064" && g[1] === "ff9b" && g.slice(2, 6).every((x) => x === "0000")) return toV4(g[6], g[7]);
  return null;
}

// true = the address may be connected to.
export function isPublicAddress(ip) {
  const family = isIP(ip);
  if (family === 4) return !IPV4_BLOCKS.some(([base, bits]) => inV4Block(ip, base, bits));
  if (family === 6) {
    const v = expandIPv6(ip);
    if (!v) return false;
    if (v === "0000:0000:0000:0000:0000:0000:0000:0000" || v === "0000:0000:0000:0000:0000:0000:0000:0001") return false;
    const embedded = embeddedIPv4(v);
    if (embedded !== null) return isPublicAddress(embedded);
    const first = parseInt(v.slice(0, 4), 16);
    if ((first & 0xfe00) === 0xfc00) return false; // fc00::/7 unique local
    if ((first & 0xffc0) === 0xfe80) return false; // fe80::/10 link-local
    if ((first & 0xffc0) === 0xfec0) return false; // fec0::/10 site-local (deprecated)
    if ((first & 0xff00) === 0xff00) return false; // ff00::/8 multicast
    if (v.startsWith("2001:0db8")) return false; // documentation
    if (v.startsWith("2001:0000")) return false; // Teredo
    if (v.startsWith("2002")) return false; // 6to4 (can embed private v4)
    if (v.startsWith("0100:0000:0000:0000")) return false; // discard-only
    return true;
  }
  return false;
}

export const NET_ERROR_CODES = Object.freeze({
  URL_INVALID: "URL_INVALID",
  SCHEME_NOT_ALLOWED: "SCHEME_NOT_ALLOWED",
  CREDENTIALS_IN_URL: "CREDENTIALS_IN_URL",
  PORT_NOT_ALLOWED: "PORT_NOT_ALLOWED",
  HOST_BLOCKED: "HOST_BLOCKED",
  CROSS_ORIGIN: "CROSS_ORIGIN",
  DNS_FAILED: "DNS_FAILED",
  ADDRESS_NOT_PUBLIC: "ADDRESS_NOT_PUBLIC",
});

export class NetPolicyError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "NetPolicyError";
    this.code = code;
  }
}

// policy: { origin, allowHttp=false, allowedPorts=[443] (+80 when allowHttp), allowLoopbackForTests=false }
export function createNetPolicy({ origin, allowHttp = false, allowedPorts = null, allowLoopbackForTests = false, lookupImpl = null } = {}) {
  let base;
  try { base = new URL(origin); } catch { throw new NetPolicyError(NET_ERROR_CODES.URL_INVALID, "Authorized origin is not a valid URL."); }
  const schemes = allowHttp ? ["https:", "http:"] : ["https:"];
  if (!schemes.includes(base.protocol)) throw new NetPolicyError(NET_ERROR_CODES.SCHEME_NOT_ALLOWED, "Authorized origin must use https.");
  if (base.username || base.password) throw new NetPolicyError(NET_ERROR_CODES.CREDENTIALS_IN_URL, "Authorized origin must not carry credentials.");
  // Loopback is only ever accepted when the AUTHORIZED ORIGIN itself is a loopback literal and the
  // test flag is set -- a public origin can never redirect or resolve into loopback.
  const loopbackOrigin = allowLoopbackForTests && isIP(base.hostname.replace(/^\[|\]$/g, "")) && isLoopbackAddress(base.hostname.replace(/^\[|\]$/g, ""));
  if (!loopbackOrigin) assertHostnameNotBlocked(base.hostname);
  const ports = new Set((allowedPorts || (allowHttp ? [443, 80] : [443])).map(Number));
  if (loopbackOrigin) ports.add(Number(base.port || (base.protocol === "https:" ? 443 : 80)));
  const authorizedOrigin = base.origin;
  const lookup = lookupImpl || dnsLookup;

  function checkUrl(raw) {
    let url;
    try { url = raw instanceof URL ? new URL(raw.href) : new URL(raw); } catch { throw new NetPolicyError(NET_ERROR_CODES.URL_INVALID, "URL is not valid."); }
    if (!schemes.includes(url.protocol)) throw new NetPolicyError(NET_ERROR_CODES.SCHEME_NOT_ALLOWED, "Scheme not allowed.");
    if (url.username || url.password) throw new NetPolicyError(NET_ERROR_CODES.CREDENTIALS_IN_URL, "URL must not carry credentials.");
    const port = Number(url.port || (url.protocol === "https:" ? 443 : 80));
    if (!ports.has(port)) throw new NetPolicyError(NET_ERROR_CODES.PORT_NOT_ALLOWED, "Port not allowed.");
    if (url.origin !== authorizedOrigin) throw new NetPolicyError(NET_ERROR_CODES.CROSS_ORIGIN, "Only the authorized origin may be fetched.");
    return url;
  }

  // Resolves ONCE and returns the single validated address the connection must be pinned to.
  async function resolvePinned(hostname) {
    const bare = hostname.replace(/^\[|\]$/g, "");
    if (isIP(bare)) {
      if (loopbackOrigin && isLoopbackAddress(bare)) return { address: bare, family: isIP(bare) };
      if (!isPublicAddress(bare)) throw new NetPolicyError(NET_ERROR_CODES.ADDRESS_NOT_PUBLIC, "Address is not public.");
      return { address: bare, family: isIP(bare) };
    }
    assertHostnameNotBlocked(bare);
    const answers = await new Promise((resolve, reject) => {
      lookup(bare, { all: true, verbatim: true }, (error, addresses) => (error ? reject(error) : resolve(addresses)));
    }).catch(() => { throw new NetPolicyError(NET_ERROR_CODES.DNS_FAILED, "Hostname could not be resolved."); });
    const list = Array.isArray(answers) ? answers : [answers];
    if (list.length === 0) throw new NetPolicyError(NET_ERROR_CODES.DNS_FAILED, "Hostname has no addresses.");
    // EVERY answer must be public -- a mixed answer is how rebinding attacks hide a private address.
    for (const entry of list) {
      if (!isPublicAddress(entry.address)) throw new NetPolicyError(NET_ERROR_CODES.ADDRESS_NOT_PUBLIC, "Hostname resolves to a non-public address.");
    }
    return { address: list[0].address, family: list[0].family || isIP(list[0].address) };
  }

  return Object.freeze({ authorizedOrigin, checkUrl, resolvePinned, loopbackOrigin: Boolean(loopbackOrigin) });
}

function assertHostnameNotBlocked(hostname) {
  const bare = String(hostname || "").replace(/^\[|\]$/g, "");
  if (!bare) throw new NetPolicyError(NET_ERROR_CODES.HOST_BLOCKED, "Hostname is empty.");
  if (BLOCKED_HOSTNAMES.some((re) => re.test(bare))) throw new NetPolicyError(NET_ERROR_CODES.HOST_BLOCKED, "Hostname is not allowed.");
  if (isIP(bare) && !isPublicAddress(bare)) throw new NetPolicyError(NET_ERROR_CODES.ADDRESS_NOT_PUBLIC, "Address is not public.");
}
