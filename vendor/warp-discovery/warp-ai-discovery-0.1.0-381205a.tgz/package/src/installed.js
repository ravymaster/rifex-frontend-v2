// Warp Discovery -- INSTALLED mode (recommended for sites that install Warp).
//
// The crawler observes; the installed package PROVES. A site that installs Warp can contribute facts
// the external crawler can only guess: its real framework routes, its sitemap, and a navigation file
// the owner declares (with access/area/action for account and auth pages the crawler never fetches).
//
// Safety: route discovery reads DIRECTORY AND FILE NAMES only, never file contents; it skips hidden
// entries, every .env* file, node_modules, API routes, private (_x) folders and dynamic segments.
// Declared entries are proposals like any other: contract-validated, verified, then approved by a
// person. Nothing internal is published unless the owner approves it.

import fs from "node:fs";
import path from "node:path";
import { CONTRACT_VERSIONS, AREAS, ACCESS, ACTIONS, isValidHref, LIMITS } from "./contracts.js";

const PAGE_FILE = /^page\.(?:js|jsx|ts|tsx|mdx)$/;

export function scanNextAppRoutes(appDir, { maxRoutes = 500 } = {}) {
  const routes = [];
  function walk(dir, segments, depth) {
    if (depth > 10 || routes.length >= maxRoutes) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      const name = entry.name;
      if (name.startsWith(".") || /^\.env/i.test(name) || name === "node_modules") continue;
      if (entry.isFile() && PAGE_FILE.test(name)) {
        const dynamic = segments.some((s) => s.startsWith("["));
        routes.push({ path: `/${segments.filter((s) => !/^\(.*\)$/.test(s)).join("/")}`.replace(/\/$/, "") || "/", dynamic });
      } else if (entry.isDirectory()) {
        if (name === "api" && segments.length === 0) continue; // endpoints are never routes
        if (name.startsWith("_") || name.startsWith("@")) continue; // private folders / parallel slots
        walk(path.join(dir, name), [...segments, name], depth + 1);
      }
    }
  }
  walk(appDir, [], 0);
  return routes.sort((a, b) => (a.path < b.path ? -1 : 1));
}

// declared: [{ href, label, area, access, action, intents? }] -- the owner's own navigation file.
export function buildInstalledManifest({ routes = [], declared = [], deploymentVersion = null } = {}) {
  const problems = [];
  const cleanDeclared = [];
  declared.slice(0, LIMITS.NAVIGATION_MAX).forEach((d, i) => {
    const p = `$.declared[${i}]`;
    if (!d || !isValidHref(d.href)) return problems.push({ code: "DECLARED_HREF_INVALID", path: p });
    if (!AREAS.includes(d.area) || !ACCESS.includes(d.access) || !ACTIONS.includes(d.action)) return problems.push({ code: "DECLARED_CLASSIFICATION_INVALID", path: p });
    if (typeof d.label !== "string" || !d.label.trim() || d.label.length > LIMITS.LABEL_MAX) return problems.push({ code: "DECLARED_LABEL_INVALID", path: p });
    cleanDeclared.push({ href: d.href, label: d.label.trim(), area: d.area, access: d.access, action: d.action, ...(Array.isArray(d.intents) ? { intents: d.intents.slice(0, LIMITS.INTENTS_MAX).map(String) } : {}) });
  });
  return {
    contract: CONTRACT_VERSIONS.INSTALLED,
    deploymentVersion: deploymentVersion ? String(deploymentVersion).slice(0, 80) : null,
    routes: routes.filter((r) => !r.dynamic && isValidHref(r.path)).map((r) => r.path),
    declared: cleanDeclared,
    problems,
  };
}

// Adds installed facts to an inventory: declared entries become link observations carrying the
// owner's classification (source "declared"); proven routes are returned for the verifier.
export function mergeInstalled(inventory, manifest) {
  if (!manifest || manifest.contract !== CONTRACT_VERSIONS.INSTALLED) throw new Error("Not a Warp Discovery installed manifest (unsupported contract).");
  const links = new Map((inventory.links || []).map((l) => [l.path, { ...l }]));
  for (const d of manifest.declared) {
    const existing = links.get(d.href) || { path: d.href, labels: {}, sources: [], foundOn: [], firstDepth: 0 };
    existing.declared = d;
    if (!existing.sources.includes("declared")) existing.sources.push("declared");
    links.set(d.href, existing);
  }
  return {
    inventory: { ...inventory, links: [...links.values()] },
    installedPaths: new Set([...manifest.routes, ...manifest.declared.map((d) => d.href)]),
  };
}
