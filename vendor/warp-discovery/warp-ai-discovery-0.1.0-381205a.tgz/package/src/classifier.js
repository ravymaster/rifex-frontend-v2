// Warp Discovery -- deterministic classifier. Rules only: no AI, no network, no site-specific data.
// Every decision returns its evidence and a confidence, so a person can review WHY.

const RULES = Object.freeze({
  logout: /(?:^|\/)(?:logout|log-out|signout|sign-out|salir|cerrar-sesion)(?:\/|$)|cerrar sesi[oó]n|log ?out|sign ?out/i,
  sign_in: /(?:^|\/)(?:login|log-in|signin|sign-in|ingresar|iniciar-sesion|entrar|acceder|acceso)(?:\/|$)|\b(?:iniciar sesi[oó]n|ingresar|ingresa|entrar|acceder|log ?in|sign ?in)\b/i,
  register: /(?:^|\/)(?:register|registro|registrarse|signup|sign-up|crear-cuenta|unete|join)(?:\/|$)|\b(?:reg[ií]strate|registrarse|registro|crear (?:una )?cuenta|sign ?up|[úu]nete)\b/i,
  recover_account: /(?:^|\/)(?:forgot[-_]?password|reset[-_]?password|password[-_]?reset|recuperar(?:-[a-z]+)*|olvide(?:-[a-z]+)*|restablecer(?:-[a-z]+)*|recover(?:-[a-z]+)*)(?:\/|$)|olvid[eé] (?:mi )?(?:clave|contrase[ñn]a)|recuperar (?:la |mi )?(?:clave|contrase[ñn]a|cuenta|acceso)|forgot (?:your )?password|reset (?:your )?password/i,
  administrative: /(?:^|\/)(?:admin|administrador|administracion|backoffice|back-office|wp-admin|staff|superadmin|cpanel|moderacion|moderation|internal)(?:\/|$)/i,
  legal: /(?:^|\/)(?:terminos(?:-[a-z]+)*|terms(?:-[a-z]+)*|tos|condiciones(?:-[a-z]+)*|privacidad|privacy(?:-[a-z]+)*|cookies|legal|aviso-legal|uso-aceptable|acceptable-use|cumplimiento|compliance|politica[a-z-]*|policy|policies)(?:\/|$)|t[ée]rminos|condiciones de uso|privacidad|privacy|cookies|aviso legal|uso aceptable|cumplimiento/i,
  faq: /(?:^|\/)(?:faq|faqs|preguntas-frecuentes|preguntas|ayuda|help|centro-de-ayuda|help-center)(?:\/|$)|preguntas frecuentes|\bfaq\b|centro de ayuda|\bayuda\b|\bhelp\b/i,
  contact: /(?:^|\/)(?:contacto|contact|contactanos|contact-us|soporte|support)(?:\/|$)|\bcontacto\b|\bcont[aá]ctanos\b|\bcontact\b|\bsoporte\b|\bsupport\b/i,
  trust: /(?:^|\/)(?:seguridad|security|confianza|trust|reportar|report|denuncias?)(?:\/|$)|\bseguridad\b|\bconfianza\b|\breportar\b/i,
  account: /(?:^|\/)(?:mi|mis|my|cuenta|account|perfil|profile|panel|dashboard|settings|ajustes|configuracion|preferencias|bancos[a-z-]*|pagos|billing|facturacion|mis-[a-z-]+|mi-[a-z-]+)(?:\/|$)/i,
  create: /(?:^|\/)(?:crear|nuevo|nueva|new|create|publicar)(?:\/|$)/i,
  configure: /(?:^|\/)(?:settings|ajustes|configuracion|preferencias|bancos[a-z-]*|integraciones)(?:\/|$)/i,
});

export const DEFAULT_INTENTS = Object.freeze({
  sign_in: ["ingresar", "iniciar sesión", "entrar a mi cuenta", "acceder", "login"],
  register: ["registrarme", "crear cuenta", "registro", "unirme", "sign up"],
  recover_account: ["olvidé mi contraseña", "recuperar contraseña", "recuperar acceso", "restablecer clave"],
  logout: ["cerrar sesión", "salir de mi cuenta"],
  contact: ["contacto", "soporte", "hablar con el equipo"],
});

// input: { path, label, source, observedAccess? ('account' when an unauthenticated GET was
// redirected to the sign-in page) }. Output: { area, access, action, confidence, reasons[] }.
export function classifyLink({ path, label = "", source = "body", observedAccess = null }) {
  const p = String(path || "/").toLowerCase();
  const l = String(label || "").toLowerCase();
  const reasons = [];
  const pathOrLabel = (rule) => {
    const byPath = rule.test(p);
    const byLabel = rule.test(l);
    return byPath || byLabel ? { byPath, byLabel } : null;
  };
  const conf = (m) => (m.byPath && m.byLabel ? 0.95 : m.byPath ? 0.85 : 0.7);

  let m;
  if ((m = pathOrLabel(RULES.logout))) return done("authentication", "account", "logout", conf(m), "logout_rule");
  if (RULES.administrative.test(p)) return done("administrative", "administrative", "browse", 0.9, "administrative_path");
  if ((m = pathOrLabel(RULES.recover_account))) return done("authentication", "public", "recover_account", conf(m), "recover_rule");
  if ((m = pathOrLabel(RULES.register))) return done("authentication", "public", "register", conf(m), "register_rule");
  if ((m = pathOrLabel(RULES.sign_in))) return done("authentication", "public", "sign_in", conf(m), "sign_in_rule");
  if (observedAccess === "account" || RULES.account.test(p)) {
    const action = RULES.create.test(p) ? "create" : RULES.configure.test(p) ? "configure" : "browse";
    return done("account_navigation", "account", action, observedAccess === "account" ? 0.95 : 0.75, observedAccess === "account" ? "redirected_to_sign_in" : "account_path");
  }
  if ((m = pathOrLabel(RULES.legal))) return done("legal", "public", "read", conf(m), "legal_rule");
  if ((m = pathOrLabel(RULES.contact))) return done("support", "public", "contact", conf(m), "contact_rule");
  if ((m = pathOrLabel(RULES.faq))) return done("support", "public", "read", conf(m), "faq_rule");
  if ((m = pathOrLabel(RULES.trust))) return done("support", "public", "read", conf(m) - 0.05, "trust_rule");
  const area = source === "header" || source === "nav" ? "primary_navigation" : source === "footer" ? "footer" : "content";
  return done(area, "public", "browse", source === "body" ? 0.5 : 0.7, `source_${source}`);

  function done(area, access, action, confidence, reason) {
    reasons.push(reason);
    return { area, access, action, confidence: Math.round(confidence * 100) / 100, reasons };
  }
}

export function defaultIntentsFor(action, label) {
  const base = DEFAULT_INTENTS[action] ? [...DEFAULT_INTENTS[action]] : [];
  const clean = String(label || "").trim().toLowerCase();
  if (clean && clean.length <= 60 && !base.includes(clean)) base.unshift(clean);
  return base.slice(0, 12);
}

// Stable, readable id from area + path: "/preguntas-frecuentes" -> "support-preguntas-frecuentes".
export function idFor(area, path, prefix = null) {
  const slug = String(path || "/").toLowerCase().replace(/^\/+|\/+$/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "home";
  const head = prefix || ({ authentication: "auth", primary_navigation: "nav", account_navigation: "account", footer: "footer", support: "support", legal: "legal", content: "page", administrative: "admin" }[area] || "page");
  return `${head}-${slug}`.slice(0, 64).replace(/-+$/g, "");
}
