// Warp Discovery -- dependency-free HTML extraction. NEVER executes scripts.
//
// Extracts: title, meta description, canonical, robots meta, links grouped by region
// (header/nav/footer/body), public JSON-LD (parsed as data only), forms (observation only:
// action, method and field NAMES/TYPES -- never values), and visible text organized as sections.
//
// Untrusted-content rules: <script>, <style>, <noscript>, <template>, <iframe>, <svg>, comments and
// anything hidden (hidden attribute, aria-hidden="true", inline display:none / visibility:hidden)
// are removed BEFORE text is read. Text is data; nothing extracted here ever becomes a rule.

const DROP_BLOCKS = /<(script|style|noscript|template|iframe|svg|object|embed|canvas|math)\b[^>]*>[\s\S]*?<\/\1\s*>/gi;
const COMMENTS = /<!--[\s\S]*?-->/g;
const VOID_HIDDEN = /<(input|img|meta|link)\b[^>]*>/gi;

export function decodeEntities(text) {
  return String(text)
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&#(\d{1,6});/g, (_, n) => safeCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]{1,6});/gi, (_, n) => safeCodePoint(parseInt(n, 16)));
}

function safeCodePoint(n) {
  if (!Number.isFinite(n) || n <= 0 || n > 0x10ffff || (n >= 0xd800 && n <= 0xdfff)) return "";
  if (n < 32 && n !== 9 && n !== 10 && n !== 13) return "";
  return String.fromCodePoint(n);
}

function attr(tag, name) {
  const m = tag.match(new RegExp(`\\s${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return m ? decodeEntities(m[1] ?? m[2] ?? m[3] ?? "") : null;
}

function stripTags(html) {
  return decodeEntities(html.replace(/<br\s*\/?>/gi, " ").replace(/<[^>]+>/g, " ")).replace(/[​-‍﻿‪-‮⁦-⁩]/g, "").replace(/\s+/g, " ").trim();
}

function isHiddenTag(openTag) {
  if (/\shidden(?:\s|=|>|\/)/i.test(openTag)) return true;
  if (/aria-hidden\s*=\s*["']?true/i.test(openTag)) return true;
  const style = attr(openTag, "style");
  if (style && /(display\s*:\s*none|visibility\s*:\s*hidden|font-size\s*:\s*0|opacity\s*:\s*0(?:[;\s]|$))/i.test(style)) return true;
  return false;
}

// Removes hidden elements (with their content). Handles nesting of the same tag name.
function removeHidden(html) {
  let out = html;
  for (let guard = 0; guard < 200; guard += 1) {
    const re = /<([a-z][a-z0-9]*)\b[^>]*>/gi;
    let match;
    let found = null;
    while ((match = re.exec(out))) {
      if (isHiddenTag(match[0])) { found = match; break; }
    }
    if (!found) break;
    const tag = found[1].toLowerCase();
    const start = found.index;
    if (/\/>$/.test(found[0]) || ["input", "img", "br", "hr", "meta", "link"].includes(tag)) { out = out.slice(0, start) + out.slice(start + found[0].length); continue; }
    const openRe = new RegExp(`<${tag}\\b[^>]*>|</${tag}\\s*>`, "gi");
    openRe.lastIndex = start + found[0].length;
    let depth = 1;
    let end = out.length;
    let m;
    while ((m = openRe.exec(out))) {
      if (m[0][1] === "/") depth -= 1; else depth += 1;
      if (depth === 0) { end = m.index + m[0].length; break; }
    }
    out = out.slice(0, start) + out.slice(end);
  }
  return out;
}

function sliceRegion(html, tag) {
  const regions = [];
  const re = new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)</${tag}\\s*>`, "gi");
  let m;
  while ((m = re.exec(html))) regions.push(m[1]);
  return regions;
}

function linksIn(fragment) {
  const out = [];
  const re = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi;
  let m;
  while ((m = re.exec(fragment))) {
    const open = `<a ${m[1]}>`;
    const href = attr(open, "href");
    if (!href) continue;
    const rel = (attr(open, "rel") || "").toLowerCase();
    const label = (stripTags(m[2]) || attr(open, "aria-label") || attr(open, "title") || "").slice(0, 120);
    out.push({ href, label, nofollow: rel.includes("nofollow") });
  }
  return out;
}

export function extractPage(rawHtml, { maxSections = 60 } = {}) {
  const htmlNoComments = String(rawHtml || "").replace(COMMENTS, " ");
  // JSON-LD is read BEFORE scripts are dropped, as data only, and only when it parses as JSON.
  const jsonLd = [];
  const ldRe = /<script\b[^>]*type\s*=\s*["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script\s*>/gi;
  let ld;
  while ((ld = ldRe.exec(htmlNoComments)) && jsonLd.length < 10) {
    try { const parsed = JSON.parse(ld[1].trim()); jsonLd.push(parsed); } catch { /* ignored: not data */ }
  }
  const head = (htmlNoComments.match(/<head\b[^>]*>([\s\S]*?)<\/head\s*>/i) || [])[1] || "";
  const title = stripTags((head.match(/<title\b[^>]*>([\s\S]*?)<\/title\s*>/i) || [])[1] || "").slice(0, 160);
  let description = null; let canonical = null; let robots = null;
  for (const tag of head.match(/<(meta|link)\b[^>]*>/gi) || []) {
    const name = (attr(tag, "name") || attr(tag, "property") || "").toLowerCase();
    if (/^<meta/i.test(tag) && (name === "description" || name === "og:description") && !description) description = (attr(tag, "content") || "").slice(0, 300);
    if (/^<meta/i.test(tag) && name === "robots") robots = (attr(tag, "content") || "").toLowerCase();
    if (/^<link/i.test(tag) && (attr(tag, "rel") || "").toLowerCase() === "canonical") canonical = attr(tag, "href");
  }
  const body = (htmlNoComments.match(/<body\b[^>]*>([\s\S]*)<\/body\s*>/i) || [null, htmlNoComments])[1];
  const cleaned = removeHidden(body.replace(DROP_BLOCKS, " "));
  // Forms -- observation only (never submitted). Field values are never read.
  const forms = [];
  const formRe = /<form\b([^>]*)>([\s\S]*?)<\/form\s*>/gi;
  let f;
  while ((f = formRe.exec(cleaned)) && forms.length < 20) {
    const open = `<form ${f[1]}>`;
    const fields = [];
    for (const tag of f[2].match(/<(input|select|textarea)\b[^>]*>/gi) || []) {
      const type = (attr(tag, "type") || tag.match(/^<(\w+)/)[1]).toLowerCase();
      if (type === "hidden") { fields.push({ name: "(hidden)", type: "hidden" }); continue; }
      const name = (attr(tag, "name") || attr(tag, "id") || "").slice(0, 60);
      fields.push({ name, type });
    }
    forms.push({ action: attr(open, "action") || "", method: (attr(open, "method") || "get").toLowerCase(), fields: fields.slice(0, 40) });
  }
  const headerHtml = sliceRegion(cleaned, "header").join(" ");
  const footerHtml = sliceRegion(cleaned, "footer").join(" ");
  const navHtml = sliceRegion(cleaned, "nav").join(" ");
  const headerLinks = linksIn(headerHtml);
  const footerLinks = linksIn(footerHtml);
  const navLinks = linksIn(navHtml).filter((l) => !headerLinks.some((h) => h.href === l.href) && !footerLinks.some((h) => h.href === l.href));
  const mainHtml = (cleaned.match(/<main\b[^>]*>([\s\S]*?)<\/main\s*>/i) || [])[1]
    || cleaned.replace(/<(header|footer|nav)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ");
  const bodyLinks = linksIn(mainHtml);
  const sections = extractSections(mainHtml.replace(VOID_HIDDEN, " "), maxSections);
  return { title, description, canonical, robots, jsonLd, forms, links: { header: headerLinks, nav: navLinks, footer: footerLinks, body: bodyLinks }, sections };
}

// Splits visible text into sections at h1-h4; paragraphs/list items/table cells become text.
function extractSections(html, maxSections) {
  const sections = [];
  let current = { heading: null, parts: [] };
  const tokenRe = /<(h[1-4])\b[^>]*>([\s\S]*?)<\/\1\s*>|<(p|li|td|th|dd|dt|blockquote|figcaption|summary)\b[^>]*>([\s\S]*?)<\/\3\s*>/gi;
  let t;
  while ((t = tokenRe.exec(html))) {
    if (t[1]) {
      if (current.heading || current.parts.length) sections.push(current);
      current = { heading: stripTags(t[2]).slice(0, 160) || null, parts: [] };
    } else {
      const text = stripTags(t[4]);
      if (text) current.parts.push(text);
    }
    if (sections.length >= maxSections) break;
  }
  if ((current.heading || current.parts.length) && sections.length < maxSections) sections.push(current);
  return sections.map((s) => ({ heading: s.heading, text: s.parts.join("\n").slice(0, 4000) })).filter((s) => s.heading || s.text);
}
