// Warp Discovery -- SCAN mode crawler. Observes; never acts.
//
// Same authorized origin only. GET/HEAD only (safeFetch.js). Never submits forms, never signs in,
// never follows logout, never fetches administrative pages; authentication and account pages are
// known from their LINK only (fetching them is off by default). Respects robots.txt, caps pages,
// depth, concurrency, rate, total time and repeated path templates. Produces an inventory (data),
// never a capability.

import { createNetPolicy } from "./netPolicy.js";
import { createSafeFetcher } from "./safeFetch.js";
import { normalizeLink, pathTemplate } from "./normalizer.js";
import { extractPage } from "./htmlExtract.js";
import { classifyLink } from "./classifier.js";
import { looksLikeInstruction, redactPersonalData, findStatedDate } from "./contentSafety.js";
import { CONTRACT_VERSIONS, LIMITS } from "./contracts.js";
import { hashOf } from "./hash.js";

export const DEFAULT_SCAN_LIMITS = Object.freeze({
  maxPages: 50,
  maxDepth: 3,
  concurrency: 2,
  delayMs: 1000,
  maxBytes: 1_000_000,
  timeoutMs: 10_000,
  totalTimeMs: 180_000,
  maxPerTemplate: 5,
  maxRedirects: 3,
  maxSitemapUrls: 200,
});

const HARD_CAPS = Object.freeze({ maxPages: 500, maxDepth: 6, concurrency: 4, maxBytes: 5_000_000 });

function clampLimits(limits) {
  const out = { ...DEFAULT_SCAN_LIMITS, ...(limits || {}) };
  out.maxPages = Math.max(1, Math.min(HARD_CAPS.maxPages, Math.floor(out.maxPages)));
  out.maxDepth = Math.max(0, Math.min(HARD_CAPS.maxDepth, Math.floor(out.maxDepth)));
  out.concurrency = Math.max(1, Math.min(HARD_CAPS.concurrency, Math.floor(out.concurrency)));
  out.maxBytes = Math.max(10_000, Math.min(HARD_CAPS.maxBytes, Math.floor(out.maxBytes)));
  out.delayMs = Math.max(0, Math.floor(out.delayMs));
  return out;
}

export function parseRobots(text, agentToken = "warpdiscovery") {
  const groups = [];
  let current = null;
  for (const rawLine of String(text || "").split(/\r?\n/).slice(0, 2000)) {
    const line = rawLine.replace(/#.*/, "").trim();
    const m = line.match(/^([A-Za-z-]+)\s*:\s*(.*)$/);
    if (!m) continue;
    const key = m[1].toLowerCase(); const value = m[2].trim();
    if (key === "user-agent") {
      if (!current || current.rules.length) { current = { agents: [], rules: [] }; groups.push(current); }
      current.agents.push(value.toLowerCase());
    } else if ((key === "disallow" || key === "allow") && current) {
      current.rules.push({ allow: key === "allow", path: value });
    }
  }
  const mine = groups.filter((g) => g.agents.some((a) => a !== "*" && agentToken.includes(a)));
  const rules = (mine.length ? mine : groups.filter((g) => g.agents.includes("*"))).flatMap((g) => g.rules);
  return function isAllowed(path) {
    let best = null;
    for (const rule of rules) {
      if (!rule.path) continue;
      const pattern = new RegExp(`^${rule.path.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\\\$$/, "$")}`);
      if (pattern.test(path) && (!best || rule.path.length > best.path.length || (rule.path.length === best.path.length && rule.allow))) best = rule;
    }
    return !best || best.allow;
  };
}

function sleep(ms, signal) {
  return new Promise((resolve) => {
    if (!ms) return resolve();
    const t = setTimeout(resolve, ms);
    signal?.addEventListener?.("abort", () => { clearTimeout(t); resolve(); }, { once: true });
  });
}

// Splits long text into contract-sized chunks without cutting words.
function chunkText(text, max) {
  const out = [];
  let rest = String(text || "").trim();
  while (rest.length > max) {
    let cut = rest.lastIndexOf(" ", max);
    if (cut < max * 0.6) cut = max;
    out.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  if (rest) out.push(rest);
  return out;
}

export function sanitizeSections(rawSections) {
  const sections = [];
  const quarantined = [];
  const redactions = { email: 0, rut: 0, card: 0, phone: 0 };
  for (const raw of rawSections) {
    const heading = raw.heading ? redactPersonalData(raw.heading) : null;
    const body = redactPersonalData(raw.text || "");
    for (const k of Object.keys(redactions)) redactions[k] += body.redactions[k] + (heading ? heading.redactions[k] : 0);
    const headingText = heading ? heading.text.slice(0, LIMITS.SECTION_HEADING_MAX) : null;
    if (looksLikeInstruction(headingText) || looksLikeInstruction(body.text)) {
      quarantined.push({ heading: headingText ? headingText.slice(0, 80) : null, reason: "instruction_like_text" });
      continue;
    }
    const chunks = chunkText(body.text, LIMITS.SECTION_TEXT_MAX);
    if (chunks.length === 0 && headingText) continue; // heading with no text carries nothing to read
    chunks.forEach((text, index) => sections.push({ heading: index === 0 ? headingText : headingText ? `${headingText} (cont.)`.slice(0, LIMITS.SECTION_HEADING_MAX) : null, text }));
  }
  return { sections: sections.slice(0, LIMITS.SECTIONS_MAX), quarantined, redactions };
}

export async function scanSite({ origin, limits, allowHttp = false, allowLoopbackForTests = false, allowedQueryParams = [], fetchAuthPages = false, fetchAccountPages = false, respectRobots = true, fetcher = null, lookupImpl = null, signal = null, now = () => new Date() } = {}) {
  const L = clampLimits(limits);
  const policy = createNetPolicy({ origin, allowHttp, allowLoopbackForTests, lookupImpl });
  const controller = new AbortController();
  const onOuterAbort = () => controller.abort();
  signal?.addEventListener?.("abort", onOuterAbort, { once: true });
  const deadline = setTimeout(() => controller.abort(), L.totalTimeMs);
  // A redirect is followed only into a page the crawler would fetch by itself: never into sign-in,
  // registration, recovery, logout, administrative, account or API paths.
  const fetchable = (u) => {
    const c = classifyLink({ path: u.pathname });
    if (c.action === "logout" || c.area === "administrative" || /^\/api(?:\/|$)/.test(u.pathname)) return false;
    if (c.area === "authentication" && !fetchAuthPages) return false;
    if (c.area === "account_navigation" && !fetchAccountPages) return false;
    return true;
  };
  const http = fetcher || createSafeFetcher(policy, { maxBytes: L.maxBytes, timeoutMs: L.timeoutMs, maxRedirects: L.maxRedirects, signal: controller.signal, shouldFollowRedirect: fetchable });
  const base = new URL(policy.authorizedOrigin);
  const startedAt = now().toISOString();
  const stats = { fetched: 0, skipped: {}, errors: {}, externalLinks: 0, robotsRespected: respectRobots };
  const skip = (reason) => { stats.skipped[reason] = (stats.skipped[reason] || 0) + 1; };
  const fail = (code) => { stats.errors[code] = (stats.errors[code] || 0) + 1; };

  let isAllowed = () => true;
  if (respectRobots) {
    try {
      const robots = await http.fetch(new URL("/robots.txt", base));
      if (robots.status === 200 && robots.body) isAllowed = parseRobots(robots.body);
    } catch { /* no robots.txt -> default allow */ }
  }

  const links = new Map(); // path -> aggregated link observation
  const pages = [];
  const forms = [];
  const endpoints = new Map();
  const quarantinedAll = [];
  const redactionTotals = { email: 0, rut: 0, card: 0, phone: 0 };
  const queued = new Set();
  const templates = new Map();
  const queue = [];

  function noteLink(normalized, label, source, foundOn, depth) {
    const key = normalized.path;
    let entry = links.get(key);
    if (!entry) { entry = { path: key, labels: {}, sources: [], foundOn: [], firstDepth: depth }; links.set(key, entry); }
    if (label) entry.labels[label] = (entry.labels[label] || 0) + 1;
    if (!entry.sources.includes(source)) entry.sources.push(source);
    if (foundOn && entry.foundOn.length < 5 && !entry.foundOn.includes(foundOn)) entry.foundOn.push(foundOn);
    if (/^\/api(?:\/|$)/.test(key)) endpoints.set(key, { path: key, via: "link", foundOn });
    return entry;
  }

  function enqueue(normalized, depth, label, source) {
    const cls = classifyLink({ path: normalized.path, label, source });
    if (cls.action === "logout") return skip("logout_never_followed");
    if (cls.area === "administrative") return skip("administrative_never_fetched");
    if (cls.area === "authentication" && !fetchAuthPages) return skip("auth_page_not_fetched");
    if (cls.area === "account_navigation" && !fetchAccountPages) return skip("account_page_not_fetched");
    if (/^\/api(?:\/|$)/.test(normalized.path)) return skip("endpoint_never_fetched");
    if (depth > L.maxDepth) return skip("max_depth");
    if (queued.has(normalized.key)) return undefined;
    if (!isAllowed(normalized.path)) {
      const observed = links.get(normalized.path);
      if (observed) observed.robotsDisallowed = true;
      return skip("robots_disallow");
    }
    const tpl = pathTemplate(normalized.path);
    const count = templates.get(tpl) || 0;
    if (count >= L.maxPerTemplate) return skip("template_cap");
    templates.set(tpl, count + 1);
    queued.add(normalized.key);
    queue.push({ url: normalized.url, path: normalized.path, depth });
    return undefined;
  }

  const norm = (href, at) => normalizeLink(href, at, { authorizedOrigin: policy.authorizedOrigin, allowedQueryParams });
  const root = norm("/", base);
  queued.add(root.key);
  queue.push({ url: root.url, path: root.path, depth: 0 });
  templates.set(pathTemplate(root.path), 1);

  // Sitemap (data only): its URLs are seeds at depth 1, still subject to every rule above.
  try {
    const sm = await http.fetch(new URL("/sitemap.xml", base));
    if (sm.status === 200 && sm.body) {
      const locs = [...sm.body.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/gi)].slice(0, L.maxSitemapUrls);
      for (const [, loc] of locs) {
        const n = norm(loc, base);
        if (!n.ok) { if (n.reason === "cross_origin") stats.externalLinks += 1; continue; }
        noteLink(n, null, "sitemap", "/sitemap.xml", 1);
        enqueue(n, 1, null, "sitemap");
      }
    }
  } catch { /* no sitemap */ }

  async function visit(item) {
    let res;
    try {
      res = await http.fetch(item.url);
      stats.fetched += 1;
    } catch (error) {
      fail(error.code || "NETWORK");
      pages.push({ path: item.path, depth: item.depth, error: error.code || "NETWORK" });
      return;
    }
    const finalPath = res.finalUrl.pathname;
    const redirectedToSignIn = res.redirects.length > 0 && classifyLink({ path: finalPath }).action === "sign_in";
    if (res.redirectStopped && !redirectedToSignIn) {
      pages.push({ path: item.path, depth: item.depth, status: res.status, redirectStoppedAt: finalPath });
      return;
    }
    if (res.redirects.length && finalPath !== item.path) queued.add(finalPath);
    if (redirectedToSignIn) {
      // An unauthenticated GET bounced to the sign-in page: the ORIGINAL path requires a session.
      const entry = links.get(item.path) || noteLink({ path: item.path }, null, "redirect", null, item.depth);
      entry.observedAccess = "account";
      pages.push({ path: item.path, depth: item.depth, status: res.status, redirectedTo: finalPath, observedAccess: "account" });
      return;
    }
    if (res.status !== 200 || !res.body || !/html/.test(res.mime || "")) {
      pages.push({ path: item.path, depth: item.depth, status: res.status, mime: res.mime || null, broken: res.status >= 400 });
      return;
    }
    const page = extractPage(res.body);
    const safe = sanitizeSections(page.sections);
    for (const k of Object.keys(redactionTotals)) redactionTotals[k] += safe.redactions[k];
    for (const q of safe.quarantined) quarantinedAll.push({ path: finalPath, ...q });
    const canonical = page.canonical ? norm(page.canonical, res.finalUrl) : null;
    const fullText = page.sections.map((s) => `${s.heading || ""} ${s.text || ""}`).join(" ");
    const record = {
      path: item.path,
      finalPath,
      depth: item.depth,
      status: res.status,
      title: redactPersonalData(page.title).text,
      description: page.description ? redactPersonalData(page.description).text : null,
      canonicalPath: canonical && canonical.ok ? canonical.path : null,
      noindex: /noindex/.test(page.robots || ""),
      jsonLdTypes: page.jsonLd.flatMap((d) => [].concat(d && d["@type"] ? d["@type"] : [])).slice(0, 10).map(String),
      sections: safe.sections,
      quarantinedSections: safe.quarantined.length,
      effectiveDate: findStatedDate(fullText, "effective"),
      updatedAt: findStatedDate(fullText, "updated"),
    };
    record.contentHash = hashOf({ title: record.title, sections: record.sections });
    pages.push(record);
    for (const [region, list] of Object.entries(page.links)) {
      for (const link of list) {
        const n = norm(link.href, res.finalUrl);
        if (!n.ok) { if (n.reason === "cross_origin") stats.externalLinks += 1; else skip(`link_${n.reason}`); continue; }
        noteLink(n, redactPersonalData(link.label).text.slice(0, LIMITS.LABEL_MAX), region, finalPath, item.depth + 1);
        if (link.nofollow) { skip("nofollow"); continue; }
        enqueue(n, item.depth + 1, link.label, region);
      }
    }
    for (const form of page.forms) {
      const n = form.action ? norm(form.action, res.finalUrl) : { ok: true, path: finalPath };
      forms.push({ foundOn: finalPath, actionPath: n.ok ? n.path : null, external: !n.ok && n.reason === "cross_origin", method: form.method, fields: form.fields.map((f) => ({ name: f.name, type: f.type })) });
      if (n.ok && /^\/api(?:\/|$)/.test(n.path)) endpoints.set(n.path, { path: n.path, via: "form", foundOn: finalPath });
    }
  }

  // Bounded worker pool with a conservative per-worker delay.
  async function worker() {
    while (!controller.signal.aborted) {
      const item = queue.shift();
      if (!item) return;
      if (stats.fetched + Object.values(stats.errors).reduce((a, b) => a + b, 0) >= L.maxPages) { skip("max_pages"); continue; }
      await visit(item);
      await sleep(L.delayMs, controller.signal);
    }
  }
  try {
    // Re-spawn workers while new items keep arriving and capacity remains.
    while (queue.length && !controller.signal.aborted && stats.fetched < L.maxPages) {
      await Promise.all(Array.from({ length: Math.min(L.concurrency, queue.length) }, worker));
    }
  } finally {
    clearTimeout(deadline);
    signal?.removeEventListener?.("abort", onOuterAbort);
  }
  if (controller.signal.aborted) stats.cancelled = true;
  for (const item of queue) skip("not_reached");

  return {
    contract: CONTRACT_VERSIONS.INVENTORY,
    origin: policy.authorizedOrigin,
    startedAt,
    finishedAt: now().toISOString(),
    limits: L,
    stats,
    pages,
    links: [...links.values()],
    forms,
    endpoints: [...endpoints.values()],
    quarantined: quarantinedAll,
    redactions: redactionTotals,
  };
}
