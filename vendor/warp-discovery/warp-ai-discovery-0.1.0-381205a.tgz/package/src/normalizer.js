// Warp Discovery -- URL normalizer. Canonicalizes same-origin links and removes noise and traps.

const SENSITIVE_PARAM = /token|code|session|sess|sid|key|secret|pass|auth|sig|signature|state|nonce|email|mail|phone|rut|user|uid|jwt|otp|reset|ticket|redirect|next|return|callback|ref/i;
const BINARY_EXT = /\.(?:png|jpe?g|gif|webp|avif|svg|ico|bmp|tiff?|pdf|zip|gz|tgz|rar|7z|tar|mp3|mp4|m4a|wav|ogg|webm|mov|avi|woff2?|ttf|otf|eot|exe|dmg|apk|msi|bin|iso|doc|docx|xls|xlsx|ppt|pptx|csv|json|js|mjs|css|map|wasm)$/i;

// Returns { ok:true, url, path } or { ok:false, reason }.
export function normalizeLink(href, baseUrl, { authorizedOrigin, allowedQueryParams = [], maxPathLength = 200, maxSegments = 8 } = {}) {
  if (typeof href !== "string") return { ok: false, reason: "not_string" };
  const trimmed = href.trim();
  if (!trimmed || trimmed.startsWith("#")) return { ok: false, reason: "fragment_only" };
  if (/^(?:javascript|data|file|ftp|mailto|tel|sms|blob|about|vbscript|ws|wss|chrome|intent):/i.test(trimmed)) return { ok: false, reason: "scheme" };
  let url;
  try { url = new URL(trimmed, baseUrl); } catch { return { ok: false, reason: "invalid" }; }
  if (url.protocol !== "https:" && url.protocol !== "http:") return { ok: false, reason: "scheme" };
  if (url.username || url.password) return { ok: false, reason: "credentials" };
  if (url.origin !== authorizedOrigin) return { ok: false, reason: "cross_origin" };
  url.hash = "";
  // Query control: drop everything except explicitly allowlisted, non-sensitive params, sorted.
  const kept = [];
  for (const [name, value] of url.searchParams) {
    if (allowedQueryParams.includes(name) && !SENSITIVE_PARAM.test(name) && value.length <= 40) kept.push([name, value]);
  }
  kept.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  url.search = kept.length ? `?${kept.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&")}` : "";
  let path = url.pathname.replace(/\/{2,}/g, "/");
  try { path = decodeURI(path); path = encodeURI(path); } catch { return { ok: false, reason: "encoding" }; }
  if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
  if (/\/\.\.?(?:\/|$)/.test(path)) return { ok: false, reason: "traversal" };
  if (path.length > maxPathLength) return { ok: false, reason: "path_too_long" };
  const segments = path.split("/").filter(Boolean);
  if (segments.length > maxSegments) return { ok: false, reason: "too_deep_path" };
  if (hasRepeatingSegments(segments)) return { ok: false, reason: "repeating_segments" };
  if (BINARY_EXT.test(path)) return { ok: false, reason: "binary_extension" };
  url.pathname = path;
  return { ok: true, url, path, key: `${path}${url.search}` };
}

function hasRepeatingSegments(segments) {
  // /a/b/a/b or /x/x/x -- typical of relative-link loops.
  const counts = new Map();
  for (const s of segments) counts.set(s, (counts.get(s) || 0) + 1);
  if ([...counts.values()].some((n) => n >= 3)) return true;
  for (let size = 1; size <= Math.floor(segments.length / 2); size += 1) {
    const tail = segments.slice(-size).join("/");
    const prev = segments.slice(-2 * size, -size).join("/");
    if (tail === prev) return true;
  }
  return false;
}

// Collapses ids, numbers, dates and slugs with digits into placeholders, so /eventos/2026/11/16,
// /eventos/2026/11/17 ... or /page/1..999 share ONE template that is capped per crawl.
export function pathTemplate(path) {
  return path
    .split("/")
    .map((s) => {
      if (/^\d{4}-\d{2}-\d{2}$/.test(s) || /^\d+$/.test(s)) return ":n";
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s)) return ":uuid";
      if (/\d/.test(s) && s.length > 6) return ":slug";
      return s;
    })
    .join("/");
}

export function isSensitiveParamName(name) {
  return SENSITIVE_PARAM.test(String(name));
}
