// Warp Discovery -- shared, versioned contracts (2026-11-16).
//
// ONE module that every stage reads: the crawler (producer of observations), the candidate builder,
// the Connector verifier, the approval registry, the publisher and the serve-side capabilities.
// Kept in its own file and commit on purpose: if the shape of a contract ever changes, it changes
// here once, with a new version string, instead of drifting between producer and consumer.
//
// Principle encoded by these contracts:
//   the crawler DISCOVERS -> the Connector VERIFIES -> a person APPROVES -> Discovery PUBLISHES
//   -> Warp uses ONLY what was published.
// Nothing observed is ever a permission. An `account` or `administrative` page may be KNOWN as
// navigation; knowing it never grants access, data or capabilities.

export const CONTRACT_VERSIONS = Object.freeze({
  INVENTORY: "warp.discovery_inventory.v1",
  CANDIDATES: "warp.discovery_candidates.v1",
  APPROVALS: "warp.discovery_approvals.v1",
  SITE_MAP: "warp.site_map.v1",
  INSTALLED: "warp.discovery_installed.v1",
  DIFF: "warp.discovery_diff.v1",
});

export const KINDS = Object.freeze({
  NAVIGATION: "navigation",
  PUBLIC_CONTENT: "public_content",
  FORM_OBSERVATION: "form_observation",
  ENDPOINT_OBSERVATION: "endpoint_observation",
});

export const AREAS = Object.freeze([
  "primary_navigation",
  "account_navigation",
  "footer",
  "authentication",
  "support",
  "legal",
  "content",
  "administrative",
  // Added 2026-11-16 (owner review of the first real site): public commercial pages (pricing,
  // commissions) and solution/landing pages. Public by contract. Appended, so earlier ids/order hold.
  "commercial",
  "solutions",
]);

export const PUBLIC_ONLY_AREAS = Object.freeze(["legal", "support", "commercial", "solutions"]);

export const ACCESS = Object.freeze(["public", "account", "administrative"]);

export const ACTIONS = Object.freeze([
  "browse",
  "read",
  "sign_in",
  "register",
  "recover_account",
  "create",
  "configure",
  "contact",
  "logout",
]);

// Authentication actions: the entry that answers them must be PUBLIC and in the authentication area.
// A page that requires a session can never answer "where do I sign in".
export const AUTH_ACTIONS = Object.freeze(["sign_in", "register", "recover_account"]);

export const STATUSES = Object.freeze(["observed", "candidate", "verified", "approved", "published", "rejected", "stale"]);

export const CHANGE_STATES = Object.freeze(["unchanged", "changed", "missing", "new", "stale"]);

export const SOURCES = Object.freeze(["header", "nav", "footer", "body", "sitemap", "canonical", "jsonld", "redirect", "installed", "declared"]);

export const LIMITS = Object.freeze({
  ID_MAX: 64,
  LABEL_MAX: 80,
  HREF_MAX: 200,
  INTENTS_MAX: 12,
  INTENT_MAX: 60,
  NAVIGATION_MAX: 100, // = Connector MAX_ENUM_MEMBERS: every published id fits a closed enum
  CONTENT_DOCS_MAX: 40,
  SECTIONS_MAX: 60,
  SECTION_HEADING_MAX: 160,
  SECTION_TEXT_MAX: 1500,
  CONTENT_TOTAL_MAX: 60000,
  TITLE_MAX: 160,
  SECTIONS_PER_PAGE: 6,
  KEY_FACTS_MAX: 10,
  KEY_FACT_QUOTE_MAX: 300,
});

const ID_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const HASH_PATTERN = /^[a-f0-9]{64}$/;
// A published href is ALWAYS a same-site, relative path: no scheme, no host, no query, no fragment.
// Warp never receives (and site.content.read never accepts) an arbitrary URL.
const HREF_PATTERN = /^\/(?:[A-Za-z0-9._~\-]+(?:\/[A-Za-z0-9._~\-]+)*)?$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,9})?)?(?:Z|[+-]\d{2}:\d{2}))?$/;

export function isValidId(value) {
  return typeof value === "string" && value.length <= LIMITS.ID_MAX && ID_PATTERN.test(value);
}

export function isValidHref(value) {
  return typeof value === "string" && value.length <= LIMITS.HREF_MAX && HREF_PATTERN.test(value) && !value.includes("//") && !/\/\.\.?(?:\/|$)/.test(value);
}

export function isValidHash(value) {
  return typeof value === "string" && HASH_PATTERN.test(value);
}

export function isIsoDate(value) {
  return typeof value === "string" && ISO_DATE.test(value) && !Number.isNaN(Date.parse(value.length === 10 ? `${value}T00:00:00Z` : value));
}

function shortText(value, max) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= max;
}

// Returns a list of {code, path} problems -- never values, so an error list can be logged safely.
export function validateNavigationEntry(entry, path = "$") {
  const problems = [];
  const add = (code, field) => problems.push({ code, path: field ? `${path}.${field}` : path });
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
    add("NAV_NOT_OBJECT");
    return problems;
  }
  if (entry.kind !== KINDS.NAVIGATION) add("NAV_KIND_INVALID", "kind");
  if (!isValidId(entry.id)) add("NAV_ID_INVALID", "id");
  if (!shortText(entry.label, LIMITS.LABEL_MAX)) add("NAV_LABEL_INVALID", "label");
  if (!isValidHref(entry.href)) add("NAV_HREF_INVALID", "href");
  if (!AREAS.includes(entry.area)) add("NAV_AREA_INVALID", "area");
  if (!ACCESS.includes(entry.access)) add("NAV_ACCESS_INVALID", "access");
  if (!ACTIONS.includes(entry.action)) add("NAV_ACTION_INVALID", "action");
  if (!Array.isArray(entry.intents) || entry.intents.length > LIMITS.INTENTS_MAX || entry.intents.some((i) => !shortText(i, LIMITS.INTENT_MAX))) add("NAV_INTENTS_INVALID", "intents");
  if (entry.contentId !== null && entry.contentId !== undefined && !isValidId(entry.contentId)) add("NAV_CONTENT_ID_INVALID", "contentId");
  if (!STATUSES.includes(entry.status)) add("NAV_STATUS_INVALID", "status");
  if (entry.contentHash !== null && entry.contentHash !== undefined && !isValidHash(entry.contentHash)) add("NAV_HASH_INVALID", "contentHash");
  // Coherence rules -- the ones that make H-02 impossible by construction.
  if (AUTH_ACTIONS.includes(entry.action) && (entry.access !== "public" || entry.area !== "authentication")) add("NAV_AUTH_ACTION_NOT_PUBLIC_AUTH", "action");
  if (entry.area === "authentication" && !AUTH_ACTIONS.includes(entry.action) && entry.action !== "logout") add("NAV_AUTH_AREA_ACTION", "action");
  if (entry.action === "logout" && entry.access !== "account") add("NAV_LOGOUT_ACCESS", "access");
  if (entry.area === "administrative" && entry.access !== "administrative") add("NAV_ADMIN_ACCESS", "access");
  if (entry.access === "administrative" && entry.area !== "administrative") add("NAV_ADMIN_AREA", "area");
  if (entry.area === "account_navigation" && entry.access !== "account") add("NAV_ACCOUNT_ACCESS", "access");
  if (PUBLIC_ONLY_AREAS.includes(entry.area) && entry.access !== "public") add("NAV_PUBLIC_DOC_ACCESS", "access");
  return problems;
}

export function validateContentEntry(entry, path = "$") {
  const problems = [];
  const add = (code, field) => problems.push({ code, path: field ? `${path}.${field}` : path });
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
    add("CONTENT_NOT_OBJECT");
    return problems;
  }
  if (entry.kind !== KINDS.PUBLIC_CONTENT) add("CONTENT_KIND_INVALID", "kind");
  if (!isValidId(entry.id)) add("CONTENT_ID_INVALID", "id");
  if (!shortText(entry.title, LIMITS.TITLE_MAX)) add("CONTENT_TITLE_INVALID", "title");
  if (!isValidHref(entry.href)) add("CONTENT_HREF_INVALID", "href");
  if (!["legal", "support", "content"].includes(entry.area)) add("CONTENT_AREA_INVALID", "area");
  // Public content is public by definition: account/administrative pages are never content sources.
  if (entry.access !== "public") add("CONTENT_ACCESS_NOT_PUBLIC", "access");
  if (!isValidHash(entry.contentHash)) add("CONTENT_HASH_INVALID", "contentHash");
  for (const field of ["effectiveDate", "updatedAt", "scannedAt"]) {
    if (entry[field] !== null && entry[field] !== undefined && !isIsoDate(entry[field])) add("CONTENT_DATE_INVALID", field);
  }
  if (!STATUSES.includes(entry.status)) add("CONTENT_STATUS_INVALID", "status");
  if (!Array.isArray(entry.sections) || entry.sections.length === 0 || entry.sections.length > LIMITS.SECTIONS_MAX) {
    add("CONTENT_SECTIONS_INVALID", "sections");
  } else {
    let total = 0;
    entry.sections.forEach((section, index) => {
      const p = `sections[${index}]`;
      if (!section || typeof section !== "object") return add("CONTENT_SECTION_INVALID", p);
      if (!isValidId(section.id)) add("CONTENT_SECTION_ID_INVALID", `${p}.id`);
      if (section.heading !== null && section.heading !== undefined && !shortText(section.heading, LIMITS.SECTION_HEADING_MAX)) add("CONTENT_SECTION_HEADING_INVALID", `${p}.heading`);
      if (!shortText(section.text, LIMITS.SECTION_TEXT_MAX)) add("CONTENT_SECTION_TEXT_INVALID", `${p}.text`);
      if (section.quarantined) add("CONTENT_SECTION_QUARANTINED", p);
      total += (section.text || "").length + (section.heading || "").length;
    });
    if (total > LIMITS.CONTENT_TOTAL_MAX) add("CONTENT_TOO_LARGE", "sections");
    // keyFacts (2026-11-16): owner-approved structured fragments (e.g. a minimum-age rule). Each one is
    // a VERBATIM quote of an existing section, checked here -- a fact can never be invented or
    // reworded, only pointed at.
    if (entry.keyFacts !== undefined) {
      if (!Array.isArray(entry.keyFacts) || entry.keyFacts.length > LIMITS.KEY_FACTS_MAX) {
        add("CONTENT_KEY_FACTS_INVALID", "keyFacts");
      } else {
        const ids = new Set();
        entry.keyFacts.forEach((fact, index) => {
          const p = `keyFacts[${index}]`;
          if (!fact || typeof fact !== "object") return add("CONTENT_KEY_FACT_INVALID", p);
          if (!isValidId(fact.id) || ids.has(fact.id)) add("CONTENT_KEY_FACT_ID_INVALID", `${p}.id`);
          ids.add(fact.id);
          if (!shortText(fact.label, LIMITS.LABEL_MAX)) add("CONTENT_KEY_FACT_LABEL_INVALID", `${p}.label`);
          if (!shortText(fact.quote, LIMITS.KEY_FACT_QUOTE_MAX)) return add("CONTENT_KEY_FACT_QUOTE_INVALID", `${p}.quote`);
          const section = entry.sections.find((s) => s && s.id === fact.sectionId);
          if (!section) return add("CONTENT_KEY_FACT_SECTION_MISSING", `${p}.sectionId`);
          if (!squash(section.text).includes(squash(fact.quote))) add("CONTENT_KEY_FACT_NOT_VERBATIM", `${p}.quote`);
        });
      }
    }
  }
  return problems;
}

const squash = (text) => String(text || "").replace(/\s+/g, " ").trim();

// The ONLY shape the serve side accepts. Every entry must be `published`; anything else (observed,
// candidate, verified, approved-but-not-built, rejected, stale) makes the whole map invalid, so a
// candidate can never be served by accident -- the server refuses to start instead.
export function validatePublishedSiteMap(siteMap) {
  const problems = [];
  const add = (code, path) => problems.push({ code, path });
  if (!siteMap || typeof siteMap !== "object" || Array.isArray(siteMap)) {
    add("SITE_MAP_NOT_OBJECT", "$");
    return { ok: false, problems };
  }
  if (siteMap.contract !== CONTRACT_VERSIONS.SITE_MAP) add("SITE_MAP_CONTRACT_UNSUPPORTED", "$.contract");
  if (!isValidHash(siteMap.mapHash)) add("SITE_MAP_HASH_INVALID", "$.mapHash");
  if (!isIsoDate(siteMap.generatedAt)) add("SITE_MAP_DATE_INVALID", "$.generatedAt");
  const navigation = Array.isArray(siteMap.navigation) ? siteMap.navigation : null;
  const content = Array.isArray(siteMap.content) ? siteMap.content : null;
  if (!navigation || navigation.length > LIMITS.NAVIGATION_MAX) add("SITE_MAP_NAVIGATION_INVALID", "$.navigation");
  if (!content || content.length > LIMITS.CONTENT_DOCS_MAX) add("SITE_MAP_CONTENT_INVALID", "$.content");
  if (!navigation || !content) return { ok: false, problems };
  const ids = new Set();
  const contentIds = new Set(content.map((c) => c && c.id));
  navigation.forEach((entry, index) => {
    const path = `$.navigation[${index}]`;
    problems.push(...validateNavigationEntry(entry, path));
    if (entry?.status !== "published") add("SITE_MAP_ENTRY_NOT_PUBLISHED", `${path}.status`);
    if (entry?.access === "administrative" || entry?.area === "administrative") add("SITE_MAP_ADMIN_PUBLISHED", path);
    if (entry?.contentId && !contentIds.has(entry.contentId)) add("SITE_MAP_CONTENT_REF_MISSING", `${path}.contentId`);
    if (ids.has(entry?.id)) add("SITE_MAP_DUPLICATE_ID", `${path}.id`);
    ids.add(entry?.id);
  });
  content.forEach((entry, index) => {
    const path = `$.content[${index}]`;
    problems.push(...validateContentEntry(entry, path));
    if (entry?.status !== "published") add("SITE_MAP_ENTRY_NOT_PUBLISHED", `${path}.status`);
    if (ids.has(entry?.id)) add("SITE_MAP_DUPLICATE_ID", `${path}.id`);
    ids.add(entry?.id);
  });
  return { ok: problems.length === 0, problems };
}

export class DiscoveryContractError extends Error {
  constructor(code, message, problems = []) {
    super(message);
    this.name = "DiscoveryContractError";
    this.code = code;
    this.problems = problems.slice(0, 40);
  }
}

export function assertPublishedSiteMap(siteMap) {
  const result = validatePublishedSiteMap(siteMap);
  if (!result.ok) {
    const first = result.problems[0];
    throw new DiscoveryContractError(
      siteMap && siteMap.contract && siteMap.contract !== CONTRACT_VERSIONS.SITE_MAP ? "SITE_MAP_CONTRACT_UNSUPPORTED" : "SITE_MAP_INVALID",
      `Published site map is not servable (${first.code} at ${first.path}). Only a map built by "warp discover build" from approved entries can be served.`,
      result.problems,
    );
  }
  return siteMap;
}
