// Warp Discovery -- the ONLY network primitive the crawler uses.
//
// - GET/HEAD only. No body is ever sent; no cookies are sent or stored; Set-Cookie is ignored.
// - Every hop (initial URL and each redirect) is re-checked against the net policy: same authorized
//   origin, allowed scheme/port, public address. Redirects are followed manually, bounded.
// - The TCP connection is pinned to the address validated by policy.resolvePinned(): http(s).request
//   gets a `lookup` that returns that exact address, so the socket can never connect to a second,
//   different DNS answer (DNS rebinding). TLS still verifies the certificate for the real hostname.
// - Only allowlisted MIME types are read; anything else is aborted without reading the body.
// - The DECOMPRESSED body is capped (gzip/deflate/br are decoded as a stream and aborted the moment
//   the cap is passed), plus a compression-ratio cap -- a decompression bomb never fills memory.
// - Per-request timeout and an external AbortSignal for cancellation.

import http from "node:http";
import https from "node:https";
import zlib from "node:zlib";
import { NetPolicyError } from "./netPolicy.js";

export const FETCH_ERROR_CODES = Object.freeze({
  METHOD_NOT_ALLOWED: "METHOD_NOT_ALLOWED",
  TOO_MANY_REDIRECTS: "TOO_MANY_REDIRECTS",
  REDIRECT_INVALID: "REDIRECT_INVALID",
  MIME_NOT_ALLOWED: "MIME_NOT_ALLOWED",
  TOO_LARGE: "TOO_LARGE",
  COMPRESSION_RATIO: "COMPRESSION_RATIO",
  ENCODING_NOT_ALLOWED: "ENCODING_NOT_ALLOWED",
  TIMEOUT: "TIMEOUT",
  ABORTED: "ABORTED",
  NETWORK: "NETWORK",
});

export const DEFAULT_USER_AGENT = "WarpDiscovery/0.1 (read-only public crawler; no forms, no login)";
export const DEFAULT_ALLOWED_MIME = Object.freeze(["text/html", "application/xhtml+xml", "application/xml", "text/xml", "text/plain"]);

export class FetchError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.name = "FetchError";
    this.code = code;
    Object.assign(this, extra);
  }
}

export function createSafeFetcher(policy, {
  userAgent = DEFAULT_USER_AGENT,
  maxRedirects = 3,
  maxBytes = 1_000_000,
  maxCompressionRatio = 50,
  timeoutMs = 10_000,
  allowedMime = DEFAULT_ALLOWED_MIME,
  signal = null,
  requestImpl = null, // tests only: replaces http(s).request
  shouldFollowRedirect = null, // (url) => boolean; false = stop and report the redirect, never fetch it
} = {}) {
  async function fetchOnce(url, method) {
    const pinned = await policy.resolvePinned(url.hostname);
    const transport = requestImpl || (url.protocol === "https:" ? https.request : http.request);
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (fn, value) => { if (!settled) { settled = true; clearTimeout(timer); signal?.removeEventListener?.("abort", onAbort); fn(value); } };
      const req = transport({
        protocol: url.protocol,
        hostname: url.hostname,
        port: url.port || (url.protocol === "https:" ? 443 : 80),
        path: `${url.pathname}${url.search}`,
        method,
        servername: url.hostname,
        headers: {
          "User-Agent": userAgent,
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.5",
          "Accept-Encoding": "gzip, deflate, br",
        },
        // Pin: never resolve again; always connect to the address the policy validated.
        lookup: (_host, options, callback) => {
          if (options && options.all) callback(null, [{ address: pinned.address, family: pinned.family }]);
          else callback(null, pinned.address, pinned.family);
        },
        agent: false,
      }, (res) => {
        const status = res.statusCode || 0;
        const headers = res.headers || {};
        if (status >= 300 && status < 400) {
          res.resume();
          return finish(resolve, { status, headers, location: headers.location || null, body: null, pinnedAddress: pinned.address });
        }
        const mime = String(headers["content-type"] || "").split(";")[0].trim().toLowerCase();
        if (method === "HEAD") { res.resume(); return finish(resolve, { status, headers, mime, body: null, pinnedAddress: pinned.address }); }
        if (!allowedMime.includes(mime)) {
          res.destroy();
          return finish(reject, new FetchError(FETCH_ERROR_CODES.MIME_NOT_ALLOWED, "Content type not allowed.", { status, mime }));
        }
        const encoding = String(headers["content-encoding"] || "identity").trim().toLowerCase();
        let stream = res;
        if (encoding === "gzip" || encoding === "x-gzip") stream = res.pipe(zlib.createGunzip());
        else if (encoding === "deflate") stream = res.pipe(zlib.createInflate());
        else if (encoding === "br") stream = res.pipe(zlib.createBrotliDecompress());
        else if (encoding !== "identity" && encoding !== "") { res.destroy(); return finish(reject, new FetchError(FETCH_ERROR_CODES.ENCODING_NOT_ALLOWED, "Content encoding not allowed.")); }
        const declared = Number(headers["content-length"]);
        if (Number.isFinite(declared) && declared > maxBytes) { res.destroy(); return finish(reject, new FetchError(FETCH_ERROR_CODES.TOO_LARGE, "Response too large.", { status })); }
        let raw = 0;
        res.on("data", (chunk) => { raw += chunk.length; });
        const chunks = [];
        let total = 0;
        stream.on("data", (chunk) => {
          total += chunk.length;
          if (total > maxBytes) { res.destroy(); stream.destroy?.(); return finish(reject, new FetchError(FETCH_ERROR_CODES.TOO_LARGE, "Response too large.", { status })); }
          if (raw > 0 && encoding !== "identity" && total / raw > maxCompressionRatio && total > 64 * 1024) { res.destroy(); stream.destroy?.(); return finish(reject, new FetchError(FETCH_ERROR_CODES.COMPRESSION_RATIO, "Compression ratio too high.", { status })); }
          chunks.push(chunk);
        });
        stream.on("end", () => finish(resolve, { status, headers, mime, body: Buffer.concat(chunks).toString("utf8"), pinnedAddress: pinned.address }));
        stream.on("error", () => finish(reject, new FetchError(FETCH_ERROR_CODES.NETWORK, "Response stream failed.")));
      });
      const timer = setTimeout(() => { req.destroy(); finish(reject, new FetchError(FETCH_ERROR_CODES.TIMEOUT, "Request timed out.")); }, timeoutMs);
      const onAbort = () => { req.destroy(); finish(reject, new FetchError(FETCH_ERROR_CODES.ABORTED, "Request cancelled.")); };
      if (signal) { if (signal.aborted) return onAbort(); signal.addEventListener("abort", onAbort, { once: true }); }
      req.on("error", (error) => finish(reject, error instanceof FetchError ? error : new FetchError(FETCH_ERROR_CODES.NETWORK, "Network error.")));
      req.end();
    });
  }

  // Returns { finalUrl, status, mime, body, redirects:[...] }. Throws NetPolicyError/FetchError.
  async function fetch(rawUrl, { method = "GET" } = {}) {
    if (method !== "GET" && method !== "HEAD") throw new FetchError(FETCH_ERROR_CODES.METHOD_NOT_ALLOWED, "Only GET and HEAD are allowed.");
    let url = policy.checkUrl(rawUrl);
    const redirects = [];
    for (let hop = 0; hop <= maxRedirects; hop += 1) {
      if (signal?.aborted) throw new FetchError(FETCH_ERROR_CODES.ABORTED, "Request cancelled.");
      const response = await fetchOnce(url, method);
      if (response.status >= 300 && response.status < 400) {
        if (!response.location) throw new FetchError(FETCH_ERROR_CODES.REDIRECT_INVALID, "Redirect without location.");
        let next;
        try { next = new URL(response.location, url); } catch { throw new FetchError(FETCH_ERROR_CODES.REDIRECT_INVALID, "Redirect location invalid."); }
        // Re-validate the redirect target exactly like a first request (origin, scheme, port);
        // its address is re-validated by resolvePinned on the next hop.
        try { url = policy.checkUrl(next); } catch (error) {
          if (error instanceof NetPolicyError) { error.redirectFrom = url.pathname; }
          throw error;
        }
        redirects.push({ status: response.status, to: url.pathname });
        if (shouldFollowRedirect && !shouldFollowRedirect(url)) {
          return { finalUrl: url, status: response.status, mime: null, body: null, redirects, redirectStopped: true, pinnedAddress: response.pinnedAddress };
        }
        continue;
      }
      return { finalUrl: url, status: response.status, mime: response.mime || null, body: response.body, redirects, pinnedAddress: response.pinnedAddress };
    }
    throw new FetchError(FETCH_ERROR_CODES.TOO_MANY_REDIRECTS, "Too many redirects.");
  }

  return Object.freeze({ fetch });
}
