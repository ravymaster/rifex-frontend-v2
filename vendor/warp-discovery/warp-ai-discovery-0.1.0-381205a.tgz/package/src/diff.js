// Warp Discovery -- change detection (Phase 9). Hashes and metadata only; no full content is needed.
// States: unchanged, changed, missing, new, stale. A change NEVER publishes anything: it only
// tells the owner what to review. Approved entries that changed go back to review (publisher.js).

import { CONTRACT_VERSIONS, assertPublishedSiteMap } from "./contracts.js";

function index(entries) {
  return new Map((entries || []).map((e) => [e.path || e.href, e]));
}

// inventory vs inventory: new/missing/changed/unchanged pages, broken links, moved routes, forms changed.
export function diffInventories(previous, current) {
  const prevPages = index((previous?.pages || []).filter((p) => p.status === 200 && p.contentHash));
  const currPages = index((current?.pages || []).filter((p) => p.status === 200 && p.contentHash));
  const prevLinks = new Set((previous?.links || []).map((l) => l.path));
  const currLinks = new Set((current?.links || []).map((l) => l.path));
  const pages = [];
  for (const [path, p] of currPages) {
    const before = prevPages.get(path);
    pages.push({ path, state: !before ? "new" : before.contentHash === p.contentHash ? "unchanged" : "changed", legal: Boolean(p.effectiveDate || p.updatedAt) && before && before.contentHash !== p.contentHash });
  }
  for (const [path, p] of prevPages) {
    if (!currPages.has(path)) {
      const movedTo = [...currPages.values()].find((c) => c.contentHash === p.contentHash && !prevPages.has(c.path));
      pages.push({ path, state: "missing", ...(movedTo ? { movedTo: movedTo.path } : {}) });
    }
  }
  const links = [
    ...[...currLinks].filter((l) => !prevLinks.has(l)).map((path) => ({ path, state: "new" })),
    ...[...prevLinks].filter((l) => !currLinks.has(l)).map((path) => ({ path, state: "missing" })),
  ];
  const broken = (current?.pages || []).filter((p) => typeof p.status === "number" && p.status >= 400).map((p) => ({ path: p.path, status: p.status }));
  const formKey = (f) => `${f.foundOn}|${f.actionPath}|${f.method}|${(f.fields || []).map((x) => `${x.name}:${x.type}`).join(",")}`;
  const prevForms = new Set((previous?.forms || []).map(formKey));
  const formsChanged = (current?.forms || []).filter((f) => !prevForms.has(formKey(f))).map((f) => ({ foundOn: f.foundOn, actionPath: f.actionPath }));
  return { contract: CONTRACT_VERSIONS.DIFF, kind: "inventory", pages, links, broken, formsChanged };
}

// published site map vs current candidates: what Warp is being served that no longer matches.
export function diffSiteMap(siteMap, candidates, { now = () => new Date(), maxAgeDays = 30 } = {}) {
  assertPublishedSiteMap(siteMap);
  const current = new Map([...(candidates?.navigation || []), ...(candidates?.content || [])].map((c) => [c.id, c]));
  const currentHrefs = new Set([...current.values()].map((c) => c.href));
  const ageDays = (now().getTime() - Date.parse(siteMap.generatedAt)) / 86_400_000;
  const entries = [...siteMap.navigation, ...siteMap.content].map((e) => {
    const c = current.get(e.id);
    let state;
    if (!c && !currentHrefs.has(e.href)) state = "missing";
    else if (!c || c.contentHash !== e.contentHash || c.href !== e.href) state = "changed";
    else state = ageDays > maxAgeDays ? "stale" : "unchanged";
    return { id: e.id, href: e.href, state };
  });
  const published = new Set(entries.map((e) => e.id));
  const added = [...current.values()].filter((c) => !published.has(c.id) && c.status === "candidate").map((c) => ({ id: c.id, href: c.href, state: "new" }));
  return { contract: CONTRACT_VERSIONS.DIFF, kind: "site_map", mapHash: siteMap.mapHash, entries: [...entries, ...added], needsReview: entries.some((e) => e.state !== "unchanged") || added.length > 0 };
}
