// Warp Discovery -- Connector Verifier. Validates a candidate before any person may approve it,
// and again at build time. Checks route proof, schema (contract), access coherence and risk.
// Forms and endpoints are never verifiable: an observation never becomes a write or a capability.

import { KINDS, validateNavigationEntry, validateContentEntry } from "./contracts.js";

// installedPaths: Set of routes proven by the installed package (strongest proof).
export function verifyCandidate(candidate, { installedPaths = new Set() } = {}) {
  const checks = [];
  const check = (code, ok) => { checks.push({ code, ok: Boolean(ok) }); return ok; };
  if (!candidate || typeof candidate !== "object") return { id: null, ok: false, checks: [{ code: "NOT_A_CANDIDATE", ok: false }], problems: [] };

  if (candidate.kind === KINDS.FORM_OBSERVATION || candidate.kind === KINDS.ENDPOINT_OBSERVATION || candidate.blocked) {
    check("OBSERVATION_NEVER_VERIFIABLE", false);
    return { id: candidate.id, kind: candidate.kind, ok: false, checks, problems: [] };
  }
  if (candidate.kind !== KINDS.NAVIGATION && candidate.kind !== KINDS.PUBLIC_CONTENT) {
    check("KIND_SUPPORTED", false);
    return { id: candidate.id, kind: candidate.kind, ok: false, checks, problems: [] };
  }
  if (candidate.status === "rejected") check("NOT_REJECTED", false);

  const probe = { ...candidate, status: "verified" };
  const problems = candidate.kind === KINDS.NAVIGATION ? validateNavigationEntry(probe) : validateContentEntry(probe);
  check("CONTRACT_VALID", problems.length === 0);
  check("NOT_ADMINISTRATIVE", candidate.access !== "administrative" && candidate.area !== "administrative");

  const ev = candidate.evidence || {};
  const installed = installedPaths.has(candidate.href);
  if (candidate.kind === KINDS.PUBLIC_CONTENT) {
    // Content must have been actually read (200) from a public page, or proven by the installed package.
    check("ROUTE_PROVEN", installed || ev.fetched === true);
    check("ACCESS_PUBLIC", candidate.access === "public");
    check("NO_QUARANTINED_SECTIONS", Array.isArray(candidate.sections) && candidate.sections.every((s) => !s.quarantined));
  } else {
    // Navigation: the route is proven if it was fetched (200), declared/installed, observed to require a
    // session (redirect to sign-in), or linked from an authorized page of the same site.
    // Authentication and account pages are never fetched by design, so a link from an authorized page
    // of the same site (or a redirect to sign-in) proves them; every other PUBLIC page must have been
    // read with 200, or be proven by the installed package.
    const linked = Array.isArray(ev.foundOn) && ev.foundOn.length > 0;
    const neverFetchedByDesign = candidate.area === "authentication" || candidate.access === "account";
    check("ROUTE_PROVEN", installed || candidate.source === "declared" || ev.fetched === true || (neverFetchedByDesign && linked));
    check("NOT_BROKEN", !(typeof ev.status === "number" && ev.status >= 400) && !ev.error && !ev.redirectStoppedAt);
    check("ROBOTS_ALLOWED", !ev.robotsDisallowed);
    // Risk: navigation is read-only orientation -- low risk by definition. A logout entry is only ever
    // a link to the page; the engine can never perform it.
    check("RISK_LOW_READ_ONLY", true);
  }
  const ok = checks.every((c) => c.ok);
  return { id: candidate.id, kind: candidate.kind, ok, checks, problems };
}

export function verifyAll(candidatesDoc, options = {}) {
  const results = {};
  for (const c of [...(candidatesDoc.navigation || []), ...(candidatesDoc.content || []), ...(candidatesDoc.observations || [])]) {
    results[c.id] = verifyCandidate(c, options);
  }
  return results;
}
