// Warp Discovery -- Candidate Builder. Inventory (observations) -> candidate contracts.
// Candidates are PROPOSALS: status "candidate" (or "rejected" when a rule forbids them). Nothing here
// is ever published or served; forms and endpoints are observation-only and permanently blocked.

import { classifyLink, defaultIntentsFor, idFor } from "./classifier.js";
import { CONTRACT_VERSIONS, KINDS, LIMITS } from "./contracts.js";
import { hashOf } from "./hash.js";
import { findStatedDate } from "./contentSafety.js";

const sectionText = (page) => (page.sections || []).map((s) => `${s.heading || ""} ${s.text || ""}`).join(" ");

const SOURCE_PRIORITY = ["header", "nav", "footer", "body", "sitemap", "redirect", "installed", "declared"];

function bestLabel(labels, path) {
  const sorted = Object.entries(labels || {}).filter(([l]) => l && l.trim()).sort((a, b) => b[1] - a[1] || a[0].length - b[0].length);
  if (sorted.length) return sorted[0][0].slice(0, LIMITS.LABEL_MAX);
  const last = String(path).split("/").filter(Boolean).pop() || "Inicio";
  const human = decodeURIComponent(last).replace(/[-_]+/g, " ").trim();
  return (human.charAt(0).toUpperCase() + human.slice(1)).slice(0, LIMITS.LABEL_MAX);
}

function primarySource(sources) {
  for (const s of SOURCE_PRIORITY) if ((sources || []).includes(s)) return s;
  return "body";
}

function cleanTitle(page, fallback) {
  const t = (page.title || "").split(/\s+[|·–—-]\s+/)[0].trim();
  const h1 = page.sections?.find((s) => s.heading)?.heading;
  return (t || h1 || fallback).slice(0, LIMITS.TITLE_MAX);
}

function uniqueId(id, used) {
  let candidate = id;
  for (let n = 2; used.has(candidate); n += 1) candidate = `${id.slice(0, 60)}-${n}`;
  used.add(candidate);
  return candidate;
}

export function buildCandidates(inventory, { now = () => new Date() } = {}) {
  if (!inventory || inventory.contract !== CONTRACT_VERSIONS.INVENTORY) throw new Error("Not a Warp Discovery inventory (unsupported contract).");
  const observedAt = inventory.finishedAt || now().toISOString();
  const used = new Set();
  const pagesByPath = new Map();
  for (const p of inventory.pages || []) {
    pagesByPath.set(p.path, p);
    if (p.finalPath && !pagesByPath.has(p.finalPath)) pagesByPath.set(p.finalPath, p);
  }
  const navigation = [];
  const content = [];

  for (const link of inventory.links || []) {
    if (/^\/api(?:\/|$)/.test(link.path)) continue; // endpoints are observations, never navigation
    const page = pagesByPath.get(link.path);
    const label = link.declared?.label || bestLabel(link.labels, link.path);
    const source = link.declared ? "declared" : primarySource(link.sources);
    // Installed mode: the site's own package DECLARES area/access/action -- more reliable than any
    // inference. It is still validated by the contract and by the Connector verifier like any other.
    const cls = link.declared
      ? { area: link.declared.area, access: link.declared.access, action: link.declared.action, confidence: 1, reasons: ["declared_by_installed_package"] }
      : classifyLink({ path: link.path, label, source, observedAccess: link.observedAccess || page?.observedAccess || null });
    const evidence = { sources: link.sources, foundOn: link.foundOn, labels: Object.keys(link.labels || {}).slice(0, 5), fetched: Boolean(page && page.status === 200 && !page.observedAccess), status: page?.status ?? null, ...(page?.error ? { error: page.error } : {}), ...(link.robotsDisallowed ? { robotsDisallowed: true } : {}), ...(page?.redirectStoppedAt ? { redirectStoppedAt: page.redirectStoppedAt } : {}) };
    let contentId = null;
    // Public documents with readable text become separate public_content candidates.
    if (page && page.status === 200 && Array.isArray(page.sections) && page.sections.length > 0 && cls.access === "public" && (cls.area === "legal" || cls.area === "support")) {
      contentId = uniqueId(idFor(cls.area, link.path, "content"), used);
      content.push({
        kind: KINDS.PUBLIC_CONTENT,
        id: contentId,
        title: cleanTitle(page, label),
        href: link.path,
        area: cls.area,
        access: "public",
        contentHash: page.contentHash,
        // Dates only when the page states them (re-derived from the stored text, so an improved rule
        // applies to an existing scan without fetching again). scannedAt = when the text was read.
        effectiveDate: page.effectiveDate || findStatedDate(sectionText(page), "effective"),
        updatedAt: page.updatedAt || findStatedDate(sectionText(page), "updated"),
        scannedAt: String(inventory.finishedAt || observedAt).slice(0, 10),
        sections: page.sections.map((s, i) => ({ id: `s${i + 1}`, heading: s.heading || null, text: s.text })),
        status: "candidate",
        observedAt,
        source,
        evidence: { ...evidence, quarantinedSections: page.quarantinedSections || 0 },
        confidence: cls.confidence,
        reason: cls.reasons.join(","),
      });
    }
    const id = uniqueId(idFor(cls.area, link.path), used);
    const blocked = cls.area === "administrative";
    navigation.push({
      kind: KINDS.NAVIGATION,
      id,
      label,
      href: link.path,
      area: cls.area,
      access: cls.access,
      action: cls.action,
      intents: Array.isArray(link.declared?.intents) && link.declared.intents.length ? link.declared.intents.slice(0, LIMITS.INTENTS_MAX) : defaultIntentsFor(cls.action, label),
      source,
      contentId,
      observedAt,
      contentHash: page?.contentHash || hashOf({ href: link.path, label, area: cls.area }),
      status: blocked ? "rejected" : "candidate",
      ...(blocked ? { rejectionReason: "administrative_never_published" } : {}),
      evidence,
      confidence: cls.confidence,
      reason: cls.reasons.join(","),
    });
  }

  // Pages that exist only as content with no readable text are reported, not invented.
  const unreadable = (inventory.pages || []).filter((p) => p.status === 200 && Array.isArray(p.sections) && p.sections.length === 0).map((p) => p.path);

  const observations = [
    ...(inventory.forms || []).map((form, i) => ({
      kind: KINDS.FORM_OBSERVATION,
      id: `form-${i + 1}`,
      foundOn: form.foundOn,
      actionPath: form.actionPath,
      method: form.method,
      fields: form.fields,
      status: "candidate",
      blocked: true,
      blockedReason: "form_observation_never_enables_a_write",
      observedAt,
    })),
    ...(inventory.endpoints || []).map((ep, i) => ({
      kind: KINDS.ENDPOINT_OBSERVATION,
      id: `endpoint-${i + 1}`,
      path: ep.path,
      via: ep.via,
      foundOn: ep.foundOn,
      status: "candidate",
      blocked: true,
      blockedReason: "endpoint_observation_never_becomes_a_capability",
      observedAt,
    })),
  ];

  return {
    contract: CONTRACT_VERSIONS.CANDIDATES,
    origin: inventory.origin,
    generatedAt: now().toISOString(),
    inventoryHash: hashOf({ pages: (inventory.pages || []).map((p) => [p.path, p.contentHash || null, p.status || null]), links: (inventory.links || []).map((l) => l.path) }),
    navigation,
    content,
    observations,
    unreadable,
    quarantined: inventory.quarantined || [],
  };
}
