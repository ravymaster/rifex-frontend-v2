// Warp Discovery -- deterministic navigation intent resolution (Phase 8).
//
// Priority: 1) explicit intent  2) matching action  3) compatible access  4) area  5) current page
// (secondary context only). Hard rule: an authentication action (sign_in / register /
// recover_account) is ONLY ever answered by a PUBLIC authentication entry with that exact action --
// a page that requires a session can never answer "where do I sign in", and nothing else displaces
// the sign-in page when that is the real intent.

import { AUTH_ACTIONS } from "./contracts.js";

const MAX_ITEMS = 40;

export function resolveNavigation(siteMap, { action = null, area = null, id = null, currentArea = null } = {}) {
  const nav = (siteMap?.navigation || []).filter((e) => e.status === "published" && e.access !== "administrative");
  let items;
  if (id) items = nav.filter((e) => e.id === id);
  else if (action && AUTH_ACTIONS.includes(action)) items = nav.filter((e) => e.action === action && e.access === "public" && e.area === "authentication");
  else if (action) items = nav.filter((e) => e.action === action);
  else items = nav.slice();
  if (area) items = items.filter((e) => e.area === area);
  const rank = (e) => (e.access === "public" ? 0 : 1) * 10 + (currentArea && e.area === currentArea ? 0 : 1);
  items.sort((a, b) => rank(a) - rank(b) || (a.id < b.id ? -1 : 1));
  return items.slice(0, MAX_ITEMS);
}

// Text -> intent, deterministic. Used by the CLI ("does my map answer this?") and by the offline
// acceptance tests that stand in for the model. It is NOT a replacement for the model in Warp.
const fold = (t) => String(t || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();

const ACTION_LEXICON = [
  ["recover_account", /\b(olvide|olvido|recuperar|recupero|restablecer|reset|forgot)\b.*\b(clave|contrasena|password|acceso|cuenta)\b|\b(clave|contrasena|password)\b.*\b(olvide|olvido|recuperar|restablecer)\b/],
  ["logout", /\b(cerrar sesion|salir de mi cuenta|log ?out|sign ?out)\b/],
  ["register", /\b(registr\w*|crear (una )?cuenta|sign ?up|unirme)\b/],
  ["sign_in", /\b(ingres\w*|iniciar sesion|inicio sesion|inicio de sesion|entrar a mi cuenta|entro a mi cuenta|acceder|log ?in|sign ?in)\b/],
];
const READ_CONTENT = /\b(cuales son|que dicen|que dice|que establecen|que establece|contenido|resumen|explica\w*|puedo|se puede|requisit\w*|edad|anos)\b/;

export function interpretQuery(siteMap, text) {
  const q = fold(text);
  const actions = [];
  for (const [action, re] of ACTION_LEXICON) if (re.test(q) && !(action === "sign_in" && actions.includes("recover_account"))) actions.push(action);
  const nav = (siteMap?.navigation || []).filter((e) => e.status === "published" && e.access !== "administrative");
  // Explicit intents/labels of the site's own approved entries.
  const byIntent = nav
    .map((e) => ({ e, score: [e.label, ...(e.intents || [])].map(fold).filter((s) => s.length >= 4 && q.includes(s)).reduce((m, s) => Math.max(m, s.length), 0) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((x) => x.e);
  let entries;
  if (actions.length) entries = actions.flatMap((a) => resolveNavigation(siteMap, { action: a }));
  else entries = byIntent;
  const docs = new Set(entries.map((e) => e.contentId).filter(Boolean));
  const mode = docs.size && READ_CONTENT.test(q) ? "content" : "link";
  return { actions, entries: [...new Map(entries.map((e) => [e.id, e])).values()], mode, contentIds: [...docs] };
}
