// Warp Discovery -- Discovery Publisher. Builds the ONLY servable artifact (warp.site_map.v1) from
// entries that are (1) present in the current candidates, (2) verified by the Connector verifier,
// (3) approved by a person for the SAME contentHash. Nothing else is ever included.
//
// Changes never publish automatically:
//  - approved but the page changed since -> keep the previously PUBLISHED version if it is still valid
//    and still present on the site, and report it for review; otherwise leave it out;
//  - approved but the route disappeared -> left out (it stops being recommended).
// The output is a local file. Distributing it (deploying the site) is always a separate human step.

import { CONTRACT_VERSIONS, KINDS, assertPublishedSiteMap } from "./contracts.js";
import { verifyCandidate } from "./verifier.js";
import { applyOverrides, findDecision } from "./approvals.js";
import { hashOf } from "./hash.js";

const SERVED_NAV_FIELDS = ["kind", "id", "label", "href", "area", "access", "action", "intents", "contentId", "contentHash", "status"];
const SERVED_CONTENT_FIELDS = ["kind", "id", "title", "href", "area", "access", "contentHash", "effectiveDate", "updatedAt", "scannedAt", "keyFacts", "sections", "status"];

function pick(entry, fields) {
  const out = {};
  for (const f of fields) if (entry[f] !== undefined) out[f] = entry[f];
  return out;
}

export function buildSiteMap({ candidates, approvals, previousSiteMap = null, installedPaths = new Set(), now = () => new Date() }) {
  if (!candidates || candidates.contract !== CONTRACT_VERSIONS.CANDIDATES) throw new Error("Not a Warp Discovery candidates file (unsupported contract).");
  if (approvals && approvals.contract !== CONTRACT_VERSIONS.APPROVALS) throw new Error("Not a Warp Discovery approvals file (unsupported contract).");
  if (previousSiteMap) assertPublishedSiteMap(previousSiteMap);
  const report = { published: [], keptPrevious: [], skipped: [] };
  const previousById = new Map([...(previousSiteMap?.navigation || []), ...(previousSiteMap?.content || [])].map((e) => [e.id, e]));
  const presentHrefs = new Set([...(candidates.navigation || []), ...(candidates.content || [])].map((c) => c.href));

  function resolveEntry(candidate, fields) {
    const decision = findDecision(approvals, candidate.id);
    if (!decision) return report.skipped.push({ id: candidate.id, reason: "not_reviewed" }) && null;
    if (decision.decision !== "approved") return report.skipped.push({ id: candidate.id, reason: "rejected_by_owner" }) && null;
    if (decision.contentHash !== (candidate.contentHash || null)) {
      const prev = previousById.get(candidate.id);
      if (prev && prev.contentHash === decision.contentHash && presentHrefs.has(prev.href)) {
        report.keptPrevious.push({ id: candidate.id, reason: "changed_since_approval_pending_review" });
        return pick(prev, fields);
      }
      return report.skipped.push({ id: candidate.id, reason: "changed_since_approval_pending_review" }) && null;
    }
    const merged = applyOverrides(candidate, decision.overrides);
    const verification = verifyCandidate(merged, { installedPaths });
    if (!verification.ok) return report.skipped.push({ id: candidate.id, reason: "verification_failed", checks: verification.checks.filter((c) => !c.ok).map((c) => c.code) }) && null;
    report.published.push({ id: candidate.id });
    return pick({ ...merged, status: "published" }, fields);
  }

  const content = [];
  for (const c of candidates.content || []) {
    const e = resolveEntry(c, SERVED_CONTENT_FIELDS);
    if (e) content.push({ ...e, sections: e.sections.map((s) => ({ id: s.id, heading: s.heading ?? null, text: s.text })) });
  }
  const contentIds = new Set(content.map((c) => c.id));
  const navigation = [];
  for (const c of candidates.navigation || []) {
    if (c.kind !== KINDS.NAVIGATION) continue;
    const e = resolveEntry(c, SERVED_NAV_FIELDS);
    if (e) navigation.push({ ...e, contentId: e.contentId && contentIds.has(e.contentId) ? e.contentId : null });
  }
  // Approved entries whose route is gone from the site are reported (they stop being recommended).
  for (const d of approvals?.decisions || []) {
    if (d.decision === "approved" && ![...(candidates.navigation || []), ...(candidates.content || [])].some((c) => c.id === d.id)) {
      report.skipped.push({ id: d.id, reason: "missing_from_site" });
    }
  }
  navigation.sort((a, b) => (a.id < b.id ? -1 : 1));
  content.sort((a, b) => (a.id < b.id ? -1 : 1));
  const siteMap = {
    contract: CONTRACT_VERSIONS.SITE_MAP,
    origin: candidates.origin,
    generatedAt: now().toISOString(),
    navigation,
    content,
  };
  siteMap.mapHash = hashOf({ navigation, content });
  assertPublishedSiteMap(siteMap);
  return { siteMap, report };
}
