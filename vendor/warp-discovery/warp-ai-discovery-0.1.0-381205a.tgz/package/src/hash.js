import { createHash } from "node:crypto";

// Canonical JSON: object keys sorted recursively, so the same data always hashes the same no matter
// the insertion order. Used for contentHash (one page/document) and mapHash (a whole site map).
export function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  const keys = Object.keys(value).filter((k) => value[k] !== undefined).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(value[k])}`).join(",")}}`;
}

export function sha256Hex(text) {
  return createHash("sha256").update(String(text), "utf8").digest("hex");
}

export function hashOf(value) {
  return sha256Hex(canonicalJson(value));
}
