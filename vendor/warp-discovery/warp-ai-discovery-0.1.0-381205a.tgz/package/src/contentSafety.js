// Warp Discovery -- crawled content is UNTRUSTED DATA.
//
// 1. Instruction-like text (prompt injection) is QUARANTINED: the whole section is excluded from
//    what can ever be published, and reported for human review. It never reaches Warp.
// 2. Personal data that a public page may leak (emails, phone numbers, Chilean RUT, card-like
//    numbers) is replaced by a neutral marker before anything is stored -- only counts are kept.

const INJECTION_PATTERNS = [
  /ignor(?:e|a|en|ar)\b[^.\n]{0,40}\b(?:previous|prior|above|all|todas?|las|anteriores?)\b[^.\n]{0,30}\b(?:instructions?|instrucciones|reglas|rules|prompts?)/i,
  /(?:disregard|olvida|olvidar|override|anula|anular|bypass|salta(?:te)?)\b[^.\n]{0,40}\b(?:instructions?|instrucciones|rules|reglas|system|sistema|guardrails?|restricciones)/i,
  /\b(?:system prompt|prompt del sistema|developer message|mensaje del sistema|jailbreak|DAN mode)\b/i,
  /\b(?:you are now|ahora eres|act[uú]a como|act as|pretend to be|finge ser|from now on you|a partir de ahora (?:eres|debes|responde))\b/i,
  /<\/?\s*(?:system|assistant|user|instructions?|im_start|im_end)\s*>/i,
  /\b(?:assistant|asistente|AI|IA|model|modelo|Warp)\b[^.\n]{0,25}\b(?:must|debe|deber[aá]s|should|tiene que)\b[^.\n]{0,40}\b(?:say|responder|decir|reveal|revelar|recommend|recomendar|ignore|ignorar|tell|answer)/i,
  /\b(?:BEGIN|END) (?:PROMPT|INSTRUCTIONS|SYSTEM)\b/i,
];

export function looksLikeInstruction(text) {
  const t = String(text || "");
  return INJECTION_PATTERNS.some((re) => re.test(t));
}

const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
const RUT = /\b\d{1,2}\.?\d{3}\.?\d{3}-[\dkK]\b/g;
const CARD = /\b(?:\d[ -]?){13,19}\b/g;
// Phone: only with an explicit "+country" prefix or a phone keyword, so amounts like 10.000.000 are
// never mistaken for a phone number in legal text.
const PHONE = /\+\d{1,3}[\s.-]?\(?\d{1,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}\b|(?:tel[eé]fono|tel\.|fono|celular|whats?app|m[oó]vil|phone)\s*:?\s*\(?\d{1,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}\b/gi;
export const REDACTION_MARK = "[dato omitido]";

// Returns { text, redactions } -- redactions is a count per kind, never the values.
export function redactPersonalData(text) {
  const counts = { email: 0, rut: 0, card: 0, phone: 0 };
  let out = String(text || "");
  out = out.replace(EMAIL, () => { counts.email += 1; return REDACTION_MARK; });
  out = out.replace(RUT, () => { counts.rut += 1; return REDACTION_MARK; });
  out = out.replace(CARD, (m) => { if (m.replace(/\D/g, "").length < 13) return m; counts.card += 1; return REDACTION_MARK; });
  out = out.replace(PHONE, (m) => {
    if (m.replace(/\D/g, "").length < 8) return m;
    counts.phone += 1;
    const keep = m.search(/[+\d(]/); // keep the keyword ("Teléfono: "), drop only the number
    return `${keep > 0 ? m.slice(0, keep) : ""}${REDACTION_MARK}`;
  });
  return { text: out, redactions: counts };
}

// Effective date / last update, only when the page states it explicitly. Never guessed.
const MONTHS = { enero: 1, febrero: 2, marzo: 3, abril: 4, mayo: 5, junio: 6, julio: 7, agosto: 8, septiembre: 9, setiembre: 9, octubre: 10, noviembre: 11, diciembre: 12, january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
export function findStatedDate(text, kind) {
  const lead = kind === "effective"
    ? /(?:vigente desde|vigencia|fecha de vigencia|en vigor desde|publicad[oa](?: el)?|effective(?: date| as of| from)?)\s*:?\s*/i
    : /(?:[uú]ltima actualizaci[oó]n|actualizad[oa] (?:el|al)|last updated|updated(?: on)?)\s*:?\s*/i;
  const m = String(text || "").match(new RegExp(`${lead.source}(\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{4}|\\d{1,2} de [a-záéíóú]+ de \\d{4}|[A-Za-z]+ \\d{1,2},? \\d{4})`, "i"));
  if (!m) return null;
  return toIsoDate(m[1]);
}

function toIsoDate(raw) {
  let y; let mo; let d;
  let m;
  if ((m = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/))) [, y, mo, d] = m.map(Number);
  else if ((m = raw.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/))) { d = Number(m[1]); mo = Number(m[2]); y = Number(m[3]); }
  else if ((m = raw.match(/^(\d{1,2}) de ([a-záéíóú]+) de (\d{4})$/i))) { d = Number(m[1]); mo = MONTHS[m[2].toLowerCase()]; y = Number(m[3]); }
  else if ((m = raw.match(/^([A-Za-z]+) (\d{1,2}),? (\d{4})$/))) { mo = MONTHS[m[1].toLowerCase()]; d = Number(m[2]); y = Number(m[3]); }
  if (!y || !mo || !d || mo > 12 || d > 31) return null;
  return `${String(y).padStart(4, "0")}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}
