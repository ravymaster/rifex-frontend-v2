import test from "node:test";
import assert from "node:assert/strict";
import {
  CONTRACT_VERSIONS, AREAS, ACCESS, ACTIONS, STATUSES, CHANGE_STATES,
  isValidHref, validateNavigationEntry, validateContentEntry, validatePublishedSiteMap, assertPublishedSiteMap,
} from "../src/contracts.js";
import { hashOf, canonicalJson } from "../src/hash.js";

const H = "a".repeat(64);
const nav = (over = {}) => ({ kind: "navigation", id: "auth-login", label: "Ingresar", href: "/login", area: "authentication", access: "public", action: "sign_in", intents: ["ingresar"], contentId: null, status: "published", contentHash: H, ...over });
const doc = (over = {}) => ({ kind: "public_content", id: "legal-terms", title: "Términos", href: "/terminos", area: "legal", access: "public", contentHash: H, effectiveDate: "2026-01-01", updatedAt: null, status: "published", sections: [{ id: "s1", heading: "Uso", text: "Texto." }], ...over });
const map = (over = {}) => ({ contract: CONTRACT_VERSIONS.SITE_MAP, mapHash: H, generatedAt: "2026-11-16T00:00:00Z", navigation: [nav()], content: [doc()], ...over });

test("closed vocabularies match the mission (areas, access, actions, statuses, change states)", () => {
  assert.deepEqual([...AREAS], ["primary_navigation", "account_navigation", "footer", "authentication", "support", "legal", "content", "administrative", "commercial", "solutions"]);
  assert.deepEqual([...ACCESS], ["public", "account", "administrative"]);
  assert.deepEqual([...ACTIONS], ["browse", "read", "sign_in", "register", "recover_account", "create", "configure", "contact", "logout"]);
  assert.deepEqual([...STATUSES], ["observed", "candidate", "verified", "approved", "published", "rejected", "stale"]);
  assert.deepEqual([...CHANGE_STATES], ["unchanged", "changed", "missing", "new", "stale"]);
});

test("href is always a same-site relative path: no scheme, host, query, fragment or traversal", () => {
  for (const ok of ["/", "/login", "/preguntas-frecuentes", "/a/b_c.d"]) assert.equal(isValidHref(ok), true, ok);
  for (const bad of ["https://evil.example/login", "//evil.example", "/login?next=/x", "/terminos#a", "/a/../admin", "javascript:alert(1)", "login", "/a//b", ""]) assert.equal(isValidHref(bad), false, bad);
});

test("a valid navigation entry has no problems", () => {
  assert.deepEqual(validateNavigationEntry(nav()), []);
});

test("an auth action can only be answered by a PUBLIC authentication entry (H-02 by construction)", () => {
  const codes = validateNavigationEntry(nav({ id: "mis-iniciativas", href: "/mis-iniciativas", area: "account_navigation", access: "account", action: "sign_in" })).map((p) => p.code);
  assert.ok(codes.includes("NAV_AUTH_ACTION_NOT_PUBLIC_AUTH"));
});

test("account/administrative coherence is enforced", () => {
  assert.ok(validateNavigationEntry(nav({ area: "account_navigation", access: "public", action: "browse" })).some((p) => p.code === "NAV_ACCOUNT_ACCESS"));
  assert.ok(validateNavigationEntry(nav({ area: "footer", access: "administrative", action: "browse" })).some((p) => p.code === "NAV_ADMIN_AREA"));
  assert.ok(validateNavigationEntry(nav({ area: "legal", access: "account", action: "read" })).some((p) => p.code === "NAV_PUBLIC_DOC_ACCESS"));
  assert.ok(validateNavigationEntry(nav({ area: "authentication", action: "logout", access: "public" })).some((p) => p.code === "NAV_LOGOUT_ACCESS"));
});

test("public content must be public and bounded; quarantined sections are invalid", () => {
  assert.deepEqual(validateContentEntry(doc()), []);
  assert.ok(validateContentEntry(doc({ access: "account" })).some((p) => p.code === "CONTENT_ACCESS_NOT_PUBLIC"));
  assert.ok(validateContentEntry(doc({ sections: [{ id: "s1", text: "x".repeat(1501) }] })).some((p) => p.code === "CONTENT_SECTION_TEXT_INVALID"));
  assert.ok(validateContentEntry(doc({ sections: [{ id: "s1", text: "ok", quarantined: true }] })).some((p) => p.code === "CONTENT_SECTION_QUARANTINED"));
  assert.ok(validateContentEntry(doc({ href: "https://x.example/terminos" })).some((p) => p.code === "CONTENT_HREF_INVALID"));
});

test("a site map with any non-published entry is refused (candidates are never servable)", () => {
  assert.equal(validatePublishedSiteMap(map()).ok, true);
  for (const status of ["observed", "candidate", "verified", "approved", "rejected", "stale"]) {
    const result = validatePublishedSiteMap(map({ navigation: [nav({ status })] }));
    assert.equal(result.ok, false, status);
    assert.ok(result.problems.some((p) => p.code === "SITE_MAP_ENTRY_NOT_PUBLISHED"));
  }
});

test("administrative entries are never servable, even if marked published", () => {
  const result = validatePublishedSiteMap(map({ navigation: [nav({ id: "admin", href: "/admin", area: "administrative", access: "administrative", action: "browse" })] }));
  assert.ok(result.problems.some((p) => p.code === "SITE_MAP_ADMIN_PUBLISHED"));
});

test("unknown contract version fails with a clear code; problems never carry values", () => {
  assert.throws(() => assertPublishedSiteMap(map({ contract: "warp.site_map.v9" })), (e) => e.code === "SITE_MAP_CONTRACT_UNSUPPORTED");
  const result = validatePublishedSiteMap(map({ navigation: [nav({ href: "https://secret-host.example/x" })] }));
  assert.equal(JSON.stringify(result.problems).includes("secret-host"), false);
});

test("dangling contentId and duplicate ids are refused", () => {
  assert.ok(validatePublishedSiteMap(map({ navigation: [nav({ contentId: "nope" })] })).problems.some((p) => p.code === "SITE_MAP_CONTENT_REF_MISSING"));
  assert.ok(validatePublishedSiteMap(map({ navigation: [nav(), nav()] })).problems.some((p) => p.code === "SITE_MAP_DUPLICATE_ID"));
});

test("canonical hashing is order-independent", () => {
  assert.equal(canonicalJson({ b: 1, a: [2, { d: 1, c: 2 }] }), canonicalJson({ a: [2, { c: 2, d: 1 }], b: 1 }));
  assert.equal(hashOf({ x: 1, y: 2 }), hashOf({ y: 2, x: 1 }));
  assert.match(hashOf({}), /^[a-f0-9]{64}$/);
});

test("commercial and solutions areas are public-only", () => {
  assert.deepEqual(validateNavigationEntry(nav({ id: "nav-planes", href: "/planes", area: "commercial", access: "public", action: "browse" })), []);
  assert.ok(validateNavigationEntry(nav({ id: "nav-planes", href: "/planes", area: "commercial", access: "account", action: "browse" })).some((p) => p.code === "NAV_PUBLIC_DOC_ACCESS"));
  assert.deepEqual(validateNavigationEntry(nav({ id: "sol", href: "/soluciones/eventos", area: "solutions", access: "public", action: "browse" })), []);
});

test("keyFacts must be verbatim quotes of an existing section; scannedAt must be a date", () => {
  const base = doc({ scannedAt: "2026-11-16", sections: [{ id: "s3", heading: "Cuentas", text: "Para crear una iniciativa se requiere declaración de ser mayor de 18 años y aceptar los términos." }] });
  const fact = { id: "edad-minima", label: "Edad mínima", sectionId: "s3", quote: "declaración de ser mayor de 18 años" };
  assert.deepEqual(validateContentEntry({ ...base, keyFacts: [fact] }), []);
  assert.ok(validateContentEntry({ ...base, keyFacts: [{ ...fact, quote: "mayor de 16 años" }] }).some((p) => p.code === "CONTENT_KEY_FACT_NOT_VERBATIM"));
  assert.ok(validateContentEntry({ ...base, keyFacts: [{ ...fact, sectionId: "s9" }] }).some((p) => p.code === "CONTENT_KEY_FACT_SECTION_MISSING"));
  assert.ok(validateContentEntry({ ...base, keyFacts: [fact, fact] }).some((p) => p.code === "CONTENT_KEY_FACT_ID_INVALID"));
  assert.ok(validateContentEntry({ ...base, scannedAt: "ayer" }).some((p) => p.code === "CONTENT_DATE_INVALID"));
});
