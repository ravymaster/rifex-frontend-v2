import test from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { PassThrough } from "node:stream";
import { createNetPolicy, isPublicAddress } from "../src/netPolicy.js";
import { createSafeFetcher } from "../src/safeFetch.js";
import { startFixtureSite } from "./fixtureSite.mjs";

const lookupTo = (...answers) => {
  const calls = [];
  const fn = (host, opts, cb) => { calls.push(host); const a = answers[Math.min(calls.length - 1, answers.length - 1)]; cb(null, a.map((address) => ({ address, family: address.includes(":") ? 6 : 4 }))); };
  fn.calls = calls;
  return fn;
};

test("private, loopback, link-local, CGNAT, metadata, multicast and mapped addresses are never public", () => {
  for (const ip of ["127.0.0.1", "10.1.2.3", "172.16.0.1", "172.31.255.255", "192.168.1.8", "169.254.169.254", "100.64.0.1", "100.98.210.35", "0.0.0.0", "224.0.0.1", "255.255.255.255", "198.18.0.1",
    "::1", "::", "fc00::1", "fd12::1", "fe80::1", "ff02::1", "::ffff:127.0.0.1", "::ffff:10.0.0.1", "::ffff:a9fe:a9fe", "64:ff9b::a00:1", "2001:db8::1", "2002:c0a8:0101::1"]) {
    assert.equal(isPublicAddress(ip), false, ip);
  }
  for (const ip of ["93.184.216.34", "8.8.8.8", "76.76.21.21", "2606:4700::1111"]) assert.equal(isPublicAddress(ip), true, ip);
});

test("origin policy: https only, no credentials, blocked names, no private literal", () => {
  assert.throws(() => createNetPolicy({ origin: "http://site.example" }), (e) => e.code === "SCHEME_NOT_ALLOWED");
  assert.throws(() => createNetPolicy({ origin: "file:///etc/passwd" }), (e) => e.code === "SCHEME_NOT_ALLOWED");
  assert.throws(() => createNetPolicy({ origin: "ftp://site.example" }), (e) => e.code === "SCHEME_NOT_ALLOWED");
  assert.throws(() => createNetPolicy({ origin: "https://user:pw@site.example" }), (e) => e.code === "CREDENTIALS_IN_URL");
  for (const o of ["https://localhost", "https://api.localhost", "https://metadata.google.internal", "https://169.254.169.254", "https://10.0.0.1", "https://[::1]"]) {
    assert.throws(() => createNetPolicy({ origin: o }), (e) => ["HOST_BLOCKED", "ADDRESS_NOT_PUBLIC"].includes(e.code), o);
  }
  // Loopback only works with the explicit test flag AND a loopback literal origin.
  assert.throws(() => createNetPolicy({ origin: "http://127.0.0.1:3000", allowHttp: true }));
  assert.ok(createNetPolicy({ origin: "http://127.0.0.1:3000", allowHttp: true, allowLoopbackForTests: true }));
});

test("only the authorized origin, scheme and port can be requested", () => {
  const p = createNetPolicy({ origin: "https://site.example", lookupImpl: lookupTo(["93.184.216.34"]) });
  assert.equal(p.checkUrl("https://site.example/a").pathname, "/a");
  assert.throws(() => p.checkUrl("https://other.example/"), (e) => e.code === "CROSS_ORIGIN");
  assert.throws(() => p.checkUrl("https://site.example:8443/"), (e) => e.code === "PORT_NOT_ALLOWED");
  assert.throws(() => p.checkUrl("http://site.example/"), (e) => e.code === "SCHEME_NOT_ALLOWED");
  assert.throws(() => p.checkUrl("data:text/html,x"), (e) => e.code === "SCHEME_NOT_ALLOWED");
});

test("DNS: every answer must be public (cloud metadata and mixed answers are refused)", async () => {
  await assert.rejects(createNetPolicy({ origin: "https://site.example", lookupImpl: lookupTo(["169.254.169.254"]) }).resolvePinned("site.example"), (e) => e.code === "ADDRESS_NOT_PUBLIC");
  await assert.rejects(createNetPolicy({ origin: "https://site.example", lookupImpl: lookupTo(["93.184.216.34", "10.0.0.5"]) }).resolvePinned("site.example"), (e) => e.code === "ADDRESS_NOT_PUBLIC");
  await assert.rejects(createNetPolicy({ origin: "https://site.example", lookupImpl: lookupTo(["::ffff:192.168.0.1"]) }).resolvePinned("site.example"), (e) => e.code === "ADDRESS_NOT_PUBLIC");
});

// Fake transport: answers with a scripted response and records what the socket would connect to.
function fakeRequest(script) {
  const seen = [];
  const impl = (options, onResponse) => {
    const req = new EventEmitter();
    req.end = () => {
      const pinned = [];
      options.lookup(options.hostname, {}, (err, address) => pinned.push(address));
      options.lookup(options.hostname, {}, (err, address) => pinned.push(address)); // a 2nd resolution attempt
      seen.push({ path: options.path, method: options.method, pinned, headers: options.headers });
      const step = script(options.path, seen.length);
      const res = new PassThrough();
      res.statusCode = step.status; res.headers = step.headers || {};
      onResponse(res);
      res.end(step.body || "");
    };
    req.destroy = () => {};
    return req;
  };
  impl.seen = seen;
  return impl;
}

test("DNS rebinding: the socket is pinned to the validated address; a later private answer is never used", async () => {
  const lookup = lookupTo(["93.184.216.34"], ["127.0.0.1"]);
  const policy = createNetPolicy({ origin: "https://site.example", lookupImpl: lookup });
  const requestImpl = fakeRequest(() => ({ status: 200, headers: { "content-type": "text/html" }, body: "<p>ok</p>" }));
  const res = await createSafeFetcher(policy, { requestImpl }).fetch("https://site.example/");
  assert.equal(res.status, 200);
  assert.deepEqual(requestImpl.seen[0].pinned, ["93.184.216.34", "93.184.216.34"]);
  assert.equal(lookup.calls.length, 1);
});

test("every redirect hop is re-resolved and re-validated (same host flipping to a private IP is refused)", async () => {
  const lookup = lookupTo(["93.184.216.34"], ["10.0.0.9"]);
  const policy = createNetPolicy({ origin: "https://site.example", lookupImpl: lookup });
  const requestImpl = fakeRequest((path) => (path === "/" ? { status: 302, headers: { location: "/next" } } : { status: 200, headers: { "content-type": "text/html" }, body: "x" }));
  await assert.rejects(createSafeFetcher(policy, { requestImpl }).fetch("https://site.example/"), (e) => e.code === "ADDRESS_NOT_PUBLIC");
});

test("only GET/HEAD; no cookies sent; identifiable user agent", async () => {
  const policy = createNetPolicy({ origin: "https://site.example", lookupImpl: lookupTo(["93.184.216.34"]) });
  const requestImpl = fakeRequest(() => ({ status: 200, headers: { "content-type": "text/html", "set-cookie": "sid=1" }, body: "x" }));
  const f = createSafeFetcher(policy, { requestImpl });
  await assert.rejects(f.fetch("https://site.example/", { method: "POST" }), (e) => e.code === "METHOD_NOT_ALLOWED");
  await f.fetch("https://site.example/");
  await f.fetch("https://site.example/");
  assert.equal(requestImpl.seen.every((s) => s.method === "GET" && !("Cookie" in s.headers) && !("cookie" in s.headers)), true);
  assert.match(requestImpl.seen[0].headers["User-Agent"], /^WarpDiscovery\//);
});

test("real fixture: redirect to a private IP and to another site are blocked; size, bomb, binary, loops capped", async () => {
  const site = await startFixtureSite();
  try {
    const policy = createNetPolicy({ origin: site.origin, allowHttp: true, allowLoopbackForTests: true });
    const f = createSafeFetcher(policy, { maxBytes: 1_000_000 });
    await assert.rejects(f.fetch(`${site.origin}/redir-private`), (e) => e.code === "CROSS_ORIGIN");
    await assert.rejects(f.fetch(`${site.origin}/redir-external`), (e) => e.code === "CROSS_ORIGIN");
    await assert.rejects(f.fetch(`${site.origin}/redir-chain-1`), (e) => e.code === "TOO_MANY_REDIRECTS");
    await assert.rejects(f.fetch(`${site.origin}/big`), (e) => e.code === "TOO_LARGE");
    await assert.rejects(f.fetch(`${site.origin}/bomb`), (e) => ["TOO_LARGE", "COMPRESSION_RATIO"].includes(e.code));
    await assert.rejects(f.fetch(`${site.origin}/binary`), (e) => e.code === "MIME_NOT_ALLOWED");
    const ok = await f.fetch(`${site.origin}/redir-ok`);
    assert.equal(ok.finalUrl.pathname, "/eventos");
    assert.equal(site.requests.some((r) => r.method !== "GET"), false);
    assert.equal(site.requests.some((r) => r.cookie), false);
  } finally { await site.close(); }
});

test("cancellation and timeout stop the request", async () => {
  const site = await startFixtureSite();
  try {
    const policy = createNetPolicy({ origin: site.origin, allowHttp: true, allowLoopbackForTests: true });
    const controller = new AbortController();
    controller.abort();
    await assert.rejects(createSafeFetcher(policy, { signal: controller.signal }).fetch(`${site.origin}/`), (e) => e.code === "ABORTED");
  } finally { await site.close(); }
  const policy = createNetPolicy({ origin: "https://site.example", lookupImpl: lookupTo(["93.184.216.34"]) });
  const hang = () => { const req = new EventEmitter(); req.end = () => {}; req.destroy = () => {}; return req; };
  await assert.rejects(createSafeFetcher(policy, { requestImpl: hang, timeoutMs: 50 }).fetch("https://site.example/"), (e) => e.code === "TIMEOUT");
});
