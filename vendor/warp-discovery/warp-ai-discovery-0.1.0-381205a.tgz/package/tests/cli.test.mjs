import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { startFixtureSite } from "./fixtureSite.mjs";
import { scanSite, buildCandidates, verifyAll, CONTRACT_VERSIONS } from "../src/index.js";

const BIN = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "bin", "warp-discover.mjs");
const run = (...args) => spawnSync(process.execPath, [BIN, ...args], { encoding: "utf8" });

test("CLI review/build/report/diff: human approval required, only approved entries are built, no publish command", async () => {
  const site = await startFixtureSite();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "warp-cli-"));
  try {
    // The scan step is the same scanSite the CLI calls (the CLI itself refuses loopback/http origins).
    const inventory = await scanSite({ origin: site.origin, allowHttp: true, allowLoopbackForTests: true, limits: { delayMs: 0 } });
    const candidates = buildCandidates(inventory);
    fs.writeFileSync(path.join(dir, "inventory.json"), JSON.stringify(inventory));
    fs.writeFileSync(path.join(dir, "candidates.json"), JSON.stringify(candidates));
    fs.writeFileSync(path.join(dir, "verification.json"), JSON.stringify(verifyAll(candidates)));

    const help = run();
    assert.match(help.stdout, /No existe comando de publicación/);
    assert.equal(/publish|deploy/i.test(help.stdout.replace(/publicación/g, "")), false);

    assert.equal(run("review", "--dir", dir, "--approve", "auth-login").status, 2, "--by is mandatory");
    assert.equal(run("review", "--dir", dir, "--approve", "auth-login", "--by", "Asistente IA").status, 2, "AI cannot approve");
    assert.equal(run("review", "--dir", dir, "--approve", "admin-admin", "--by", "Ana Pérez").status, 2, "admin never");
    assert.equal(run("review", "--dir", dir, "--approve", "form-1", "--by", "Ana Pérez").status, 2, "forms never");

    const ok = run("review", "--dir", dir, "--approve", "auth-login,legal-terminos,content-terminos", "--by", "Ana Pérez");
    assert.equal(ok.status, 0, ok.stderr);
    const approvals = JSON.parse(fs.readFileSync(path.join(dir, "approvals.json"), "utf8"));
    assert.equal(approvals.contract, CONTRACT_VERSIONS.APPROVALS);
    assert.equal(approvals.decisions.every((d) => d.approver.type === "human" && d.approver.name === "Ana Pérez"), true);

    const build = run("build", "--dir", dir);
    assert.equal(build.status, 0, build.stderr);
    const siteMap = JSON.parse(fs.readFileSync(path.join(dir, "site-map.json"), "utf8"));
    assert.deepEqual(siteMap.navigation.map((n) => n.id).sort(), ["auth-login", "legal-terminos"]);
    assert.deepEqual(siteMap.content.map((c) => c.id), ["content-terminos"]);
    assert.match(build.stdout, /no publicado/);

    const report = run("report", "--dir", dir, "--ask", "¿Dónde ingreso a mi cuenta?");
    assert.equal(report.status, 0, report.stderr);
    assert.match(report.stdout, /"href": "\/login"/);
    assert.match(fs.readFileSync(path.join(dir, "report.md"), "utf8"), /Nada de esto está publicado/);

    const diff = run("diff", "--dir", dir, "--previous", path.join(dir, "site-map.json"));
    assert.equal(diff.status, 0, diff.stderr);
    assert.equal(JSON.parse(diff.stdout).kind, "site_map");

    // The CLI never accepts a non-https origin (no SSRF through the command line).
    const bad = run("scan", "--origin", "http://127.0.0.1:9", "--dir", dir);
    assert.notEqual(bad.status, 0);
  } finally {
    await site.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
