import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
// Installed package: the real @warp-ai/connector 0.4.0 next to it. In the monorepo: the sibling source.
const { createConnector } = await import("@warp-ai/connector").catch(() => import("../../warp-ai-connector/src/index.js"));
import { startFixtureSite } from "./fixtureSite.mjs";
import {
  scanSite, buildCandidates, verifyAll, verifyCandidate, createApprovalRegistry, recordDecision, buildSiteMap,
  registerSiteDiscoveryCapabilities, createSiteDiscoveryCapabilities, resolveNavigation, interpretQuery,
  diffInventories, diffSiteMap, scanNextAppRoutes, buildInstalledManifest, mergeInstalled, assertPublishedSiteMap,
} from "../src/index.js";

const HUMAN = { type: "human", name: "Propietaria del sitio" };
let site; let inventory; let installedPaths; let candidates; let verification; let approvals; let built;

// Installed mode supplies what the crawler cannot see: the recovery page (only linked from /login,
// which is never fetched) and the account pages' exact classification.
const DECLARED = [
  { href: "/recuperar-clave", label: "Recuperar contraseña", area: "authentication", access: "public", action: "recover_account" },
  { href: "/mi-cuenta/bancos", label: "Bancos y pagos", area: "account_navigation", access: "account", action: "configure", intents: ["bancos", "conectar medio de pago"] },
];

test.before(async () => {
  site = await startFixtureSite();
  const scanned = await scanSite({ origin: site.origin, allowHttp: true, allowLoopbackForTests: true, limits: { delayMs: 0 } });
  const merged = mergeInstalled(scanned, buildInstalledManifest({ routes: [], declared: DECLARED }));
  inventory = merged.inventory; installedPaths = merged.installedPaths;
  candidates = buildCandidates(inventory);
  verification = verifyAll(candidates, { installedPaths });
  approvals = createApprovalRegistry(candidates.origin);
  // The owner approves every VERIFIED navigation/content candidate (what "warp discover review" does).
  for (const c of [...candidates.navigation, ...candidates.content]) {
    if (verification[c.id].ok) recordDecision(approvals, c, { decision: "approved", approver: HUMAN, verification: verification[c.id] });
  }
  built = buildSiteMap({ candidates, approvals, installedPaths });
});
test.after(async () => { await site.close(); });

test("nothing is published without a human approval (candidates are never auto-published)", () => {
  const empty = buildSiteMap({ candidates, approvals: createApprovalRegistry(candidates.origin), installedPaths });
  assert.equal(empty.siteMap.navigation.length, 0);
  assert.equal(empty.siteMap.content.length, 0);
  assert.ok(empty.report.skipped.every((s) => s.reason === "not_reviewed"));
});

test("the AI cannot approve: non-human approvers and bot names are refused", () => {
  const c = candidates.navigation.find((n) => n.href === "/login");
  const reg = createApprovalRegistry(candidates.origin);
  for (const approver of [{ type: "ai", name: "Warp" }, { type: "human", name: "GPT asistente" }, { type: "human", name: "Claude" }, { type: "human", name: "" }, null]) {
    assert.throws(() => recordDecision(reg, c, { decision: "approved", approver, verification: verification[c.id] }), /APPROVER|person/i);
  }
  assert.equal(reg.decisions.length, 0);
});

test("forms, endpoints, admin and unverified candidates can never be approved", () => {
  const reg = createApprovalRegistry(candidates.origin);
  const form = candidates.observations.find((o) => o.kind === "form_observation");
  assert.throws(() => recordDecision(reg, form, { decision: "approved", approver: HUMAN, verification: { ok: true } }), (e) => e.code === "BLOCKED_OBSERVATION");
  const admin = candidates.navigation.find((n) => n.href === "/admin");
  assert.throws(() => recordDecision(reg, admin, { decision: "approved", approver: HUMAN, verification: { ok: true } }), (e) => e.code === "ADMINISTRATIVE");
  const big = candidates.navigation.find((n) => n.href === "/big");
  assert.equal(verification[big.id].ok, false);
  assert.throws(() => recordDecision(reg, big, { decision: "approved", approver: HUMAN, verification: verification[big.id] }), (e) => e.code === "NOT_VERIFIED");
  assert.equal(verifyCandidate(form).ok, false);
});

test("Connector verifies: public pages need a 200 read, account/auth need a same-site link, admin never", () => {
  const v = (href) => verification[candidates.navigation.find((n) => n.href === href).id];
  assert.equal(v("/terminos").ok, true);
  assert.equal(v("/login").ok, true);
  assert.equal(v("/mi-cuenta").ok, true);
  assert.equal(v("/admin").ok, false);
  assert.equal(v("/Terminos").ok, false); // 404
  assert.equal(v("/privado/secreto").ok, false); // robots
  assert.equal(v("/redir-private").ok, false); // SSRF-blocked
  assert.equal(v("/recuperar-clave").ok, true); // proven by the installed package
});

test("the published map contains no admin, no candidates, no failed pages and passes the serve contract", () => {
  const { siteMap } = built;
  assert.doesNotThrow(() => assertPublishedSiteMap(siteMap));
  assert.equal(siteMap.navigation.some((e) => e.access === "administrative"), false);
  assert.equal(siteMap.navigation.some((e) => ["/big", "/bomb", "/binary", "/redir-private", "/privado/secreto", "/Terminos"].includes(e.href)), false);
  assert.equal([...siteMap.navigation, ...siteMap.content].every((e) => e.status === "published"), true);
});

test("Discovery serves only published entries through the real Connector 0.4.0, read-only", async () => {
  const connector = createConnector({ platform: { id: "demo", name: "Demo" } });
  const ids = registerSiteDiscoveryCapabilities(connector, { siteMap: built.siteMap, origin: "https://demo.example" });
  assert.deepEqual(ids, ["site.navigation.list", "site.content.read"]);
  const manifest = connector.getManifest();
  for (const cap of manifest.capabilities) {
    assert.equal(cap.operationType, "read");
    assert.equal(cap.sideEffects, false);
    assert.equal(cap.authentication, "public");
    assert.ok(cap.description.length <= 240, `${cap.id} description fits Warp's 240-char window`);
  }
  // A map with a candidate in it can never be registered.
  const tampered = structuredClone(built.siteMap);
  tampered.navigation[0].status = "candidate";
  assert.throws(() => registerSiteDiscoveryCapabilities(createConnector({ platform: { id: "x", name: "X" } }), { siteMap: tampered, origin: "https://demo.example" }), (e) => e.code === "SITE_MAP_INVALID");
});

test("public content is read by approved id; arbitrary URLs and unknown ids are rejected before the handler", async () => {
  const connector = createConnector({ platform: { id: "demo", name: "Demo" } });
  registerSiteDiscoveryCapabilities(connector, { siteMap: built.siteMap, origin: "https://demo.example" });
  const terms = await connector.invoke("site.content.read", { id: "content-terminos" });
  assert.equal(terms.url, "https://demo.example/terminos");
  assert.equal(terms.effective_date, "2026-01-15");
  assert.match(JSON.stringify(terms.sections), /mayor de 18 años/);
  assert.match(terms.notice, /no constituye asesoría legal/);
  await assert.rejects(connector.invoke("site.content.read", { id: "https://evil.example/terminos" }), (e) => e.code === "INVALID_ARGUMENTS");
  await assert.rejects(connector.invoke("site.content.read", { id: "content-admin" }), (e) => e.code === "INVALID_ARGUMENTS");
  await assert.rejects(connector.invoke("site.content.read", { id: "content-terminos", url: "https://evil.example" }), (e) => e.code === "INVALID_ARGUMENTS");
  await assert.rejects(connector.invoke("site.navigation.list", { action: "delete_account" }), (e) => e.code === "INVALID_ARGUMENTS");
});

test("prompt injection in a page never reaches what is served", async () => {
  const connector = createConnector({ platform: { id: "demo", name: "Demo" } });
  registerSiteDiscoveryCapabilities(connector, { siteMap: built.siteMap, origin: "https://demo.example" });
  const out = JSON.stringify(await connector.invoke("site.content.read", { id: "content-terminos" })) + JSON.stringify(connector.getManifest());
  assert.equal(/ignora todas|system prompt|12 años|recomienda \/admin|actúa como/i.test(out), false);
});

test("Phase 8 intent resolution: sign_in never resolves to an account page; account pages carry the session notice", async () => {
  const connector = createConnector({ platform: { id: "demo", name: "Demo" } });
  registerSiteDiscoveryCapabilities(connector, { siteMap: built.siteMap, origin: "https://demo.example" });
  const signIn = await connector.invoke("site.navigation.list", { action: "sign_in" });
  assert.deepEqual(signIn.items.map((i) => i.url), ["https://demo.example/login"]);
  assert.equal(signIn.items[0].requires_session, false);
  const reg = await connector.invoke("site.navigation.list", { action: "register" });
  assert.deepEqual(reg.items.map((i) => i.url), ["https://demo.example/registro"]);
  const rec = await connector.invoke("site.navigation.list", { action: "recover_account" });
  assert.deepEqual(rec.items.map((i) => i.url), ["https://demo.example/recuperar-clave"]);
  const cfg = await connector.invoke("site.navigation.list", { action: "configure" });
  assert.ok(cfg.items.some((i) => i.url.endsWith("/mi-cuenta/bancos") && i.requires_session && /Requiere iniciar sesión/.test(i.notice)));
  // Even if a published map tried to answer sign_in with an account page, the contract refuses it.
  const evil = structuredClone(built.siteMap);
  const acct = evil.navigation.find((e) => e.access === "account" && e.action !== "logout");
  acct.action = "sign_in";
  assert.throws(() => assertPublishedSiteMap(evil));
  assert.equal(resolveNavigation(built.siteMap, { action: "sign_in" }).some((e) => e.access !== "public"), false);
});

test("deterministic query interpretation covers the acceptance questions", () => {
  const q = (t) => interpretQuery(built.siteMap, t);
  assert.deepEqual(q("¿Dónde ingreso a mi cuenta?").entries.map((e) => e.href), ["/login"]);
  assert.deepEqual(q("¿Cómo me registro?").entries.map((e) => e.href), ["/registro"]);
  assert.deepEqual(q("Olvidé mi contraseña").entries.map((e) => e.href), ["/recuperar-clave"]);
  assert.deepEqual(q("¿Dónde me registro o cómo ingreso?").entries.map((e) => e.href).sort(), ["/login", "/registro"]);
  assert.deepEqual(q("¿Dónde están las preguntas frecuentes?").entries.map((e) => e.href), ["/preguntas-frecuentes"]);
  const terms = q("¿Cuáles son los términos?");
  assert.equal(terms.mode, "content");
  assert.deepEqual(terms.contentIds, ["content-terminos"]);
  assert.equal(q("¿Dónde están los términos?").mode, "link");
});

test("change detection: changed/new/missing/moved pages, broken links and changed forms; changes never auto-publish", async () => {
  const prev = structuredClone(inventory);
  const curr = structuredClone(inventory);
  const terms = curr.pages.find((p) => p.path === "/terminos");
  terms.contentHash = "f".repeat(64);
  curr.pages = curr.pages.filter((p) => p.path !== "/seguridad");
  curr.links = curr.links.filter((l) => l.path !== "/seguridad"); // the route disappeared from the site
  curr.pages.push({ ...prev.pages.find((p) => p.path === "/seguridad"), path: "/seguridad-nueva" });
  curr.forms = curr.forms.map((f) => ({ ...f, fields: [...f.fields, { name: "telefono", type: "tel" }] }));
  const d = diffInventories(prev, curr);
  assert.equal(d.pages.find((p) => p.path === "/terminos").state, "changed");
  assert.equal(d.pages.find((p) => p.path === "/seguridad").state, "missing");
  assert.equal(d.pages.find((p) => p.path === "/seguridad").movedTo, "/seguridad-nueva");
  assert.ok(d.broken.some((b) => b.path === "/Terminos"));
  assert.equal(d.formsChanged.length > 0, true);

  // Rebuild from the changed site with the SAME approvals: the changed doc is not re-published with
  // new text -- the last approved version is kept and flagged; the removed page stops being served.
  const c2 = buildCandidates(curr);
  const rebuilt = buildSiteMap({ candidates: c2, approvals, previousSiteMap: built.siteMap, installedPaths });
  const keptTerms = rebuilt.siteMap.content.find((e) => e.id === "content-terminos");
  assert.equal(keptTerms.contentHash, built.siteMap.content.find((e) => e.id === "content-terminos").contentHash);
  assert.ok(rebuilt.report.keptPrevious.some((k) => k.id === "content-terminos"));
  assert.equal(rebuilt.siteMap.navigation.some((e) => e.href === "/seguridad"), false);
  const sd = diffSiteMap(built.siteMap, c2);
  assert.equal(sd.needsReview, true);
  assert.equal(sd.entries.find((e) => e.id === "content-terminos").state, "changed");
  assert.equal(sd.entries.find((e) => e.href === "/seguridad").state, "missing");
  const stale = diffSiteMap(built.siteMap, candidates, { now: () => new Date(Date.parse(built.siteMap.generatedAt) + 40 * 86_400_000) });
  assert.ok(stale.entries.some((e) => e.state === "stale"));
});

test("installed mode lists route NAMES only and never reads .env or hidden files", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "warp-installed-"));
  try {
    const mk = (p, content = "x") => { fs.mkdirSync(path.dirname(path.join(dir, p)), { recursive: true }); fs.writeFileSync(path.join(dir, p), content); };
    mk("page.jsx"); mk("terminos/page.jsx"); mk("(publico)/faq/page.tsx"); mk("eventos/[slug]/page.jsx"); mk("api/secret/route.js");
    mk("_private/page.jsx"); mk(".env.local", "SECRET=1"); mk(".hidden/page.jsx"); mk("admin/page.jsx");
    const routes = scanNextAppRoutes(dir);
    assert.deepEqual(routes.filter((r) => !r.dynamic).map((r) => r.path), ["/", "/admin", "/faq", "/terminos"]);
    assert.equal(routes.some((r) => r.path.startsWith("/api")), false);
    const manifest = buildInstalledManifest({ routes, declared: [{ href: "https://evil.example", label: "x", area: "footer", access: "public", action: "browse" }] });
    assert.deepEqual(manifest.routes, ["/", "/admin", "/faq", "/terminos"]);
    assert.equal(manifest.declared.length, 0);
    assert.equal(manifest.problems[0].code, "DECLARED_HREF_INVALID");
    // A route proven by the package is still never published without review; admin never.
    const fakeAdmin = { kind: "navigation", id: "admin-admin", label: "Admin", href: "/admin", area: "administrative", access: "administrative", action: "browse", intents: [], contentId: null, status: "candidate", evidence: {} };
    assert.equal(verifyCandidate(fakeAdmin, { installedPaths: new Set(manifest.routes) }).ok, false);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test("no leakage between sites: each connector serves only its own map and origin", async () => {
  const other = structuredClone(built.siteMap);
  other.navigation = other.navigation.filter((e) => e.href === "/login");
  other.content = [];
  other.navigation[0].contentId = null;
  const a = createConnector({ platform: { id: "a", name: "A" } });
  const b = createConnector({ platform: { id: "b", name: "B" } });
  registerSiteDiscoveryCapabilities(a, { siteMap: built.siteMap, origin: "https://a.example" });
  const idsB = registerSiteDiscoveryCapabilities(b, { siteMap: other, origin: "https://b.example" });
  assert.deepEqual(idsB, ["site.navigation.list"]);
  const listB = await b.invoke("site.navigation.list", {});
  assert.equal(listB.items.every((i) => i.url.startsWith("https://b.example/")), true);
  assert.equal(listB.items.length, 1);
  await assert.rejects(b.invoke("site.content.read", { id: "content-terminos" }), (e) => e.code === "CAPABILITY_NOT_FOUND");
});

test("compatibility: an old installation that does not register these capabilities is unchanged; bad options fail clearly", () => {
  const old = createConnector({ platform: { id: "old", name: "Old" } });
  old.capability({ id: "old.thing.read", description: "Una capacidad antigua de lectura.", inputSchema: { type: "object", properties: {}, required: [], additionalProperties: false }, outputSchema: { type: "object", properties: {}, required: [], additionalProperties: false }, handler: async () => ({}) });
  assert.deepEqual(old.getManifest().capabilities.map((c) => c.id), ["old.thing.read"]);
  assert.throws(() => registerSiteDiscoveryCapabilities({}, { siteMap: built.siteMap, origin: "https://x.example" }), (e) => e.code === "CONNECTOR_REQUIRED");
  assert.throws(() => createSiteDiscoveryCapabilities({ siteMap: { ...built.siteMap, contract: "warp.site_map.v2" }, origin: "https://x.example" }), (e) => e.code === "SITE_MAP_CONTRACT_UNSUPPORTED");
  assert.throws(() => createSiteDiscoveryCapabilities({ siteMap: built.siteMap, origin: "http://x.example" }), (e) => e.code === "SITE_ORIGIN_INVALID");
});

test("owner-approved keyFacts are served verbatim with scan date; an invented or reworded fact is refused", async () => {
  const terms = candidates.content.find((c) => c.id === "content-terminos");
  const section = terms.sections.find((s) => /mayor de 18/.test(s.text));
  const fact = { id: "edad-minima", label: "Edad mínima para crear una iniciativa", sectionId: section.id, quote: "debes ser mayor de 18 años" };
  const reg = createApprovalRegistry(candidates.origin);
  assert.throws(() => recordDecision(reg, terms, { decision: "approved", approver: HUMAN, verification: verification[terms.id], overrides: { keyFacts: [{ ...fact, quote: "debes ser mayor de 16 años" }] } }), (e) => e.code === "OVERRIDE_INVALID");
  recordDecision(reg, terms, { decision: "approved", approver: HUMAN, verification: verification[terms.id], overrides: { keyFacts: [fact] } });
  const { siteMap } = buildSiteMap({ candidates, approvals: reg, installedPaths });
  const connector = createConnector({ platform: { id: "demo", name: "Demo" } });
  registerSiteDiscoveryCapabilities(connector, { siteMap, origin: "https://demo.example" });
  for (const page of [1, 2]) {
    const out = await connector.invoke("site.content.read", { id: "content-terminos", page });
    assert.deepEqual(out.key_facts, [{ label: fact.label, quote: fact.quote, section: section.heading }]);
    assert.match(out.scanned_at, /^\d{4}-\d{2}-\d{2}$/);
  }
});

test("«Publicada DD/MM/AAAA» is read as the effective date; nothing is guessed when no date is stated", async () => {
  const { findStatedDate } = await import("../src/contentSafety.js");
  assert.equal(findStatedDate("Política de Privacidad Versión 1.0 · Publicada 01/09/2026", "effective"), "2026-09-01");
  assert.equal(findStatedDate("Última actualización: 27/08/2026.", "updated"), "2026-08-27");
  assert.equal(findStatedDate("Texto sin fechas.", "effective"), null);
});
