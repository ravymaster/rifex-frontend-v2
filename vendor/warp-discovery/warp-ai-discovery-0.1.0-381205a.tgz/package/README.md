# @warp-ai/discovery (0.1.0, local)

Warp Discovery: the crawler **discovers**, the Connector **verifies**, a person **approves**,
Discovery **publishes**, Warp uses **only what was published**. No AI anywhere in this package.

## Modes

- **Scan** (`warp-discover scan`): safe, same-origin, read-only crawl of an authorized public site →
  `inventory.json`, `candidates.json`, `verification.json`, `report.md`. Publishes nothing.
- **Serve** (`registerSiteDiscoveryCapabilities(connector, { siteMap, origin })`): registers two
  generic read capabilities on an existing `@warp-ai/connector` (>= 0.4.0) from a site map built by
  `warp-discover build`. Refuses to start if the map contains anything not published.

```js
import { createConnector } from "@warp-ai/connector";
import { registerSiteDiscoveryCapabilities } from "@warp-ai/discovery/serve";
import siteMap from "./warp/site-map.json" with { type: "json" };

const connector = createConnector({ platform: { id: "my-site", name: "My Site" } });
// ...existing capabilities...
registerSiteDiscoveryCapabilities(connector, { siteMap, origin: "https://my-site.example" });
```

Capabilities: `site.navigation.list` (action/area/id, closed enums) and `site.content.read`
(content id, closed enum; never a URL). `sign_in`, `register` and `recover_account` only ever resolve
to PUBLIC authentication pages; account pages carry `requires_session: true`.

To use them from Warp AI Engine, the site entry in `WARP_AI_HOSTED_SITES` needs the two invocation
paths and their classification (`minimumWarpLevel 1, public, read, low, none`). Configuration only.

## CLI

```
warp-discover scan   --origin https://site --dir ./warp-scan [--max-pages 50 --max-depth 3 --concurrency 2 --delay-ms 1000] [--installed declared.json]
warp-discover report --dir ./warp-scan [--ask "¿Dónde ingreso?"]
warp-discover review --dir ./warp-scan --approve id1,id2 --reject id3 --by "Nombre Apellido" [--intents "a|b"]
warp-discover build  --dir ./warp-scan [--previous site-map.json] [--out site-map.json]
warp-discover diff   --dir ./warp-scan --previous <old-scan-dir|site-map.json>
```

There is no publish command. The built map is installed with the site's own deploy.

## Safety

https only; same origin; every DNS answer must be public and the socket is pinned to it; redirects
re-validated; GET/HEAD only; no cookies; MIME allowlist; size and decompression caps; robots.txt;
page/depth/concurrency/rate/time caps; no sign-in, registration, recovery, logout, admin, account or
API fetches; forms and endpoints are observations only; hidden/script content dropped;
instruction-like text quarantined; personal data replaced before storage. Approval requires an
identified person and is bound to the approved content hash.
